$(function(){
    // -> ajax 가 시작될때 실행 ==> 우선순위1 (에러발생시에도 실행)
    $(document).ajaxStart(function (event) {
        // console.log('ajaxStart',event);
        //loadingBarShow();
        $('.loading').show();
    }).ajaxError(function(event,jqxhr,settings,thrownError){
            console.log("==================ajaxError")
            console.log(jqxhr)
            console.log(jqxhr.status);
            if( jqxhr.status == 401) {
                alert(jqxhr.responseJSON.message);
                if (jqxhr.getResponseHeader("SESSION_EXPIRED") === "true") {
                    window.location.href = "/login";
                } else {//접근 권한이 없는경우

                }
            }else if(jqxhr.status == 400){
                let messages = jqxhr.responseJSON.join("\n")
                alert(messages)
            }else{
                alert(jqxhr.responseJSON.message);
            }
            //else if(jqxhr.status == 500){
             //   alert('시스템 에러 발생! 관리자에게 문의하세요.');
           // }
    }).ajaxComplete(function(event,request,settings) {
        // console.log('ajaxComplete', event, request, settings);
        if (settings.url == "/ajax/changeLocale") {
            location.reload();
        } else {
            //loadingBarHide();
        }
        $('.loading').hide();
    });
});

//언어 처리 변경시
function fnChangeLocale(lang) {
    $.ajax({
        type: "post",
        url: "/ajax/changeLocale",
        data: {"language": lang},
        dataType: "json",
        success: function (data, textStatus, jqXHR) {
            console.log('fnChangeLocale :');
          //  location.reload();
            /*  // Ajax 요청이 성공한 경우, 처리할 코드 작성
              if (jqXHR.getResponseHeader("SESSION_EXPIRED") === "true") {
                  alert("세션이 만료되었습니다2.");
                  window.location.href = "/login";
              }else{
                  location.reload();
              }
              */
        },
        error: function (jqXHR, textStatus, errorThrown) {
            /*  if (jqXHR.getResponseHeader("SESSION_EXPIRED") === "true") {
                  alert("세션이 만료되었습니다1.");
                  window.location.href = "/login";
              }
             */
        },
        complete : function(){
            //location.reload();
        }
    });
}

//로그인시 선택한 언어 세팅
function setLocale(language){
    $("#lang").val(language).prop("selected", true);
}

/**
 * Toast Grid
 */
function resetGridData(grid, data){
    // 그리드 컬럼
    const gridColumns = grid.getColumns();

    // 공통 Response
    const codeData = data['codeData'];
    const gridData = data['gridData'];

    /**
     * 1. 그리드 넓이 재설정
     * 2. 코드 콤보박스 옵션 재설정
     *    - codeData 키값 == grid 컬럼 name 이랑 일치해야함
     * */
    gridColumns.forEach((col)=>{
        for(const [k,v] of Object.entries(col)){
            if(k==='baseWidth')col['width']=v;

            if(k==='name'&&codeData!=null&&codeData[v])col.editor.options.listItems=codeData[v];
        }
    });

    // 컬럼 재설정
    grid.setColumns(gridColumns);

    // 그리드 데이터 재설정
    grid.resetData(gridData['collection']);
}

function getSaveCheckedRow(grid){
    grid.finishEditing();
    return JSON.stringify({
        createdRows:grid.getModifiedRows()['createdRows'].filter(x => grid.getCheckedRowKeys().includes(x.rowKey)),
        updatedRows:grid.getModifiedRows()['updatedRows'].filter(x => grid.getCheckedRowKeys().includes(x.rowKey))
    });
}
function getRemoveCheckedRow(grid){
    const result = [];
    const checkedRows = grid.getCheckedRows();
    const createdRows = grid.getModifiedRows()['createdRows'];

    checkedRows.forEach((ckr)=>{
        if(!createdRows.find(r=>r.rowKey===ckr.rowKey)){
            result.push(ckr);
        }
    })

    return JSON.stringify({
        deletedRows:result
    });
}



/*
function removeRow(grid){
    if(grid.getRow( grid.getFocusedCell().rowKey)['removeRowButton']){
        grid.removeRow(grid.getFocusedCell().rowKey,{});
    }
}
*/
