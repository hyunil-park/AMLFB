/**
 * 그리드 totalCount
 */
class TotalCount {
    constructor() {
        const el = document.querySelector('.total');

        this.el = el;
        this.render();
    }
    state = {
        count : 0
    }
    setCount(count){
        this.state.count = count;
        this.render();
    }
    render() {
        this.el.innerHTML = `<p>Total : <b>${this.state.count}</b>건<p>`;
    }
}