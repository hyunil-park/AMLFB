/**
 * 행삭제 버튼 function
 * 추가된 row만 행제거 가능, 기존데이터 행제거 불가능
 * 구분값 removeRowButton : true
 */
class RemoveRowButton {
    constructor(props) {
        const img = document.createElement('img')
        img.src="/images/ico_delete.svg";
        img.alt="행삭제";

        const i = document.createElement('i')


        const el = document.createElement('button');


        if(props.value){
            el.className = "btn btn-delete";
            i.append(img);
            el.append(i);
        }


        el.addEventListener('click',(ev)=>{
            props.grid.removeRow(props.rowKey,{});
        });

        this.el = el;
        this.render(props);
    }

    getElement() {
        return this.el;
    }

    render(props) {
        this.el.value = String(props.value);
    }
}
