$(document).ready(function(){
	alert("20230921 js test");
	//fnSearch(1,null, true);
	// Datepicker
        var datepicker1_1 = new tui.DatePicker('#tui-datepicker1-1',
            {
            date: new Date(),
            input: {
                element: '#startDate',
                format: 'yyyy-MM-dd'
            }
        });
        var datepicker1_2 = new tui.DatePicker('#tui-datepicker1-2',
            {
            date: new Date(),
            input: {
                element: '#endDate',
                format: 'yyyy-MM-dd'
            }
        });
});	
	
	/* 그리드 페이징 */
	const pagination = new tui.Pagination('pagination', {
		itemsPerPage: 10,
		visiblePages: 10,
	});
	pagination.on('beforeMove',(ev)=>{
		const {page} = ev;
		fnSearch(page);
	});
	pagination.on('afterMove',function (data){
		console.log(data);
	})
	
	/* 그리드 생성 */
	const grid = new tui.Grid({
       el: document.getElementById('grid'),
       //columnOptions:{ resizable: true },
       rowHeaders:['checkbox'],
       columns: [
        {header:'지점', name:'custRgstryBrn', align: 'center'},
        {header:'보고서문서번호', name:'strId', align: 'center'},
        {header:'보고서종류', name:'workGbn', align: 'center'},
        {header:'보고자', name:'updateId', align: 'center'},
        {header:'보고일시', name:'uptdttm', align: 'center'},
        {header:'RULE ID', name:'ruleId', align: 'center'}, 
        {header:'결재상태코드', name: 'sta',  align: 'center', hidden:true},
        {header:'결재상태', name: 'strStatus', align: 'center'},
        {header:'검토결과',  
         name: 'firstApprovalResult',
		 align		: 'center',
		 formatter	: 'listItemText',
		 editor		: { type	: 'select', background: '#f4f4f4',
						options	: { listItems: [] } },
		},
		{header:'검토의견', name: 'firstApprovalComment', align: 'center'},
        {header:'검토자', name: 'firstApprovalNm', align: 'center'},
        {header:'검토일자', name: 'firstApprovalDate', align: 'center'}
       ]
     });
	
	/* 그리드 조회 */
	function fnSearch(currentPage, perPage, reset){
		if(!isSearchValidation()){
            return;
        }
		perPage = perPage ? perPage : 10;

		$.ajax({
		type: "GET",
        url: "/tms/rpt/ATmsRp01/ajax/search/list",
		contentType : "application/json; charset=utf-8",
        data:{
          "pageIndex"   : currentPage,
          "pageSize"    : perPage,
          "startDate"   : $("#startDate").val(),
          "endDate"     : $("#endDate").val(),
          "strCustNo"   : $("#strCustNo").val(),
          "strRptType"  : $("#strRptType").val(),
		  "strRptStatus": $("#strRptStatus").val()
        },
        success: function (data) {
            resetGridData(grid, data)
             if(reset){
              pagination.reset(data.gridData.totalCount);
              $("#count-span").html(data.gridData.totalCount);
             }
		}
     });
 	}
	
	/* 엑셀 다운로드 */
	function fnExcelDown(){
		
		const count = grid.getRowCount();
		
		if(count ==0){
			alert("조회한 내역이 없어 엑셀로 내려 받을 내용이 없습니다.");
			return;
		}
		
		const options = {
		includeHiddenColumns: false,
		  onlySelected: true,
		  fileName: '통합문서',
		};

		grid.export('xlsx', options);
	}
	
	/* 저장 */
	function fnSave(){
		
		if(confirm("결재 하시겠습니까?")){
			ufReApproval();
		}
	}
	
	function ufReApproval(){
		grid.finishEditing();
		if(!isSaveValidation(grid, 'save')){
			return;
		}
		
		$.ajax({
			type		: "POST",
			url			: "/tms/rpt/ATmsRp01/ajax/save",
			contentType	: "application/json; charset=utf-8",
			data		: getSaveCheckedRow(grid),
			success		: function(res){
				console.log("success");
				console.log(res);
				if(res.success){
					alert("저장되었습니다");
					fnSearch(1,null, true);
				}else{
					if(res.code == 'STR001'){	
						alert(res.message);
					}
				}
			}
		});
	}	
	
	
	
	
	
	
	
	
	
	
	
	
	
	/* function ufMultiCheckBox(){
	  var tempInt = 0;
	  var gridCnt = 0;	//그리드 리스트 카운트
	  for(var j=1; j<=grid.getRowCount(); j++){
	    if(grid.getCheckedRows().length == 1){
	      if(grid.getColumnValues("sta")[j]=="R"){	  
	        tempInt++;
	      }else{
	        alert("선택된 보고서의 상태가 [반려]인 경우만 결재상신이 가능합니다.");
	        return false;
	      }
	    }
	  }
	  if(tempInt==0){
	    alert("[결재] 처리할 항목을 선택해주세요.");
	    return false;
	  }else{
	    return true; 
	  }
	}
	
	function ufCheckSta(){
		  var tempInt=0;
		  for(var j=1; j<=mSheet.LastRow; j++){
		    if(mSheet.CellValue(j, "CHECK")==1){
		      if(mSheet.CellValue(j,"STA")=="C"){
		        tempInt++;
		      }else{
		        alert("선택된 보고서의 상태가 [결재상신]인 경우만 검토가 가능합니다.");
		        return false;
		      }
		    }
		  }
		  if(tempInt==0){
		    alert("[결재상신] 처리할 항목을 선택해주세요.");
		    return false;
		  }else{
		    return true; 
		  }
		}

		function ufCheckBox(){
		  var count=0;
		  for(var i=1; i<=mSheet.LastRow; i++){
		    if(mSheet.CellValue(i, "CHECK")==1){
		      if(mSheet.CellValue(i,"STA")=="R"){
		        if(count==1){
		          alert("하나의 보고서를 선택하세요.");
		          return false;
		        }
		        count++;
		        document.frm1.vSelectRow.value=i;
		      }else{
		        alert("선택된 보고서의 상태가 [반려]인 경우만 추출상태로 변경하는 것이 가능합니다."); 
		        return false;
		      }     
		    }
		  } if(count==0){
		    alert("보고서를 선택하세요.");
		    return false;
		  }else{
		    return true;
		  }
		} */