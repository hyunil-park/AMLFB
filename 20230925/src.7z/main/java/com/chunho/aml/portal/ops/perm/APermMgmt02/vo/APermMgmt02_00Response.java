package com.chunho.aml.portal.ops.perm.APermMgmt02.vo;

import lombok.Getter;
import lombok.Setter;

import java.util.List;

@Getter
@Setter
public class APermMgmt02_00Response {
	
	private String menuCode;
	private String menuName;
	private boolean authorized;
	private String groupCode;
	private String registerId;
	private String modifyId;
	private List<APermMgmt02_00Response> _children;

	public void setUser(String userId){
		this.registerId = userId;
		this.modifyId = userId;
	}
}
