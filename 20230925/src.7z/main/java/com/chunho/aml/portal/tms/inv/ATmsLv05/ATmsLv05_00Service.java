package com.chunho.aml.portal.tms.inv.ATmsLv05;

public class ATmsLv05_00Service {

}
