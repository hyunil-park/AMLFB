package com.chunho.aml.portal.kyc.cra.AKycEdd01;

public interface AKycEdd01_00Repository {

}
