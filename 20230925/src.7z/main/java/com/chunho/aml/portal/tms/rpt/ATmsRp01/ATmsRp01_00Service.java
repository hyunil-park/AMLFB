package com.chunho.aml.portal.tms.rpt.ATmsRp01;

import javax.validation.Valid;

import org.springframework.stereotype.Service;

import com.chunho.aml.common.generic.GenericGridRequest;
import com.chunho.aml.common.generic.GenericGridResponse;
import com.chunho.aml.portal.tms.rpt.ATmsRp01.vo.ATmsRp01_00Response;
import com.chunho.aml.portal.tms.rpt.ATmsRp01.vo.ATmsRp01_00SaveRequest;
import com.chunho.aml.portal.tms.rpt.ATmsRp01.vo.ATmsRp01_00SearchRequest;
import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class ATmsRp01_00Service {
	
	private final ATmsRp01_00Repository aTmsRp01_00Repository;

	public GenericGridResponse<ATmsRp01_00Response> findRp01List(@Valid ATmsRp01_00SearchRequest request) {
		
		return GenericGridResponse.<ATmsRp01_00Response>builder()
				.pageIndex(request.getPageIndex())
				.pageSize(request.getPageSize())
				.totalCount(aTmsRp01_00Repository.findTotalCount(request))
				.collection(aTmsRp01_00Repository.findRp01List(request))
				.build();
	}

	public void save(@Valid GenericGridRequest<ATmsRp01_00SaveRequest> request) {
		// TODO Auto-generated method stub
		
	}

}
   