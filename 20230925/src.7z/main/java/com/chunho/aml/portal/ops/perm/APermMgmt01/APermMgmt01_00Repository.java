package com.chunho.aml.portal.ops.perm.APermMgmt01;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;

import com.chunho.aml.portal.ops.perm.APermMgmt01.vo.APermMgmt01_00Response;
import com.chunho.aml.portal.ops.perm.APermMgmt01.vo.APermMgmt01_00SaveRequest;
import com.chunho.aml.portal.ops.perm.APermMgmt01.vo.APermMgmt01_00SearchRequest;

/**
 * author         : yejin
 * date           : 2023-06-20
 * description    :
 * ===========================================================
 * DATE              AUTHOR             NOTE
 * -----------------------------------------------------------
 * 2023-05-25        yejin       최초 생성
 */

@Mapper
public interface APermMgmt01_00Repository {

	int findTotalCount(APermMgmt01_00SearchRequest request);
	
	List<APermMgmt01_00Response> findUserList(APermMgmt01_00SearchRequest request);
	
	boolean checkDuplicateUserId(String userId);
	void createUser(APermMgmt01_00SaveRequest userSaveRequest, String sessionUserId);
	
	void modifyUser(APermMgmt01_00SaveRequest userSaveRequest, String sessionUserId);
	
	void deleteUser(APermMgmt01_00SaveRequest userSaveRequest, String sessionUserId);
	APermMgmt01_00Response findUserById(String userId);
	
	void changePassword(String userId, String password);

}
