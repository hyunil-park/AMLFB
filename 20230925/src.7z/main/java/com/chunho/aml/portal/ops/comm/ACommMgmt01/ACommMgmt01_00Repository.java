package com.chunho.aml.portal.ops.comm.ACommMgmt01;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;

import com.chunho.aml.common.generic.GenericCommonRequest;
import com.chunho.aml.portal.ops.comm.ACommMgmt01.vo.ACommMgmt01_00Response;
import com.chunho.aml.portal.ops.comm.ACommMgmt01.vo.ACommMgmt01_00SaveRequest;
import com.chunho.aml.portal.ops.comm.ACommMgmt01.vo.ACommMgmt01_00SearchRequest;
import com.chunho.aml.portal.ops.comm.ACommMgmt01.vo.ACommMgmt01_01Response;
import com.chunho.aml.portal.ops.comm.ACommMgmt01.vo.ACommMgmt01_01SaveRequest;

@Mapper
public interface ACommMgmt01_00Repository {

	//그룹코드
	List<ACommMgmt01_00Response> findGroupCodeList(ACommMgmt01_00SearchRequest request);
	int findGroupCodeTotalCount(ACommMgmt01_00SearchRequest request);
	
	boolean checkDuplicateGroupCode(String bcodCode);
	
	void createGroupCode(ACommMgmt01_00SaveRequest groupCodeSaveRequest, String sessionUserId);
	void updateGroupCode(ACommMgmt01_00SaveRequest groupCodeSaveRequest, String sessionUserId);
	void deleteGroupCode(ACommMgmt01_00SaveRequest groupCodeSaveRequest, String sessionUserId);
	
	//공통코드
	List<ACommMgmt01_01Response> findCommonCodeList(GenericCommonRequest<Void> request, String bcodCode);
	int findCommonCodeTotalCount(String bcodCode);
	
	void createCommonCode(ACommMgmt01_01SaveRequest commonCodeSaveRequest, String sessionUserId);
	void updateCommonCode(ACommMgmt01_01SaveRequest commonCodeSaveRequest, String sessionUserId);
	void deleteCommonCode(ACommMgmt01_01SaveRequest commonCodeSaveRequest, String sessionUserId);
	
	boolean checkDuplicateCommonCode(String bcodCode, String codeCode);
	
	
	

}
