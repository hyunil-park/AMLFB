package com.chunho.aml.portal.ops.perm.APermMgmt02;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;

import com.chunho.aml.common.generic.GenericCommonRequest;
import com.chunho.aml.portal.ops.perm.APermMgmt02.vo.APermMgmt02_00Response;
import com.chunho.aml.portal.ops.perm.APermMgmt02.vo.APermMgmt02_00SearchRequest;
import com.chunho.aml.portal.ops.perm.APermMgmt02.vo.APermMgmt02_01Response;

@Mapper
public interface APermMgmt02_00Repository {
    
	List<APermMgmt02_01Response> groupList(APermMgmt02_00SearchRequest request);
	int groupTotalCount();

	List<APermMgmt02_00Response> authMenuList(String groupCode);

	default List<APermMgmt02_00Response> findAuthMenuTree(String groupCode){
		List<APermMgmt02_00Response> authMenuList = this.authMenuList(groupCode);
		authMenuList.forEach(one->{
			if(one.get_children().isEmpty()){
				one.set_children(null);
			}else{
				one.get_children().forEach(two->{
					if(two.get_children().isEmpty()){
						two.set_children(null);
					}
				});
			}
		});
		return authMenuList;
	}

	int exist(APermMgmt02_00Response request);
	int update(APermMgmt02_00Response request);
	int insert(APermMgmt02_00Response request);

	default int save(APermMgmt02_00Response request){
		int result=0;
		if(exist(request)>0){
			update(request);
		}else{
			insert(request);
		}
		return result;
	}
	
}
