package com.chunho.aml.portal.ops.comm.test;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;

import com.chunho.aml.portal.ops.comm.test.vo.TestResponse;


@Mapper
public interface TestRepository {

	List<TestResponse> findUserList(String sessionUserId);
}
