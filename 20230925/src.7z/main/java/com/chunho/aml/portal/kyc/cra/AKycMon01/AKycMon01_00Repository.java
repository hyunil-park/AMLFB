package com.chunho.aml.portal.kyc.cra.AKycMon01;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;

import com.chunho.aml.portal.kyc.cra.AKycMon01.vo.AKycMon01_00Response;
import com.chunho.aml.portal.kyc.cra.AKycMon01.vo.AKycMon01_00SearchRequest;

@Mapper
public interface AKycMon01_00Repository {

	List<AKycMon01_00Response> findmonList(AKycMon01_00SearchRequest request);

}
