package com.chunho.aml.portal.tms.sum.ATmsSt03;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Controller
@AllArgsConstructor
@RequestMapping("/tms/sum/ATmsSt03")
@Slf4j
public class ATmsSt03_00Controller {
	
	@GetMapping("/list")
	public String index(Model model){
        return "tms/sum/ATmsSt03/ATmsSt03_00";
    }
}
