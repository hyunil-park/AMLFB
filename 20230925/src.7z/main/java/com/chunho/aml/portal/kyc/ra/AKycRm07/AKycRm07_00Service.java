package com.chunho.aml.portal.kyc.ra.AKycRm07;

import org.springframework.stereotype.Service;

import com.chunho.aml.common.SessionInfo;
import com.chunho.aml.common.generic.GenericGridRequest;
import com.chunho.aml.common.generic.GenericGridResponse;
import com.chunho.aml.portal.kyc.ra.AKycRm07.vo.AKycRm07_00Response;
import com.chunho.aml.portal.kyc.ra.AKycRm07.vo.AKycRm07_00SaveRequest;
import com.chunho.aml.portal.kyc.ra.AKycRm07.vo.AKycRm07_00SearchRequest;

import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class AKycRm07_00Service {

	private final AKycRm07_00Repository repository;
	
	public GenericGridResponse<AKycRm07_00Response> findreguList(AKycRm07_00SearchRequest request) {
		return GenericGridResponse.<AKycRm07_00Response>builder()
				.pageIndex(request.getPageIndex())
                .pageSize(request.getPageSize())
                .totalCount(repository.findTotalCount(request))
                .collection(repository.findreguList(request))
                .build();
	}

	public void save(GenericGridRequest<AKycRm07_00SaveRequest> request) {
		String sessionUserId = SessionInfo.getSessionUser().getUserId();
		
		request.getCreatedRows().forEach( x-> {
			boolean isExistYn = repository.checkDuplicateRegu(x.getReguLst());
			
			if(isExistYn) {
				throw AKycRm07_00ErrorType.STR001.exception();
			}else {
				repository.create(x, sessionUserId);
			}
		});
		
		request.getUpdatedRows().forEach( x-> {
			boolean isExistYn = repository.checkDuplicateRegu(x.getReguLst());
			
//			if(isExistYn) {
//				throw AKycRm07_00ErrorType.STR001.exception();
//			}else {
				repository.update(x, sessionUserId);
//			}
		});
	}

	public void delete(GenericGridRequest<AKycRm07_00SaveRequest> request) {
		String sessionUserId = SessionInfo.getSessionUser().getUserId();
		
		request.getDeletedRows().forEach( x-> {
			repository.delete(x, sessionUserId);
		});
		
	}

}
