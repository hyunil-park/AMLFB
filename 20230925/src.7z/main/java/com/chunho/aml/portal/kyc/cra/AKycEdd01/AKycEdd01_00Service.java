package com.chunho.aml.portal.kyc.cra.AKycEdd01;

public class AKycEdd01_00Service {

}
