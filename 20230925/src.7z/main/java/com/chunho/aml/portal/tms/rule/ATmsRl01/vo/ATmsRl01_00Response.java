package com.chunho.aml.portal.tms.rule.ATmsRl01.vo;

public class ATmsRl01_00Response {

}
