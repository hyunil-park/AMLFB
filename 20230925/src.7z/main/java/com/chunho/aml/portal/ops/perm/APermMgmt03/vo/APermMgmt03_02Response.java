package com.chunho.aml.portal.ops.perm.APermMgmt03.vo;

import lombok.Builder;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Builder
public class APermMgmt03_02Response {
    private String first;
    private String second;
    private String third;
}
