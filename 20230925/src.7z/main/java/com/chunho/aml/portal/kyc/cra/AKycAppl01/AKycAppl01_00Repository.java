package com.chunho.aml.portal.kyc.cra.AKycAppl01;

public interface AKycAppl01_00Repository {

}
