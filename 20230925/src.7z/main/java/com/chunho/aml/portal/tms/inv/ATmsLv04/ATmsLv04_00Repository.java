package com.chunho.aml.portal.tms.inv.ATmsLv04;

public interface ATmsLv04_00Repository {

}
