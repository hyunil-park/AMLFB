package com.chunho.aml.portal.ops.perm.APermMgmt04;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;

import com.chunho.aml.portal.ops.perm.APermMgmt04.vo.APermMgmt04_00Response;
import com.chunho.aml.portal.ops.perm.APermMgmt04.vo.APermMgmt04_00SearchRequest;

/**
 * author         : yejin
 * date           : 2023-06-20
 * description    :
 * ===========================================================
 * DATE              AUTHOR             NOTE
 * -----------------------------------------------------------
 * 2023-05-25        yejin       최초 생성
 */

@Mapper
public interface APermMgmt04_00Repository {

     void saveLog(APermMgmt04_00Response logVO);
     List<APermMgmt04_00Response> findLogList(APermMgmt04_00SearchRequest request);

     int findTotalCount(APermMgmt04_00SearchRequest request);
}
