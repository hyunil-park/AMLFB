package com.chunho.aml.portal.common.data;

import java.util.List;

import org.springframework.stereotype.Service;

import lombok.RequiredArgsConstructor;

/**
 * author         : yejin
 * date           : 2023-07-05
 * description    : 공통으로 사용하는 데이터 (공통코드, 부서, 그룹, ... ) Service
 * ===========================================================
 * DATE              AUTHOR             NOTE
 * -----------------------------------------------------------
 * 2023-05-24        yejin       최초 생성
 */

@Service
@RequiredArgsConstructor
public class CommonService {

    private final CommonRepository repository;

    /**
     * 그룹 코드
     */
    public List<CodeVO> findGroupList(CodeEnumType codeEnumType){

        return selectOrAllCodeList(repository.findGroupList(), codeEnumType);
    }

    /**
     * 부서 코드
     */
    public List<CodeVO> findDepartmentList(CodeEnumType codeEnumType){

        return selectOrAllCodeList(repository.findDepartmentList(), codeEnumType);

    }
    
    /**
     * 위험등급 목록	
     */
	public List<CodeVO> findriskLevList(CodeEnumType codeEnumType) {
		return selectOrAllCodeList(repository.findriskLevList(), codeEnumType);
	}

	/**
     * 사용여부
     */
	public List<CodeVO> finduseYnList(CodeEnumType codeEnumType) {
		return selectOrAllCodeList(repository.finduseYnList(), codeEnumType);
	}
	
	/**
     * 체크여부
     */
	public List<CodeVO> findcheckYnList(CodeEnumType codeEnumType) {
		return selectOrAllCodeList(repository.findcheckYnList(), codeEnumType);
	}

    /**
     * 공통그룹 코드
     */
	public List<CodeVO> findCodeList(CodeEnumType codeEnumType) {
		
		return selectOrAllCodeList(repository.findCodeList(), codeEnumType);
	}
	
	/**
     * 상품 및 서비스
     */
	public List<CodeVO> findProdTypeList(CodeEnumType codeEnumType) {
		return selectOrAllCodeList(repository.findProdTypeList(), codeEnumType);
	}
	
	/**
     * 거래유형
     */
	public List<CodeVO> findTranTpList(CodeEnumType codeEnumType) {
		return selectOrAllCodeList(repository.findTranTpList(), codeEnumType);
	}
	
	/**
     * 거래목적
     */
	public List<CodeVO> findTranPurpList(CodeEnumType codeEnumType) {
		return selectOrAllCodeList(repository.findTranPurpList(), codeEnumType);
	}

	/**
     * 예상 거래 횟수(연당위)
     */
	public List<CodeVO> findTranExpCntList(CodeEnumType codeEnumType) {
		return selectOrAllCodeList(repository.findTranExpCntList(), codeEnumType);
	}

	/**
     * 예상 거래 금액(USD/연단위)
     */
	public List<CodeVO> findTranExpAmountList(CodeEnumType codeEnumType) {
		return selectOrAllCodeList(repository.findTranExpAmountList(), codeEnumType);
	}

	/**
     * 상품거래채널	
     */
	public List<CodeVO> findProdTranChList(CodeEnumType codeEnumType) {
		return selectOrAllCodeList(repository.findProdTranChList(), codeEnumType);
	}
	
	/**
     * 관계인 구분	
     */
	public List<CodeVO> findrestype(CodeEnumType codeEnumType) {
		return selectOrAllCodeList(repository.findrestype(), codeEnumType);
	}
	
	/**
     * 상품 대분류	
     */
	public List<CodeVO> findmcGsListList(CodeEnumType codeEnumType) {
		return selectOrAllCodeList(repository.findmcGsListList(), codeEnumType);
	}

	/**
     * 상품 상세 
     */
	public List<CodeVO> finddtlGsListList(CodeEnumType codeEnumType) {
		return selectOrAllCodeList(repository.finddtlGsListList(), codeEnumType);
	}
	
	/**
     * 고객상태
     */
	public List<CodeVO> findCustStatList(CodeEnumType codeEnumType) {
		return selectOrAllCodeList(repository.findCustStatList(), codeEnumType);
	}
	
	/**
     * 고객위험등급
     */
	public List<CodeVO> findCustRiskList(CodeEnumType codeEnumType) {
		return selectOrAllCodeList(repository.findCustRiskList(), codeEnumType);
	}
	
	/**
     * 승인상태
     */
	public List<CodeVO> findApplStatList(CodeEnumType codeEnumType) {
		return selectOrAllCodeList(repository.findApplStatList(), codeEnumType);
	}
	
	
	public List<CodeVO> fnidApproveGroupList(CodeEnumType codeEnumType) {
		
		return selectOrAllCodeList(repository.fnidApproveGroupList(), codeEnumType);
	}
	
	public List<CodeVO> fnidApproveUserList(CodeEnumType codeEnumType) {
		
		return selectOrAllCodeList(repository.fnidApproveUserList(), codeEnumType);
	}

	public List<CodeVO> fnidApproveUserList2(CodeEnumType codeEnumType) {

		return selectOrAllCodeList(repository.fnidApproveUserList2(), codeEnumType);
	}


    /**
     * 전체/선택 + 코드 list 생성
     * @param list
     * @param codeEnumType
     * @return
     */
    private List<CodeVO> selectOrAllCodeList(List<CodeVO> list, CodeEnumType codeEnumType ){

        list.add(0,CodeVO.builder().value(codeEnumType.value).text(codeEnumType.text).build());

        return list;

    }

	

	


	
	/**
	 * 보고서종류 코드 list 추가_20230918
	 * @param codeEnumType
	 * @return
	 */
	public List<CodeVO> findRptType(CodeEnumType codeEnumType) {

		return selectOrAllCodeList(repository.findRptType(), codeEnumType);
	}
	
	/**
	 * 결재상태 코드 list 추가_20230918
	 * @param codeEnumType
	 * @return
	 */
	public List<CodeVO> findRptStatus(CodeEnumType codeEnumType) {

		return selectOrAllCodeList(repository.findRptStatus(), codeEnumType);
	}
	
	/**
	 * 검토결과 코드 list 추가_20230918
	 * @param codeEnumType
	 * @return
	 */
	public List<CodeVO> findFirstApprovalResult(CodeEnumType codeEnumType) {

		return selectOrAllCodeList(repository.findFirstApprovalResult(), codeEnumType);
	}



}
