package com.chunho.aml.portal.str.investigation.account;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

public class ObjectMapperJsonTest {
    public static void main(String[] args) throws JsonProcessingException {

        String json = "{\"squadName\":\"Superherosquad\",\"homeTown\":\"MetroCity\",\"formed\":2016,\"secretBase\":\"Supertower\",\"active\":true,\"members\":[{\"name\":\"MoleculeMan\",\"age\":29,\"secretIdentity\":\"DanJukes\",\"powers\":[\"Radiationresistance\",\"Turningtiny\",\"Radiationblast\"]},{\"name\":\"MadameUppercut\",\"age\":39,\"secretIdentity\":\"JaneWilson\",\"powers\":[\"Milliontonnepunch\",\"Damageresistance\",\"Superhumanreflexes\"]},{\"name\":\"EternalFlame\",\"age\":1000000,\"secretIdentity\":\"Unknown\",\"powers\":[\"Immortality\",\"HeatImmunity\",\"Inferno\",\"Teleportation\",\"Interdimensionaltravel\"]}]}";

        ObjectMapper objectMapper = new ObjectMapper();
        TestDto testDto = objectMapper.readValue(json, TestDto.class);

        System.out.println(testDto);


        System.out.println("================================================");



    }
}
