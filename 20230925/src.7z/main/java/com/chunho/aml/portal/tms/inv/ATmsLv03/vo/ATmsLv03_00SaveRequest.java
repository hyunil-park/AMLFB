package com.chunho.aml.portal.tms.inv.ATmsLv03.vo;

public class ATmsLv03_00SaveRequest {

}
