package com.chunho.aml.portal.kyc.ra.AKycRm05.vo;

import com.chunho.aml.portal.kyc.ra.AKycRm02.vo.AKycRm02_00SaveRequest;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class AKycRm05_00SaveRequest {

	private String chSeq;
	
	private String chCode;
	private String chName;
	
	private String chRisk;
	
	private String useYn;
	
}
