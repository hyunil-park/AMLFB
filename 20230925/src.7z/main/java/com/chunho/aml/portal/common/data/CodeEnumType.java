package com.chunho.aml.portal.common.data;

import lombok.Getter;

/**
 * author         : yejin
 * date           : 2023-07-26
 * description    :  공통으로 사용하는 데이터 (공통코드, 부서, 그룹, ... ) 관련 COMBOBOX의 전체 or 선택 관련 
 * ===========================================================
 * DATE              AUTHOR             NOTE
 * -----------------------------------------------------------
 * 2023-06-20        yejin       최초 생성
 */

public enum CodeEnumType {
    // httpStatus
    ALL("","전체"),
    SELECT("select","선택");

    @Getter
    public  String value;

    @Getter
    public String text;

    CodeEnumType(String value, String text) {
        this.value = value;
        this.text = text;
    }
}
