package com.chunho.aml.portal.login.vo;

import lombok.Getter;
import lombok.Setter;

/**
 * author         : yejin
 * date           : 2023-05-25
 * description    :
 * ===========================================================
 * DATE              AUTHOR             NOTE
 * -----------------------------------------------------------
 * 2023-05-25        yejin       최초 생성
 */
@Getter
@Setter
public class UserVO {

    private String userId;
    private String userName;
    private String password;
    private String departmentCode;
    private String groupCode;
    private String positionCode;
}