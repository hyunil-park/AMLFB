package com.chunho.aml.portal.tms.inv.ATmsLv05.vo;

public class ATmsLv05_00SaveRequest {

}
