package com.chunho.aml.portal.str.investigation.account;

import com.chunho.aml.portal.login.vo.UserVO;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.ToString;

import java.util.List;

@Getter
@ToString
@AllArgsConstructor
@NoArgsConstructor
public class TestDto2 {

    private String name;
    private String age;
    private String secretIdentity;
    private List<String> powers;
}
