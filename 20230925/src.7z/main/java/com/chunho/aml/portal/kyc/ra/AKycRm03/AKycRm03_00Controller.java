package com.chunho.aml.portal.kyc.ra.AKycRm03;

import java.util.HashMap;
import java.util.List;

import javax.validation.Valid;

import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.chunho.aml.common.AjaxResponse;
import com.chunho.aml.common.generic.GenericCollectionResponse;
import com.chunho.aml.common.generic.GenericGridRequest;
import com.chunho.aml.portal.common.data.CodeEnumType;
import com.chunho.aml.portal.common.data.CodeVO;
import com.chunho.aml.portal.common.data.CommonService;
import com.chunho.aml.portal.kyc.ra.AKycRm03.vo.AKycRm03_00Response;
import com.chunho.aml.portal.kyc.ra.AKycRm03.vo.AKycRm03_00SaveRequest;
import com.chunho.aml.portal.kyc.ra.AKycRm03.vo.AKycRm03_00SearchRequest;

import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Controller
@AllArgsConstructor
@RequestMapping("/kyc/ra/AKycRm03")
@Slf4j
public class AKycRm03_00Controller {
	
	private final CommonService commonService;
	private final AKycRm03_00Service service;
	
	// 온로드
	@GetMapping("/list")
	public String index(Model model){
		List<CodeVO> riskLevList = commonService.findriskLevList(CodeEnumType.ALL);
		List<CodeVO> checkYnList = commonService.findcheckYnList(CodeEnumType.ALL);
		List<CodeVO> useYnList = commonService.finduseYnList(CodeEnumType.ALL);
		
		model.addAttribute("riskLevList",riskLevList);
		model.addAttribute("checkYnList",checkYnList);
		model.addAttribute("useYnList",useYnList);
		
        return "kyc/ra/AKycRm03/AKycRm03_00";
    }
	
	// 조회
	@ResponseBody
	@GetMapping("/ajax/search/list")
	public ResponseEntity<GenericCollectionResponse<AKycRm03_00Response>> list(@Valid AKycRm03_00SearchRequest request){
		HashMap<String, List<CodeVO>> codeMap = new HashMap<>();
		codeMap.put("intyRisk",commonService.findriskLevList(CodeEnumType.SELECT));
		codeMap.put("adrRisk",commonService.findcheckYnList(CodeEnumType.SELECT));
		codeMap.put("useYn",commonService.finduseYnList(CodeEnumType.SELECT));
		
		return ResponseEntity.ok(GenericCollectionResponse.<AKycRm03_00Response>builder()
				.gridData(service.findintyList(request))
				.codeData(codeMap)
					.build());
	}
	
	// 저장(신규/수정)
	@ResponseBody
	@PostMapping("/ajax/save")
	public AjaxResponse<Void, Void> save(@RequestBody @Valid GenericGridRequest<AKycRm03_00SaveRequest> request){
		System.out.println(request);
		service.save(request);
		return AjaxResponse.<Void, Void>builder()
				.build();
	}
	
	// 삭제
	@ResponseBody
	@PostMapping("/ajax/delete")
	public AjaxResponse<Void, Void> delete(@RequestBody @Valid GenericGridRequest<AKycRm03_00SaveRequest> request){
		service.delete(request);
		return AjaxResponse.<Void, Void>builder()
				.build();
	}
}
