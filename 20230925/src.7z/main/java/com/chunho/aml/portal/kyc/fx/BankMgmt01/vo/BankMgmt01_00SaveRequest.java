package com.chunho.aml.portal.kyc.fx.BankMgmt01.vo;

public class BankMgmt01_00SaveRequest {

}
