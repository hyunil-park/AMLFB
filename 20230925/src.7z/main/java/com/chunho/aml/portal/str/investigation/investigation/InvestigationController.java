package com.chunho.aml.portal.str.investigation.investigation;

import com.chunho.aml.common.AjaxResponse;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.ibatis.datasource.DataSourceException;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.ModelAndView;

@Controller
@AllArgsConstructor
@RequestMapping(InvestigationController.PATH)
@Slf4j
public class InvestigationController {
    final static String PATH = "str/investigation/investigation";
    private final InvestigationService service;

    @GetMapping("list")
    public String list() {
        //return PATH+"file";
        return "str/investigation/investigation/list";
    }


    @GetMapping("/ajax/search/list")
    @ResponseBody
    public AjaxResponse<Void, Void> list(@RequestParam("searchText") String searchText) {

        if(true){
            throw new DataSourceException("asd");
        }

        return AjaxResponse.<Void, Void>builder()
                .success(true)
                .build();
    }

    @GetMapping("/ajax/search/detail")
    @ResponseBody
    public AjaxResponse<Void, Void> detail(@RequestParam("searchText") String searchText) {

        if(true){
            throw StrReportErrorType.STR001.exception("a","a");
        }

        return AjaxResponse.<Void, Void>builder()
                .success(true)
                .build();
    }


    @GetMapping("/ajax/errorTest1")
    public String errorTest1()  {
        // throw StrReportErrorType.STR001.exception("ss");
        throw new DataSourceException();
    }

    /*
    @GetMapping("test2")
    public String test2() {
        log.info("===test2");
        //return PATH+"file";
        return "str/investigation/index";
    }
*/

    @PostMapping("/ajax/errorTest2")
    @ResponseBody
    public String errorTest2(ModelAndView modelAndView)  {
         throw StrReportErrorType.STR001.exception("ss","DD");
        //throw StrReportErrorType.STR003.exception();
    }

}
