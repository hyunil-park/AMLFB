package com.chunho.aml.portal.kyc.ra.AKycRm08.vo;

public class AKycRm08_00Response {

}
