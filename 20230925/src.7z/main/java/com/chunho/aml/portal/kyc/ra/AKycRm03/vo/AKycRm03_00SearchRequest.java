package com.chunho.aml.portal.kyc.ra.AKycRm03.vo;

import com.chunho.aml.common.generic.SearchConditionVO;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class AKycRm03_00SearchRequest extends SearchConditionVO{

	private String serachType;
	private String serachText;
	private String riskLev;
	private String checkYn;
	private String usedIsyn;
	
}
