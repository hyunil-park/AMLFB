package com.chunho.aml.portal.ops.perm.APermMgmt04.vo;

import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.*;

import java.time.LocalDateTime;

/**
 * author         : yejin
 * date           : 2023-06-20
 * description    :
 * ===========================================================
 * DATE              AUTHOR             NOTE
 * -----------------------------------------------------------
 * 2023-06-20        yejin       최초 생성
 */

@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class APermMgmt04_00Response {
    private String userId;
    private String connectDate;
    private String connectTime;
    private String logType;
    private String requestType;
    private String requestUri;
    private String requestMethod;
    private String clientIp;
    private String errorMessage;
    private String registerId;

    @JsonFormat(shape= JsonFormat.Shape.STRING, pattern="yyyy-MM-dd HH:mm:ss")
    private LocalDateTime registerDateTime;

}
