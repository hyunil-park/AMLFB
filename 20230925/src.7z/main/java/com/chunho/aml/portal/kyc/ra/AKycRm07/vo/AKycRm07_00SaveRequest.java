package com.chunho.aml.portal.kyc.ra.AKycRm07.vo;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class AKycRm07_00SaveRequest {

	private String reguSeq;
	
	private String reguLst;
	
	private String reguAppd;
	private String reguIm;
	
	private String useYn;
	
}
