package com.chunho.aml.portal.ops.perm.APermMgmt01.vo;

import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.*;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Pattern;
import java.time.LocalDateTime;

/**
 * author         : yejin
 * date           : 2023-07-20
 * description    : grid 저장 요청 VO
 * ===========================================================
 * DATE              AUTHOR             NOTE
 * -----------------------------------------------------------
 * 2023-06-20        yejin       최초 생성
 */
@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class APermMgmt01_00SaveRequest {
	
	@NotBlank (message = "message.management.user.field.userId.require")
	@Pattern(regexp = "^[가-힣|a-z|A-Z|0-9]*$", message = "message.management.user.field.userId.regex")
	private String userId;
	@NotBlank (message = "message.management.user.field.userName.require")
	@Pattern(regexp = "^[가-힣|a-z|A-Z|0-9]*$", message = "message.management.user.field.userName.regex")
	private String userName;
	
	private String departmentCode;
	private String positionCode;
	private String groupCode;
	private String useYn;

}
