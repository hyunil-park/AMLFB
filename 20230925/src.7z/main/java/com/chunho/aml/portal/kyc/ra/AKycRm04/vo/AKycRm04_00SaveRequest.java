package com.chunho.aml.portal.kyc.ra.AKycRm04.vo;

import java.time.LocalDateTime;

import com.fasterxml.jackson.annotation.JsonFormat;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class AKycRm04_00SaveRequest {

	private String gsSeq;
	
	private String mcGs;
	private String dtlGs;

	private String gsRisk;
	
	private String useYn;
	
}
