package com.chunho.aml.portal.kyc.ra.AKycRm04.vo;

import com.chunho.aml.common.generic.SearchConditionVO;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class AKycRm04_00SearchRequest extends SearchConditionVO{

	private String mcGs;	
	private String riskLev;
	private String usedIsyn;
	
}
