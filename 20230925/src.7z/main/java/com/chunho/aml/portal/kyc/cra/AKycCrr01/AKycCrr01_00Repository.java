package com.chunho.aml.portal.kyc.cra.AKycCrr01;

public interface AKycCrr01_00Repository {

}
