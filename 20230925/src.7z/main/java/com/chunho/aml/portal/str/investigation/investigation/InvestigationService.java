package com.chunho.aml.portal.str.investigation.investigation;

import com.chunho.aml.portal.str.investigation.investigation.InvestigationRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

/**
 * author         : yejin
 * date           : 2023-05-24
 * description    :
 * ===========================================================
 * DATE              AUTHOR             NOTE
 * -----------------------------------------------------------
 * 2023-05-24        yejin       최초 생성
 */

@Service
@RequiredArgsConstructor
public class InvestigationService {

    private final InvestigationRepository repository;

    public void test(){

        repository.test();

    }

}
