package com.chunho.aml.portal.kyc.ra.AKycRm02;

import org.springframework.stereotype.Service;

import com.chunho.aml.common.SessionInfo;
import com.chunho.aml.common.generic.GenericGridRequest;
import com.chunho.aml.common.generic.GenericGridResponse;
import com.chunho.aml.portal.kyc.ra.AKycRm02.vo.AKycRm02_00Response;
import com.chunho.aml.portal.kyc.ra.AKycRm02.vo.AKycRm02_00SaveRequest;
import com.chunho.aml.portal.kyc.ra.AKycRm02.vo.AKycRm02_00SearchRequest;

import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class AKycRm02_00Service {

	private final AKycRm02_00Repository repository;
	
	public GenericGridResponse<AKycRm02_00Response> findcorpList(AKycRm02_00SearchRequest request) {
		return GenericGridResponse.<AKycRm02_00Response>builder()
				.pageIndex(request.getPageIndex())
				.pageSize(request.getPageSize())
				.totalCount(repository.findTotalCount(request))
				.collection(repository.findcorpList(request))
				.build();
	}

	public void save(GenericGridRequest<AKycRm02_00SaveRequest> request) {
		String sessionUserId = SessionInfo.getSessionUser().getUserId();
		
		request.getCreatedRows().forEach( x-> {
			boolean isExistYn = repository.checkDuplicateCorp(x.getCorpLeGrp(), x.getIcbcCtry());
			
			if(isExistYn){
				throw AKycRm02_00ErrorType.STR001.exception();
			}else{
				repository.create(x, sessionUserId);
			}
		});
		
		request.getUpdatedRows().forEach( x-> {
			boolean isExistYn = repository.checkDuplicateCorp(x.getCorpLeGrp(), x.getIcbcCtry());
			
//			if(isExistYn){
//				throw AKycRm02_00ErrorType.STR001.exception();
//			}else{
				repository.update(x, sessionUserId);
//			}
		});
	}

	public void delete(GenericGridRequest<AKycRm02_00SaveRequest> request) {
		String sessionUserId = SessionInfo.getSessionUser().getUserId();
		
		request.getDeletedRows().forEach( x-> {
			repository.delete(x, sessionUserId);
		});
	}

	 
}
