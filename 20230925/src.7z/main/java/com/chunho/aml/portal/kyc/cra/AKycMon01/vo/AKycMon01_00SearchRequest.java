package com.chunho.aml.portal.kyc.cra.AKycMon01.vo;

import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class AKycMon01_00SearchRequest {

	private String custGcif;
	private String custAbbr;
	private String name_Eng;
	private String custCcif;
	private String exchGcif;
	private String exchAbbr;
	private String syndAbbr;
	private String startDate2;
	private String endDate2;
	private String startDate3;
	private String endDate3;
	
	private String chek_stat1;
	private String chek_stat2;
	private String chek_stat3;
	
	private String chek_risk1;
	private String chek_risk2;
	private String chek_risk3;
	
	private String chek_wlfl1;
	private String chek_wlfl2;
	private String chek_wlfl3;
	private String chek_wlfl4;
	
	private String chek_appl1;
	private String chek_appl2;
	private String chek_appl3;
	
	private String chek_tran1;
	private String chek_tran2;
	private String chek_tran3;
	private String chek_tran4;
	private String chek_tran5;
	
}
