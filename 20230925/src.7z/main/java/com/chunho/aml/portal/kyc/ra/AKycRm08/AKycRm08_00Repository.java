package com.chunho.aml.portal.kyc.ra.AKycRm08;

public interface AKycRm08_00Repository {

}
