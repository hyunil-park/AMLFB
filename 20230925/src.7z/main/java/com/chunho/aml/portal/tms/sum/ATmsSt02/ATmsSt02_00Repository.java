package com.chunho.aml.portal.tms.sum.ATmsSt02;

public interface ATmsSt02_00Repository {

}
