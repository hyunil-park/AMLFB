package com.chunho.aml.portal.kyc.cra.AKycMon01.vo;

import com.chunho.aml.portal.kyc.cra.AKycCdd01.vo.AKycCdd01_00Response;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class AKycMon01_00Response {
	
	private String info_Seq;
	private String custGcif;
	private String custAbbr;
	private String name_Eng;
	private String custCcif;
	private String custStat;
	private String custRisk;
	
	private String applStat;
	private String kyc_Stat;
	private String kycEdate;
	private String kycRdate;
	private String tranGaTp;
	private String kycTdate;
	
	private String exchGcif;
	private String exchAbbr;
	private String syndAbbr;
	
	private String custWlf1;
	private String custWlf2;
	private String custWlf3;
	private String custWlf4;
	
	private String statText;
	private String riskText;
	private String applText;
	private String tranText;

}
