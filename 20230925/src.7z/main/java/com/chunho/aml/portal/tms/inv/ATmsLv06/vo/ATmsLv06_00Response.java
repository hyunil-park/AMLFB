package com.chunho.aml.portal.tms.inv.ATmsLv06.vo;

public class ATmsLv06_00Response {

}
