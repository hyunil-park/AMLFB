package com.chunho.aml.portal.ops.perm.APermMgmt03.vo;

import lombok.*;

import java.io.Serializable;
import java.util.List;

@Getter
@Setter
public class APermMgmt03_00Response implements Serializable {
    private String menuCode;
    private String menuName;
    private String menuPath;
    private int menuOrder;
    private String upMenuCode;
    private int menuDepth;
    private String registerUserId;
    private String modifyUserId;
    private List<APermMgmt03_00Response> _children;
}
