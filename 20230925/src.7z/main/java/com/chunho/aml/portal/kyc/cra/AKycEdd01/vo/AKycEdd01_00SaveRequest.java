package com.chunho.aml.portal.kyc.cra.AKycEdd01.vo;

public class AKycEdd01_00SaveRequest {

}
