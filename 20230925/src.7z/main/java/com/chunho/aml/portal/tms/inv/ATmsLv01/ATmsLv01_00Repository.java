package com.chunho.aml.portal.tms.inv.ATmsLv01;

public interface ATmsLv01_00Repository {

}
