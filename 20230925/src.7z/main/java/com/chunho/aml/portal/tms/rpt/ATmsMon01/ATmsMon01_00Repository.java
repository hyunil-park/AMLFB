package com.chunho.aml.portal.tms.rpt.ATmsMon01;

public interface ATmsMon01_00Repository {

}
