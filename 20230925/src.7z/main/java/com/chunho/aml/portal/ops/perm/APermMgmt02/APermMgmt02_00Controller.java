package com.chunho.aml.portal.ops.perm.APermMgmt02;

import java.util.HashMap;
import java.util.List;

import javax.validation.Valid;

import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.chunho.aml.common.generic.GenericCollectionResponse;
import com.chunho.aml.common.generic.GenericCommonRequest;
import com.chunho.aml.common.generic.GenericGridRequest;
import com.chunho.aml.common.generic.GenericGridResponse;
import com.chunho.aml.common.interceptor.AuthCheckerService;
import com.chunho.aml.portal.common.data.CodeEnumType;
import com.chunho.aml.portal.common.data.CodeVO;
import com.chunho.aml.portal.ops.perm.APermMgmt01.vo.APermMgmt01_00Response;
import com.chunho.aml.portal.ops.perm.APermMgmt01.vo.APermMgmt01_00SearchRequest;
import com.chunho.aml.portal.ops.perm.APermMgmt02.vo.APermMgmt02_00Response;
import com.chunho.aml.portal.ops.perm.APermMgmt02.vo.APermMgmt02_00SearchRequest;
import com.chunho.aml.portal.ops.perm.APermMgmt02.vo.APermMgmt02_01Response;

import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@Controller
@AllArgsConstructor
@RequestMapping("/ops/perm/APermMgmt02")
public class APermMgmt02_00Controller {
	
	private final APermMgmt02_00Service service;
	private final AuthCheckerService authCheckerService;

	@GetMapping("/list")
	public String index(Model model){
		return "ops/perm/APermMgmt02/APermMgmt02_00";
	}

	@ResponseBody
	@GetMapping("/ajax/list")
	public ResponseEntity<GenericCollectionResponse<APermMgmt02_01Response>> groupList(@Valid APermMgmt02_00SearchRequest request){
		return ResponseEntity.ok(GenericCollectionResponse.<APermMgmt02_01Response>builder()
				.gridData(service.groupList(request))
				.build());
	}

	@ResponseBody
	@GetMapping("/ajax/search/list")
	public ResponseEntity<List<APermMgmt02_00Response>> menuList(String groupCode){
		return ResponseEntity.ok(service.menuList(groupCode));
	}

	@ResponseBody
	@PostMapping("/ajax/save")
	public ResponseEntity<Void> save(@RequestBody GenericGridRequest<APermMgmt02_00Response> request){
		service.save(request);
		authCheckerService.refreshMenuAuth();
		return ResponseEntity.ok().build();
	}
	
}
