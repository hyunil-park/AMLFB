package com.chunho.aml.portal.kyc.synd.NCustSynd01;

public interface NCustSynd01_00Repository {

}
