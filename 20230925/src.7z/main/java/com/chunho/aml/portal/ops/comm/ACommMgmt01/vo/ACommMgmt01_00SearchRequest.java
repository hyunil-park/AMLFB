package com.chunho.aml.portal.ops.comm.ACommMgmt01.vo;

import com.chunho.aml.common.generic.SearchConditionVO;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class ACommMgmt01_00SearchRequest extends SearchConditionVO {
	private String commonGroupCode;	
	private String bcodName;
	private String bcodCode;
	private String usedIsyn;
}
