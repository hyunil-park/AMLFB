package com.chunho.aml.portal.common.data;


import org.apache.ibatis.annotations.Mapper;

import java.util.List;

/**
 * author         : yejin
 * date           : 2023-07-05
 * description    : 공통으로 사용하는 데이터 (공통코드, 부서, 그룹, ... ) Repository
 * ===========================================================
 * DATE              AUTHOR             NOTE
 * -----------------------------------------------------------
 * 2023-05-24        yejin       최초 생성
 */

@Mapper
public interface CommonRepository {

    List<CodeVO> findCodeList();
	List<CodeVO> findGroupList();
    List<CodeVO> findDepartmentList();
    List<CodeVO> fnidApproveGroupList();
	List<CodeVO> fnidApproveUserList();
	List<CodeVO> fnidApproveUserList2();
	List<CodeVO> findRptType();		//보고서종류list 추가_20230918
	List<CodeVO> findRptStatus();	//결재상태list 추가_20230918
	List<CodeVO> findProdTypeList();
	List<CodeVO> findTranTpList();
	List<CodeVO> findTranPurpList();
	List<CodeVO> findTranExpCntList();
	List<CodeVO> findTranExpAmountList();
	List<CodeVO> findProdTranChList();
	List<CodeVO> findrestype();
	List<CodeVO> findriskLevList();
	List<CodeVO> finduseYnList();
	List<CodeVO> findFirstApprovalResult(); //검토결과 코드 list 추가_20230918
	List<CodeVO> findcheckYnList();
	List<CodeVO> findmcGsListList();
	List<CodeVO> finddtlGsListList();
	List<CodeVO> findCustStatList();
	List<CodeVO> findCustRiskList();
	List<CodeVO> findApplStatList();
}
