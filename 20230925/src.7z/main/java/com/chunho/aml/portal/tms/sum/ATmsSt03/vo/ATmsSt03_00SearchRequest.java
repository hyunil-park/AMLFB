package com.chunho.aml.portal.tms.sum.ATmsSt03.vo;

public class ATmsSt03_00SearchRequest {

}
