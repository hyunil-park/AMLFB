package com.chunho.aml.portal.tms.sum.ATmsSt02.vo;

public class ATmsSt02_00Response {

}
