package com.chunho.aml.portal.tms.sum.ATmsSt01;

public interface ATmsSt01_00Repository {

}
