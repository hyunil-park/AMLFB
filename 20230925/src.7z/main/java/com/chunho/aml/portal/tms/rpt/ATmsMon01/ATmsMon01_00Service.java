package com.chunho.aml.portal.tms.rpt.ATmsMon01;

public class ATmsMon01_00Service {

}
