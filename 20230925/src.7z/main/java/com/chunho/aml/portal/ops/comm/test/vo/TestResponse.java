package com.chunho.aml.portal.ops.comm.test.vo;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class TestResponse {
	private String userId;
    private String userName;
    private String groupCode;
    private String useYn;
}
