package com.chunho.aml.portal.login;

import com.chunho.aml.common.encrypt.CryptPasswordEncoder;
import com.chunho.aml.portal.login.vo.UserVO;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * author         : yejin
 * date           : 2023-05-25
 * description    :
 * ===========================================================
 * DATE              AUTHOR             NOTE
 * -----------------------------------------------------------
 * 2023-05-25        yejin       최초 생성
 */

@Service
@RequiredArgsConstructor
public class LoginService {
    private final LoginRepository repository;
    private final CryptPasswordEncoder passwordEncoder;
    public UserVO findUserInfo(String id, String password){
        UserVO userInfo = repository.findUserInfo(id);

        if(userInfo != null && passwordEncoder.matches(password, userInfo.getPassword())) {
            return userInfo; // 입력한 비밀번호와 저장소의 비밀번호가 일치
        } else {
            return null;
        }
//        return userInfo;
    }

}
