package com.chunho.aml.portal.ops.comm.ACommMgmt01;

import java.util.List;

import javax.validation.Valid;

import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.chunho.aml.common.AjaxResponse;
import com.chunho.aml.common.generic.GenericCollectionResponse;
import com.chunho.aml.common.generic.GenericCommonRequest;
import com.chunho.aml.common.generic.GenericGridRequest;
import com.chunho.aml.portal.common.data.CodeEnumType;
import com.chunho.aml.portal.common.data.CodeVO;
import com.chunho.aml.portal.common.data.CommonService;
import com.chunho.aml.portal.ops.comm.ACommMgmt01.vo.ACommMgmt01_00Response;
import com.chunho.aml.portal.ops.comm.ACommMgmt01.vo.ACommMgmt01_00SaveRequest;
import com.chunho.aml.portal.ops.comm.ACommMgmt01.vo.ACommMgmt01_00SearchRequest;
import com.chunho.aml.portal.ops.comm.ACommMgmt01.vo.ACommMgmt01_01Response;
import com.chunho.aml.portal.ops.comm.ACommMgmt01.vo.ACommMgmt01_01SaveRequest;

import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Controller
@AllArgsConstructor
@RequestMapping("/ops/comm/ACommMgmt01")
@Slf4j
public class ACommMgmt01_00Controller {
	private final ACommMgmt01_00Service service;
	private final CommonService commonService;
	
	@GetMapping("/list")
	public String index(Model model){
		List<CodeVO> commonGroupList = commonService.findCodeList(CodeEnumType.ALL);
		List<CodeVO> useYnList = commonService.finduseYnList(CodeEnumType.ALL);
		
		model.addAttribute("commonGroupList",commonGroupList);
		model.addAttribute("useYnList",useYnList);
        return "ops/comm/ACommMgmt01/ACommMgmt01_00";
    }
	
	//그룹코드 리스트
	@ResponseBody
	@GetMapping("/ajax/search/group")
	public ResponseEntity<GenericCollectionResponse<ACommMgmt01_00Response>> groupCodeList(@Valid ACommMgmt01_00SearchRequest request){
		return ResponseEntity.ok(GenericCollectionResponse.<ACommMgmt01_00Response>builder()
				.gridData(service.findGroupCodeList(request))
				.build());
	}
	//그룹코드 저장(신규/수정)
	@ResponseBody
	@PostMapping("/ajax/save/group")
	public AjaxResponse<Void, Void> saveGroupCode(@RequestBody @Valid GenericGridRequest<ACommMgmt01_00SaveRequest> request){
		service.saveGroup(request);
		return AjaxResponse.<Void, Void>builder()
				.build();
	}
	
	//그룹코드 삭제
	@ResponseBody
	@PostMapping("/ajax/delete/group")
	public AjaxResponse<Void, Void> deleteGroupCode(@RequestBody GenericGridRequest<ACommMgmt01_00SaveRequest> request){
		service.deleteGroup(request);
		return AjaxResponse.<Void, Void>builder()
				.build();
	}
	
	//공통코드 리스트
	@ResponseBody
	@GetMapping("/ajax/search/commoncode")
	public ResponseEntity<GenericCollectionResponse<ACommMgmt01_01Response>> commonCodeList(@ModelAttribute GenericCommonRequest<Void> request, String bcodCode){
		return ResponseEntity.ok(GenericCollectionResponse.<ACommMgmt01_01Response>builder()
				.gridData(service.findCommonCodeList(request,bcodCode))
				.build());
	}
	//공통코드 저장(신규/수정)
	@ResponseBody
	@PostMapping("/ajax/save/commoncode")
	public ResponseEntity saveCommonCode(@RequestBody @Valid GenericGridRequest<ACommMgmt01_01SaveRequest> request){
		service.saveCommon(request);
		return ResponseEntity.ok().build();
	}
	//공통코드 삭제
	@ResponseBody
	@PostMapping("/ajax/delete/commoncode")
	public ResponseEntity deleteCommonCode(@RequestBody GenericGridRequest<ACommMgmt01_01SaveRequest> request){
		service.deleteCommon(request);
		return ResponseEntity.ok().build();
	}
	
	
	
	
}
