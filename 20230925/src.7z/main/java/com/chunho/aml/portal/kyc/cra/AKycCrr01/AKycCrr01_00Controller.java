package com.chunho.aml.portal.kyc.cra.AKycCrr01;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Controller
@AllArgsConstructor
@RequestMapping("/kyc/cra/AKycCrr01")
@Slf4j
public class AKycCrr01_00Controller {
	
	@GetMapping("/list")
	public String index(Model model){
        return "kyc/cra/AKycCrr01/AKycCrr01_00";
    }
	
	@GetMapping("/pop1")
	public String pop1(Model model){
		System.out.println("산출 결과 팝업");
        return "kyc/cra/AKycCrr01/AKycCrr01_01";
    }
}
