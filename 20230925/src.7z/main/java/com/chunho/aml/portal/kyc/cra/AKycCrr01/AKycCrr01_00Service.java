package com.chunho.aml.portal.kyc.cra.AKycCrr01;

public class AKycCrr01_00Service {

}
