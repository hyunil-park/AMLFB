package com.chunho.aml.portal.str.investigation.account;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.dataformat.xml.XmlMapper;

public class XmlMapperXmlTest {
    public static void main(String[] args) throws JsonProcessingException {

        ObjectMapper xmlMapper = new XmlMapper();


        String xml = ""
                + "<Data>"
                + "    <product>a</product>"
                + "    <product>b</product>"
                + "    <backUrl>www.naver.com</backUrl>"
                + "    <product>c</product>"
                + "    <product>d</product>"
                + "    <backUrl>www.naver.com</backUrl>"
                + "    <product>e</product>"
                + "</Data>";

        XmlMapper m = new XmlMapper();
        // m.setDefaultMergeable(true);
        XmlDto data = m.readValue(xml, XmlDto.class);
        System.out.println(data);
    }
}
