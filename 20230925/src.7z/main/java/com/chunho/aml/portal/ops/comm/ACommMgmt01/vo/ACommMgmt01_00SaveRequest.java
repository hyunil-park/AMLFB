package com.chunho.aml.portal.ops.comm.ACommMgmt01.vo;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Pattern;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class ACommMgmt01_00SaveRequest {
	@NotBlank (message = "message.management.code.field.bcodCode.require")
	@Pattern(regexp = "^[A-Z|0-9]*$", message = "message.management.user.field.bcodCode.regex")
	private String bcodCode;
	
	@NotBlank (message = "message.management.code.field.bcodName.require")
//	@Pattern(regexp = "^[가-힣|a-z|A-Z|0-9]*$", message = "message.management.user.field.bcodName.regex")
	private String bcodName;
	
	private String usedIsyn;
	private String codeEtcs;
}
