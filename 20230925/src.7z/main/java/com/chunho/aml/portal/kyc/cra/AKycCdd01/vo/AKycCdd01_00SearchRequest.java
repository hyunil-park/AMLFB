package com.chunho.aml.portal.kyc.cra.AKycCdd01.vo;

public class AKycCdd01_00SearchRequest {

}
