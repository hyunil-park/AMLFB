package com.chunho.aml.portal.kyc.ra.AKycRm05.vo;

import java.time.LocalDateTime;

import com.chunho.aml.portal.kyc.ra.AKycRm02.vo.AKycRm02_00Response;
import com.fasterxml.jackson.annotation.JsonFormat;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class AKycRm05_00Response {
	
	private String chSeq;
	
	private String chCode;
	private String chName;
	
	private String chRisk;
	
	private String useYn;
	
	private String registeredId;
	private String modifiedId;
	
	@JsonFormat(shape= JsonFormat.Shape.STRING, pattern="yyyy-MM-dd HH:mm:ss")
	private LocalDateTime registerDateTime;
	@JsonFormat(shape= JsonFormat.Shape.STRING, pattern="yyyy-MM-dd HH:mm:ss")
	private LocalDateTime modifyDateTime;
	
}
