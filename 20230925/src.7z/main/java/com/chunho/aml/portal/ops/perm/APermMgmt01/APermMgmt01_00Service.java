package com.chunho.aml.portal.ops.perm.APermMgmt01;


import java.util.List;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.chunho.aml.common.EnvironmentConstants;
import com.chunho.aml.common.SessionInfo;
import com.chunho.aml.common.encrypt.CryptPasswordEncoder;
import com.chunho.aml.common.generic.GenericGridRequest;
import com.chunho.aml.common.generic.GenericGridResponse;
import com.chunho.aml.portal.ops.perm.APermMgmt01.vo.APermMgmt01_00Response;
import com.chunho.aml.portal.ops.perm.APermMgmt01.vo.APermMgmt01_00SaveRequest;
import com.chunho.aml.portal.ops.perm.APermMgmt01.vo.APermMgmt01_00SearchRequest;

import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class APermMgmt01_00Service {

	private final APermMgmt01_00Repository userRepository;
	private final CryptPasswordEncoder passwordEncoder;

	public GenericGridResponse<APermMgmt01_00Response> findUserList(APermMgmt01_00SearchRequest request){
		return GenericGridResponse.<APermMgmt01_00Response>builder()
				.pageIndex(request.getPageIndex())
				.pageSize(request.getPageSize())
				.totalCount(userRepository.findTotalCount(request))
				.collection(userRepository.findUserList(request))
				.build();
	}

	@Transactional
	public void save(GenericGridRequest<APermMgmt01_00SaveRequest> request){
		String sessionUserId = SessionInfo.getSessionUser().getUserId();
	
		request.getCreatedRows().forEach( x-> {
			boolean isExistYn = userRepository.checkDuplicateUserId(x.getUserId());
	
			if(isExistYn){
				throw APermMgmt01_00ErrorType.STR001.exception();
			}else{
				userRepository.createUser(x, sessionUserId);
			}
		});
	
		request.getUpdatedRows().forEach(x-> {
			userRepository.modifyUser(x, sessionUserId);
		});
	}

	@Transactional
	public void delete(GenericGridRequest<APermMgmt01_00SaveRequest> request) {
		String sessionUserId = SessionInfo.getSessionUser().getUserId();
		
		request.getDeletedRows().forEach( x-> {
			userRepository.deleteUser(x, sessionUserId);
		});
	}

	public APermMgmt01_00Response findUserById(String userId) {
		APermMgmt01_00Response user = userRepository.findUserById(userId);
	
		if(user == null) {
			throw APermMgmt01_00ErrorType.STR002.exception(userId);
		}
		return user;
	}

	public void changePassword(String userId, String password) {
		String cryptPassword = passwordEncoder.encode(password);
		userRepository.changePassword(userId, cryptPassword);
	}

	public void initPassword(List<String> userIds) {
    	userIds.forEach( userId-> {
        	userRepository.changePassword(userId, EnvironmentConstants.CommonProperty.DEFAULT_PASSWORD);
        });
	}

}
