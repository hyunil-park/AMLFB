package com.chunho.aml.portal.tms.sum.ATmsSt02;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Controller
@AllArgsConstructor
@RequestMapping("/tms/sum/ATmsSt02")
@Slf4j
public class ATmsSt02_00Controller {
	
	@GetMapping("/list")
	public String index(Model model){
        return "tms/sum/ATmsSt02/ATmsSt02_00";
    }
}
