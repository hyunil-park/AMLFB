package com.chunho.aml.portal.login;

import com.chunho.aml.common.AjaxResponse;
import com.chunho.aml.common.EnvironmentConstants;
import com.chunho.aml.common.exception.CommonErrorType;
import com.chunho.aml.portal.login.vo.UserVO;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.LocaleResolver;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.util.List;
import java.util.Locale;

/**
 * author         : yejin
 * date           : 2023-05-25
 * description    :
 * ===========================================================
 * DATE              AUTHOR             NOTE
 * -----------------------------------------------------------
 * 2023-05-25        yejin       최초 생성
 */

@Controller
@AllArgsConstructor
@Slf4j
public class LoginController {

    private final LoginService loginService;

    private final LocaleResolver localeResolver;


    //private final MessageInjector messageInjector;

//    @GetMapping(value= {"", "/"})
//    public String defaultUrl() throws Exception {
//        return "redirect:/login";
//    }

    @GetMapping(value= {"", "/"})
    public String defaultUrl() throws Exception {
        return "redirect:"+ EnvironmentConstants.CommonProperty.LOGIN_PATH;
    }

    @GetMapping("/login")
    public String login( HttpServletRequest request, Model model , HttpSession session
            , @RequestParam(name = "lang", required = false) String language) {

        if(StringUtils.isEmpty(language)){
            language = EnvironmentConstants.CommonProperty.DEFAULT_LOCALE_KOREAN;
        }

        Locale locale = localeResolver.resolveLocale(request);
        model.addAttribute("lang", locale.toString());

        if(session.getAttribute(EnvironmentConstants.CommonProperty.LOGIN_USER_SESSION_NAME) != null){
            return "redirect:/main";
        }
        return "login/login";
    }

    @GetMapping("/login/test")
    public String loginTest(){
        return "login/testlogin";
    }



    @PostMapping("/ajax/login")
    @ResponseBody
    public AjaxResponse loginAjax(@RequestParam("userId") String id
            , @RequestParam("userPassword") String password
            , @RequestParam("lang") String language
            , HttpSession session
            ,HttpServletRequest request
            ,HttpServletResponse response) {

        /*
        String returnURL = "login/login";

        UserVO userInfo = loginService.findUserInfo(id, password);
        if(userInfo != null){
            session.setAttribute("login", userInfo);
            returnURL = "redirect:/main";
        }

       return returnURL
       */

        UserVO userInfo = loginService.findUserInfo(id, password);
        boolean result = false;

        //로그인시 다국어인터셉터이용. 다국어인터셉터에서 로직태우는것으로 수정
        //messageInjector.changeLocale(language);

        if(userInfo == null){
            throw CommonErrorType.LOGIN_FAIL.exception();
        }

        //세션세팅
        session.setAttribute(EnvironmentConstants.CommonProperty.LOGIN_USER_SESSION_NAME, userInfo);

        //언어세팅
        localeResolver.setLocale(request,response,new Locale(language));
        //session.setAttribute(SessionLocaleResolver.LOCALE_SESSION_ATTRIBUTE_NAME, new Locale(language));


        return AjaxResponse.<UserVO, Void>builder()
                .success(true)
                .param(userInfo)
                .build();
    }

    @PostMapping("/ajax/logout")
    @ResponseBody
    public AjaxResponse<Void, Void> logoutAction(HttpSession session) {
        session.invalidate();
        log.info("SESSION ===> REMOVE");
        return AjaxResponse.<Void, Void>builder()
                .success(true)
                .build();
    }

    @PostMapping(value = "/ajax/changeLocale")
    @ResponseBody
    public AjaxResponse<Void, Void> changeLocale(HttpServletResponse response, HttpSession session, @RequestParam(required = true) String language, HttpServletRequest request)  {

        log.info("locale setting change : {}", language);
        if(StringUtils.isEmpty(language)){
            language = EnvironmentConstants.CommonProperty.DEFAULT_LOCALE_KOREAN;
        }
        localeResolver.setLocale(request,response,new Locale(language));
       //session.setAttribute(SessionLocaleResolver.LOCALE_SESSION_ATTRIBUTE_NAME, new Locale(language));
       // messageInjector.changeLocale(language);


        return AjaxResponse.<Void, Void>builder()
                .success(true)
                .build();
    }


}
