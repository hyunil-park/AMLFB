package com.chunho.aml.portal.ops.perm.APermMgmt04.vo;

import com.chunho.aml.common.generic.SearchConditionVO;
import lombok.*;

/**
 * author         : yejin
 * date           : 2023-06-20
 * description    :
 * ===========================================================
 * DATE              AUTHOR             NOTE
 * -----------------------------------------------------------
 * 2023-06-20        yejin       최초 생성
 */

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class APermMgmt04_00SearchRequest extends SearchConditionVO {
    private String userId; //접속자 ID
    private String errorYn; //접속자 ID
}
