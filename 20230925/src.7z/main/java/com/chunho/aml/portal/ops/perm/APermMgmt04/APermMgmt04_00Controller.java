package com.chunho.aml.portal.ops.perm.APermMgmt04;

import javax.validation.Valid;

import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.chunho.aml.common.generic.GenericCollectionResponse;
import com.chunho.aml.portal.ops.perm.APermMgmt04.vo.APermMgmt04_00Response;
import com.chunho.aml.portal.ops.perm.APermMgmt04.vo.APermMgmt04_00SearchRequest;

import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Controller
@AllArgsConstructor
@RequestMapping(APermMgmt04_00Controller.PATH)
@Slf4j
public class APermMgmt04_00Controller {
    final static String PATH = "ops/perm/APermMgmt04";

    private final APermMgmt04_00Service logService;

    @GetMapping("list")
    public String list() {
        //return PATH+"file";
        return "ops/perm/APermMgmt04/APermMgmt04_00";
    }

    @GetMapping("/ajax/search/list")
    @ResponseBody
    public ResponseEntity<GenericCollectionResponse<APermMgmt04_00Response>>list(@Valid APermMgmt04_00SearchRequest request) {
        return ResponseEntity.ok(GenericCollectionResponse.<APermMgmt04_00Response>builder()
                .gridData(logService.findLogList(request)).build());

    }

}
