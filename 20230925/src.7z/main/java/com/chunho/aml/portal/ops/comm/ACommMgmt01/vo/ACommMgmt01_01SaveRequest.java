package com.chunho.aml.portal.ops.comm.ACommMgmt01.vo;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Pattern;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class ACommMgmt01_01SaveRequest {
	private String bcodCode;
	private String bcodName;
	
	@NotBlank (message = "message.management.code.field.codeCode.require")
    @Pattern(regexp = "^[A-Z|0-9|_]*$", message = "message.management.user.field.codeCode.regex")
	private String codeCode;
	
	@NotBlank (message = "message.management.code.field.codeName.require")
//    @Pattern(regexp = "^[가-힣|a-z|A-Z|0-9]*$", message = "message.management.code.field.codeName.regex")
	private String codeName;
	
	private String usedIsyn;
	
	private String codeEtcs;
	private String codeTco1;
	private String codeTco2;
	private String codeTco3;
	private String codeTco4;
}
