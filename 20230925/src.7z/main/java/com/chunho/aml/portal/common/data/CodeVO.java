package com.chunho.aml.portal.common.data;

import lombok.Builder;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Builder
public class CodeVO {
    private String text;
    private String value;
}
