package com.chunho.aml.portal.kyc.ra.AKycRm04;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;

import com.chunho.aml.portal.kyc.ra.AKycRm04.vo.AKycRm04_00Response;
import com.chunho.aml.portal.kyc.ra.AKycRm04.vo.AKycRm04_00SaveRequest;
import com.chunho.aml.portal.kyc.ra.AKycRm04.vo.AKycRm04_00SearchRequest;

@Mapper
public interface AKycRm04_00Repository {

	List<AKycRm04_00Response> findgsList(AKycRm04_00SearchRequest request);
	int findTotalCount(AKycRm04_00SearchRequest request);
	
	boolean checkDuplicateGs(String mcGs, String dtlGs);
	
	void create(AKycRm04_00SaveRequest AKycRm04SaveRequest, String sessionUserId);
	void update(AKycRm04_00SaveRequest AKycRm04SaveRequest, String sessionUserId);
	void delete(AKycRm04_00SaveRequest AKycRm04SaveRequest, String sessionUserId);
	

}
