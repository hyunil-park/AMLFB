package com.chunho.aml.portal.kyc.ra.AKycRm03.vo;

import com.chunho.aml.portal.kyc.ra.AKycRm02.vo.AKycRm02_00SaveRequest;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class AKycRm03_00SaveRequest {

	private String intySeq;
	
	private String bojCode;
	private String bojName;
	
	private String intyRisk;
	private String adrRisk;
	
	private String useYn;
	
}
