package com.chunho.aml.portal.tms.rule.ATmsRl01;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Controller
@AllArgsConstructor
@RequestMapping("/tms/rule/ATmsRl01")
@Slf4j
public class ATmsRl01_00Controller {
	
	@GetMapping("/list")
	public String index(Model model){
        return "tms/rule/ATmsRl01/ATmsRl01_00";
    }
}
