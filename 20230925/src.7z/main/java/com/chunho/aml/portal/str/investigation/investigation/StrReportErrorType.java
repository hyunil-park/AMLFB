package com.chunho.aml.portal.str.investigation.investigation;

import com.chunho.aml.common.exception.BusinessErrorCode;
import com.chunho.aml.common.exception.BusinessErrorCodeException;
import com.chunho.aml.common.utils.MessageUtil;
import lombok.Getter;

import java.util.function.BiFunction;

public enum StrReportErrorType implements BusinessErrorCode {
    // httpStatus
    STR001("message.str.report.error1"
            , (a,b) -> BusinessErrorCodeException.OK.httpStatus(a,b)),
    STR002("message.str.report.error2"
            , BusinessErrorCodeException.OK::httpStatus),
    STR003("message.str.report.error3"
            , BusinessErrorCodeException.OK::httpStatus);

    @Getter
    public final String code;

    @Getter
    public String message;

    StrReportErrorType( String code, BiFunction<BusinessErrorCode, Object[], BusinessErrorCodeException> exception) {
        this.code = code;
        this.exception = exception;
    }

    private final BiFunction<BusinessErrorCode, Object[], BusinessErrorCodeException> exception;

    public BusinessErrorCodeException exception(Object... args) {
        this.message = MessageUtil.getMessage(this.code,args);
        return exception.apply(this, args);
    }


}
