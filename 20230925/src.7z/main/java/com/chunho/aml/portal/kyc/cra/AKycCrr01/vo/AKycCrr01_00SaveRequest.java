package com.chunho.aml.portal.kyc.cra.AKycCrr01.vo;

public class AKycCrr01_00SaveRequest {

}
