package com.chunho.aml.portal.kyc.ra.AKycRm05;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;

import com.chunho.aml.portal.kyc.ra.AKycRm05.vo.AKycRm05_00Response;
import com.chunho.aml.portal.kyc.ra.AKycRm05.vo.AKycRm05_00SaveRequest;
import com.chunho.aml.portal.kyc.ra.AKycRm05.vo.AKycRm05_00SearchRequest;

@Mapper
public interface AKycRm05_00Repository {

	List<AKycRm05_00Response> findchList(AKycRm05_00SearchRequest request);
	int findTotalCount(AKycRm05_00SearchRequest request);
	
	boolean checkDuplicateCh(String chCode);
	
	void create(AKycRm05_00SaveRequest AKycRm05SaveRequest, String sessionUserId);
	void update(AKycRm05_00SaveRequest AKycRm05SaveRequest, String sessionUserId);
	void delete(AKycRm05_00SaveRequest AKycRm05SaveRequest, String sessionUserId);
	
}
