package com.chunho.aml.portal.tms.inv.ATmsLv03;

public interface ATmsLv03_00Repository {

}
