package com.chunho.aml.portal.kyc.cra.AKycCrr01;

import java.util.function.BiFunction;

import com.chunho.aml.common.exception.BusinessErrorCode;
import com.chunho.aml.common.exception.BusinessErrorCodeException;
import com.chunho.aml.common.utils.MessageUtil;

import lombok.Getter;

public enum AKycCrr01_00ErrorType implements BusinessErrorCode {
    // httpStatus
    STR001("message.management.code.duplicate"
            , (a,b) -> BusinessErrorCodeException.OK.httpStatus(a,b)),
	STR002("message.management.code.no.exist"
            , (a,b) -> BusinessErrorCodeException.OK.httpStatus(a,b));
    @Getter
    public final String code;

    @Getter
    public String message;

    AKycCrr01_00ErrorType(String code, BiFunction<BusinessErrorCode, Object[], BusinessErrorCodeException> exception) {
        this.code = code;
        this.exception = exception;
    }

    private final BiFunction<BusinessErrorCode, Object[], BusinessErrorCodeException> exception;

    public BusinessErrorCodeException exception(Object... args) {
        this.message = MessageUtil.getMessage(this.code,args);
        return exception.apply(this, args);
    }


}
