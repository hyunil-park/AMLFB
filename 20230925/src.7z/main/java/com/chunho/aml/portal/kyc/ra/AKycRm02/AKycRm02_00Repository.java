package com.chunho.aml.portal.kyc.ra.AKycRm02;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;

import com.chunho.aml.portal.kyc.ra.AKycRm02.vo.AKycRm02_00Response;
import com.chunho.aml.portal.kyc.ra.AKycRm02.vo.AKycRm02_00SaveRequest;
import com.chunho.aml.portal.kyc.ra.AKycRm02.vo.AKycRm02_00SearchRequest;

@Mapper
public interface AKycRm02_00Repository {

	List<AKycRm02_00Response> findcorpList(AKycRm02_00SearchRequest request);
	int findTotalCount(AKycRm02_00SearchRequest request);
	
	boolean checkDuplicateCorp(String corpLeGrp, String icbcCtry);
	
	void create(AKycRm02_00SaveRequest AKycRm02SaveRequest, String sessionUserId);
	void update(AKycRm02_00SaveRequest AKycRm02SaveRequest, String sessionUserId);
	void delete(AKycRm02_00SaveRequest AKycRm02SaveRequest, String sessionUserId);
	
}
