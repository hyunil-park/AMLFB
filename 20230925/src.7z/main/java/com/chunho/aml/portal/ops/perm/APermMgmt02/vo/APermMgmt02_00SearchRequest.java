package com.chunho.aml.portal.ops.perm.APermMgmt02.vo;

import com.chunho.aml.common.generic.SearchConditionVO;
import lombok.*;

/**
 * author         : yejin
 * date           : 2023-07-19
 * description    : grid 조회시 검색조건 요청 VO - SearchConditionVO 상속
 * ===========================================================
 * DATE              AUTHOR             NOTE
 * -----------------------------------------------------------
 * 2023-06-20        yejin       최초 생성
 */
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class APermMgmt02_00SearchRequest extends SearchConditionVO {
	
	private String text;

}
