package com.chunho.aml.portal.ops.perm.APermMgmt03.enums;

import com.chunho.aml.common.exception.BusinessErrorCode;
import com.chunho.aml.common.exception.BusinessErrorCodeException;
import com.chunho.aml.common.utils.MessageUtil;
import lombok.Getter;

import java.util.function.BiFunction;

public enum APermMgmt03_00ErrorType implements BusinessErrorCode {
    // httpStatus
    MAN001("message.management.auth.menu.error1"
            , BusinessErrorCodeException.OK::httpStatus);

    @Getter
    public final String code;

    @Getter
    public String message;

    APermMgmt03_00ErrorType(String code, BiFunction<BusinessErrorCode, Object[], BusinessErrorCodeException> exception) {
        this.code = code;
        this.exception = exception;
    }

    private final BiFunction<BusinessErrorCode, Object[], BusinessErrorCodeException> exception;

    public BusinessErrorCodeException exception(Object... args) {
        this.message = MessageUtil.getMessage(this.code,args);
        return exception.apply(this, args);
    }


}
