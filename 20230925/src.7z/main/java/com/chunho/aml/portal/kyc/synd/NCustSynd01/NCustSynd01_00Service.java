package com.chunho.aml.portal.kyc.synd.NCustSynd01;

public class NCustSynd01_00Service {

}
