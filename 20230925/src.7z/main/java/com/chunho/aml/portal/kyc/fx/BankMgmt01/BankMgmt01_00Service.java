package com.chunho.aml.portal.kyc.fx.BankMgmt01;

public class BankMgmt01_00Service {

}
