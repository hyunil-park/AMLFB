package com.chunho.aml.portal.tms.rule.ATmsRl02;

public interface ATmsRl02_00Repository {

}
