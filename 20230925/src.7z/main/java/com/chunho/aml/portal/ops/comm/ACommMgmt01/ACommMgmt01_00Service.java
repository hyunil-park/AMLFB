package com.chunho.aml.portal.ops.comm.ACommMgmt01;

import org.springframework.stereotype.Service;

import com.chunho.aml.common.SessionInfo;
import com.chunho.aml.common.generic.GenericCommonRequest;
import com.chunho.aml.common.generic.GenericGridRequest;
import com.chunho.aml.common.generic.GenericGridResponse;
import com.chunho.aml.portal.ops.comm.ACommMgmt01.vo.ACommMgmt01_00Response;
import com.chunho.aml.portal.ops.comm.ACommMgmt01.vo.ACommMgmt01_00SaveRequest;
import com.chunho.aml.portal.ops.comm.ACommMgmt01.vo.ACommMgmt01_00SearchRequest;
import com.chunho.aml.portal.ops.comm.ACommMgmt01.vo.ACommMgmt01_01Response;
import com.chunho.aml.portal.ops.comm.ACommMgmt01.vo.ACommMgmt01_01SaveRequest;

import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class ACommMgmt01_00Service {
	private final ACommMgmt01_00Repository repository;
	
	//그룹코드 리스트
	public GenericGridResponse<ACommMgmt01_00Response> findGroupCodeList(ACommMgmt01_00SearchRequest request) {
		return GenericGridResponse.<ACommMgmt01_00Response>builder()
				.pageIndex(request.getPageIndex())
				.pageSize(request.getPageSize())
				.totalCount(repository.findGroupCodeTotalCount(request))
				.collection(repository.findGroupCodeList(request))
				.build();
	}
	//그룹코드 저장(신규/수정)
	public void saveGroup(GenericGridRequest<ACommMgmt01_00SaveRequest> request) {
		String sessionUserId = SessionInfo.getSessionUser().getUserId();
		
		request.getCreatedRows().forEach( x-> {
			boolean isExistYn = repository.checkDuplicateGroupCode(x.getBcodCode());
			
			if(isExistYn) {
				throw ACommMgmt01_00ErrorType.STR001.exception();
			}else {
				repository.createGroupCode(x, sessionUserId);
			}
		});
		
		request.getUpdatedRows().forEach( x-> {
//			boolean isExistYn = repository.checkDuplicateGroupCode(x.getBcodCode());
//			
//			if(isExistYn) {
//				throw CodeErrorType.STR001.exception();
//			}else {
//				repository.updateGroupCode(x, sessionUserId);
//			}
			repository.updateGroupCode(x, sessionUserId);
		});
	}
	//그룹코드 삭제
	public void deleteGroup(GenericGridRequest<ACommMgmt01_00SaveRequest> request) {
		String sessionUserId = SessionInfo.getSessionUser().getUserId();
		
		request.getDeletedRows().forEach( x-> {
			repository.deleteGroupCode(x, sessionUserId);
		});
	}
	
	//공통코드 리스트
	public GenericGridResponse<ACommMgmt01_01Response> findCommonCodeList(GenericCommonRequest<Void> request, String bcodCode) {
		return GenericGridResponse.<ACommMgmt01_01Response>builder()
				.pageIndex(request.getPageIndex())
				.pageSize(request.getPageSize())
				.totalCount(repository.findCommonCodeTotalCount(bcodCode))
				.collection(repository.findCommonCodeList(request,bcodCode))
				.build();
	}
	//공통코드 저장(신규/수정)
	public void saveCommon(GenericGridRequest<ACommMgmt01_01SaveRequest> request) {
		String sessionUserId = SessionInfo.getSessionUser().getUserId();
		
		request.getCreatedRows().forEach( x-> {
			boolean isExistYn = repository.checkDuplicateCommonCode(x.getBcodCode(), x.getCodeCode());
			
			if(isExistYn) {
				throw ACommMgmt01_00ErrorType.STR001.exception();
			}else {
				repository.createCommonCode(x, sessionUserId);
			}
		});
		
		request.getUpdatedRows().forEach( x-> {
			repository.updateCommonCode(x, sessionUserId);
		});
	}

	//공통코드 삭제
	public void deleteCommon(GenericGridRequest<ACommMgmt01_01SaveRequest> request) {
		String sessionUserId = SessionInfo.getSessionUser().getUserId();
		
		request.getDeletedRows().forEach( x-> {
			repository.deleteCommonCode(x, sessionUserId);
		});
	}


}