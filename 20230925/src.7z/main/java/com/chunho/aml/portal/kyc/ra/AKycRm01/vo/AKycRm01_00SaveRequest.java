package com.chunho.aml.portal.kyc.ra.AKycRm01.vo;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class AKycRm01_00SaveRequest {
	
	private String ctrySeq;
	
	private String isoCode;
	private String icbcCode;
	private String ctryName;

	private String cttyRisk;
	
	private String useYn;
}
