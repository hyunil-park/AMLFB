package com.chunho.aml.portal.kyc.cra.AKycCdd01;

import java.util.HashMap;
import java.util.List;

import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.chunho.aml.common.generic.GenericCollectionResponse;
import com.chunho.aml.portal.common.data.CodeEnumType;
import com.chunho.aml.portal.common.data.CodeVO;
import com.chunho.aml.portal.common.data.CommonService;
import com.chunho.aml.portal.kyc.cra.AKycCdd01.vo.AKycCdd01_00Response;

import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Controller
@AllArgsConstructor
@RequestMapping("/kyc/cra/AKycCdd01")
@Slf4j
public class AKycCdd01_00Controller {
	private final CommonService commonService;
	private final AKycCdd01_00Service Service;
	
	@GetMapping("/list")
	public String index(Model model, @RequestParam(value="info_Seq", required=false) String info_Seq ){
		List<CodeVO> PROD_TYPE = commonService.findProdTypeList(CodeEnumType.SELECT);
		List<CodeVO> TRAN_TP = commonService.findTranTpList(CodeEnumType.SELECT);
		List<CodeVO> TRAN_PURP = commonService.findTranPurpList(CodeEnumType.SELECT);
		List<CodeVO> TRAN_EXP_CNT = commonService.findTranExpCntList(CodeEnumType.SELECT);
		List<CodeVO> TRAN_EXP_AMOUNT = commonService.findTranExpAmountList(CodeEnumType.SELECT);
		List<CodeVO> PROD_TRAN_CH = commonService.findProdTranChList(CodeEnumType.SELECT);
		
		model.addAttribute("PROD_TYPE",PROD_TYPE);
		model.addAttribute("TRAN_TP",TRAN_TP);
		model.addAttribute("TRAN_PURP",TRAN_PURP);
		model.addAttribute("TRAN_EXP_CNT",TRAN_EXP_CNT);
		model.addAttribute("TRAN_EXP_AMOUNT",TRAN_EXP_AMOUNT);
		model.addAttribute("PROD_TRAN_CH",PROD_TRAN_CH);
		model.addAttribute("info_Seq",info_Seq);
		
		System.out.println("model>>>>>>>>>>>>>>>>>>>>>"+model);
		System.out.println("info_Seq>>>>>>>>>>>>>>>>>>>>>"+info_Seq);
		
        return "kyc/cra/AKycCdd01/AKycCdd01_00";
    }
	
	@ResponseBody
	@GetMapping("/ajax/prodtype/list")
	public ResponseEntity<GenericCollectionResponse<AKycCdd01_00Response>> prodtype(){
		HashMap<String, List<CodeVO>> codeMap = new HashMap<>();
		codeMap.put("PROD_TYPE",commonService.findProdTypeList(CodeEnumType.SELECT));
		codeMap.put("TRAN_TP",commonService.findTranTpList(CodeEnumType.SELECT));
		codeMap.put("TRAN_PURP",commonService.findTranPurpList(CodeEnumType.SELECT));
		codeMap.put("TRAN_EXP_CNT",commonService.findTranExpCntList(CodeEnumType.SELECT));
		codeMap.put("TRAN_EXP_AMOUNT",commonService.findTranExpAmountList(CodeEnumType.SELECT));
		codeMap.put("PROD_TRAN_CH",commonService.findProdTranChList(CodeEnumType.SELECT));
		codeMap.put("RES_TYPE",commonService.findrestype(CodeEnumType.SELECT));
		
		return ResponseEntity.ok(GenericCollectionResponse.<AKycCdd01_00Response>builder()
				.gridData(Service.prodtype())
				.codeData(codeMap).build());
	}
	
	@ResponseBody
	@GetMapping("/ajax/search/list")
	public String model() {
		System.out.println("!!");
		return null;
	}
	
	
	
	
	
	
	
//	public ResponseEntity<GenericCollectionResponse<APermMgmt03_00Response>> menuList(){
//        return ResponseEntity.ok(service.menuList());
//    }
//	
//	public ResponseEntity<GenericCollectionResponse<APermMgmt01_00Response>> list(@Valid APermMgmt01_00SearchRequest request) {
//        HashMap<String, List<CodeVO>> codeMap = new HashMap<>();
//        codeMap.put("groupCode",commonService.findGroupList(CodeEnumType.SELECT));
//        codeMap.put("departmentCode",commonService.findDepartmentList(CodeEnumType.SELECT));
//
//        return ResponseEntity.ok(GenericCollectionResponse.<APermMgmt01_00Response>builder()
//                .gridData(userService.findUserList(request))
//                        .codeData(codeMap).build());
//
//    }
	
	@GetMapping("/pop1")
	public String pop1(Model model){
		System.out.println("고객 관계 종료/거절 팝업");
        return "kyc/cra/AKycCdd01/AKycCdd01_01";
    }
	
	@GetMapping("/pop2")
	public String pop2(Model model){
		System.out.println("작성/수정 팝업");
        return "kyc/cra/AKycCdd01/AKycCdd01_02";
    }
	
	@GetMapping("/pop3")
	public String pop3(Model model){
		System.out.println("기한 연장 신청 팝업");
        return "kyc/cra/AKycCdd01/AKycCdd01_03";
    }
	
	@GetMapping("/pop4")
	public String pop4(Model model){
		System.out.println("저장 팝업");
        return "kyc/cra/AKycCdd01/AKycCdd01_04";
    }
	
//	===========================================================	
	@GetMapping("/pop5")
	public String pop5(Model model){
		System.out.println("저장 팝업");
        return "common/pop01";
    }
	
	@GetMapping("/pop6")
	public String pop6(Model model){
		System.out.println("저장 팝업");
        return "common/pop02";
    }
	
	@GetMapping("/pop7")
	public String pop7(Model model){
		System.out.println("저장 팝업");
        return "common/pop03";
    }
	
	@GetMapping("/pop8")
	public String pop8(Model model){
		System.out.println("저장 팝업");
        return "common/pop04";
    }
	
	@GetMapping("/pop9")
	public String pop9(Model model){
		System.out.println("저장 팝업");
        return "common/pop05";
    }
	
	
}
