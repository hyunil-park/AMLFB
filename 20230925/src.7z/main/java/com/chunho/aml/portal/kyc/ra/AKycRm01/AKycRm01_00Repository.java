package com.chunho.aml.portal.kyc.ra.AKycRm01;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;

import com.chunho.aml.portal.kyc.ra.AKycRm01.vo.AKycRm01_00Response;
import com.chunho.aml.portal.kyc.ra.AKycRm01.vo.AKycRm01_00SaveRequest;
import com.chunho.aml.portal.kyc.ra.AKycRm01.vo.AKycRm01_00SearchRequest;

@Mapper
public interface AKycRm01_00Repository {

	List<AKycRm01_00Response> findctryList(AKycRm01_00SearchRequest request);
	int findTotalCount(AKycRm01_00SearchRequest request);

	boolean checkDuplicateCtry(String isoCode, String icbcCode);

	void create(AKycRm01_00SaveRequest AKycRm01SaveRequest, String sessionUserId);
	void update(AKycRm01_00SaveRequest AKycRm01SaveRequest, String sessionUserId);
	void delete(AKycRm01_00SaveRequest AKycRm01SaveRequest, String sessionUserId);
	
}
