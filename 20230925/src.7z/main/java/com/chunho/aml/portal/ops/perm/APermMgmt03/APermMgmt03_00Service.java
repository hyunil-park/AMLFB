package com.chunho.aml.portal.ops.perm.APermMgmt03;

import java.util.List;

import org.springframework.stereotype.Service;

import com.chunho.aml.common.SessionInfo;
import com.chunho.aml.common.generic.GenericCollectionResponse;
import com.chunho.aml.common.generic.GenericGridRequest;
import com.chunho.aml.common.generic.GenericGridResponse;
import com.chunho.aml.portal.ops.perm.APermMgmt03.enums.APermMgmt03_00ErrorType;
import com.chunho.aml.portal.ops.perm.APermMgmt03.vo.APermMgmt03_00Response;
import com.chunho.aml.portal.ops.perm.APermMgmt03.vo.APermMgmt03_00Request;

import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class APermMgmt03_00Service {
    private final APermMgmt03_00Repository repository;

    public GenericCollectionResponse<APermMgmt03_00Response> menuList(){
        return GenericCollectionResponse.<APermMgmt03_00Response>builder()
                .gridData(GenericGridResponse.<APermMgmt03_00Response>builder()
                        .collection(repository.findAllMenuTree())
                        .totalCount(repository.menuCount())
                        .build())
                .build();
    }

    public void save(GenericGridRequest<APermMgmt03_00Request> request){
        String userId = SessionInfo.getSessionUser().getUserId();
        createMenu(request.getCreatedRows(),userId);
        updateMenu(request.getUpdatedRows(),userId);
    }
    private void createMenu(List<APermMgmt03_00Request> request, String userId){
        for (APermMgmt03_00Request menuSaveRequest : request){
            if(repository.isExistMenu(menuSaveRequest)){
                throw APermMgmt03_00ErrorType.MAN001.exception(menuSaveRequest.getMenuCode());
            } else{
                int result = repository.createMenu(menuSaveRequest,userId);
            }

        }
    }
    private void updateMenu(List<APermMgmt03_00Request> request, String userId){
        for (APermMgmt03_00Request menuSaveRequest : request){
            int result = repository.updateMenu(menuSaveRequest,userId);
        }
    }
    public void delete(List<APermMgmt03_00Request> request){
        String userId = SessionInfo.getSessionUser().getUserId();
        for (APermMgmt03_00Request menuSaveRequest : request){
            int result = repository.deleteMenu(menuSaveRequest,userId);
        }
    }
}
