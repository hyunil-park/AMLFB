package com.chunho.aml.portal.ops.comm.ACommMgmt02;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;

import com.chunho.aml.portal.ops.comm.ACommMgmt02.vo.ACommMgmt02_00FileResponse;
import com.chunho.aml.portal.ops.comm.ACommMgmt02.vo.ACommMgmt02_00Response;
import com.chunho.aml.portal.ops.comm.ACommMgmt02.vo.ACommMgmt02_00SaveRequest;
import com.chunho.aml.portal.ops.comm.ACommMgmt02.vo.ACommMgmt02_00SearchRequest;

@Mapper
public interface ACommMgmt02_00Repository {

	List<ACommMgmt02_00Response> referenceList(ACommMgmt02_00SearchRequest request);
	int referenceTotalCount(ACommMgmt02_00SearchRequest request);
	
	void write(ACommMgmt02_00SaveRequest referenceSaveRequest, String sessionUserId, String sessionUserNa);
	void save(ACommMgmt02_00SaveRequest referenceSaveRequest, String sessionUserId);
	void delete(ACommMgmt02_00SaveRequest referenceSaveRequest, String sessionUserId);
	
	List<ACommMgmt02_00FileResponse> referenceFileList(String rfrcNmbr);
	int referenceFileTotalCount(String rfrcNmbr);
	
	void addfile(String fileName);
	
}
