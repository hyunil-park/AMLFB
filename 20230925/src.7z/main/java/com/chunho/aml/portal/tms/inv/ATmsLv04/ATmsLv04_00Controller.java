package com.chunho.aml.portal.tms.inv.ATmsLv04;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Controller
@AllArgsConstructor
@RequestMapping("/tms/inv/ATmsLv04")
@Slf4j
public class ATmsLv04_00Controller {
	
	@GetMapping("/list")
	public String index(Model model){
        return "tms/inv/ATmsLv04/ATmsLv04_00";
    }
}
