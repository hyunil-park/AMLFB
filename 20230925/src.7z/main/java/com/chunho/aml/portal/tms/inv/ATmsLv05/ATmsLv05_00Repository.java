package com.chunho.aml.portal.tms.inv.ATmsLv05;

public interface ATmsLv05_00Repository {

}
