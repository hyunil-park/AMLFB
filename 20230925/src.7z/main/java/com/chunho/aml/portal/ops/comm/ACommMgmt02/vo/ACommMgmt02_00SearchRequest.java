package com.chunho.aml.portal.ops.comm.ACommMgmt02.vo;

import com.chunho.aml.common.generic.SearchConditionVO;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class ACommMgmt02_00SearchRequest extends SearchConditionVO{
	private String searchselect;	
	private String searchtext;
}
