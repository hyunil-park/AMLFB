package com.chunho.aml.portal.kyc.cra.AKycCdd01;

import org.springframework.stereotype.Service;

import com.chunho.aml.common.encrypt.CryptPasswordEncoder;
import com.chunho.aml.common.generic.GenericGridResponse;
import com.chunho.aml.portal.kyc.cra.AKycCdd01.vo.AKycCdd01_00Response;
import com.chunho.aml.portal.ops.perm.APermMgmt01.APermMgmt01_00Repository;

import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class AKycCdd01_00Service {

	private final AKycCdd01_00Repository Repository;
	
	public GenericGridResponse<AKycCdd01_00Response> prodtype() {
		return GenericGridResponse.<AKycCdd01_00Response>builder()
				.collection(Repository.prodtype())
				.build();
	}

}
