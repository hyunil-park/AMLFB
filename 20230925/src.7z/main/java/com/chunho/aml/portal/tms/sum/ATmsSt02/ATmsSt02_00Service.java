package com.chunho.aml.portal.tms.sum.ATmsSt02;

public class ATmsSt02_00Service {

}
