package com.chunho.aml.portal.kyc.cra.AKycMon01;

import javax.validation.Valid;

import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.chunho.aml.common.generic.GenericCollectionResponse;
import com.chunho.aml.portal.common.data.CommonService;
import com.chunho.aml.portal.kyc.cra.AKycMon01.vo.AKycMon01_00Response;
import com.chunho.aml.portal.kyc.cra.AKycMon01.vo.AKycMon01_00SearchRequest;

import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Controller
@AllArgsConstructor
@RequestMapping("/kyc/cra/AKycMon01")
@Slf4j
public class AKycMon01_00Controller {
	
	private final CommonService commonService;
	private final AKycMon01_00Service service;
	
	// 온로드
	@GetMapping("/list")
	public String index(Model model){
        return "kyc/cra/AKycMon01/AKycMon01_00";
    }
	
	// 조회
	@ResponseBody
	@GetMapping("/ajax/search/list")
	public ResponseEntity<GenericCollectionResponse<AKycMon01_00Response>> list(@Valid AKycMon01_00SearchRequest request){
		
		return ResponseEntity.ok(GenericCollectionResponse.<AKycMon01_00Response>builder()
				.gridData(service.findmonList(request))
					.build());
	}
	
	// cdd 이동
	@GetMapping("/ajax/search/list1")
	public String cdd(Model model, @RequestParam(value="info_Seq", required=false) String info_Seq){
		model.addAttribute("info_Seq",info_Seq);
		System.out.println("info_Seq>>>>>>>>>>>>>>>>>>>>>"+info_Seq);
		return "redirect:kyc/cra/AKycCdd01/AKycCdd01_00";
    }
}
