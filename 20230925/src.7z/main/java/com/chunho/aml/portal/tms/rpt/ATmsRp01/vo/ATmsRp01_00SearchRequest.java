package com.chunho.aml.portal.tms.rpt.ATmsRp01.vo;

import com.chunho.aml.common.generic.SearchConditionVO;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class ATmsRp01_00SearchRequest extends SearchConditionVO {
	
	private String strFrmDate;		//등록일자from
	private String strToDate;		//등록일자to
	private String strCustNo;   	//고객번호
	private String strRptType;		//보고서종류
	private String strRptStatus;	//결재상태
}
