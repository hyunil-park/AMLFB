package com.chunho.aml.portal.kyc.cra.AKycMon01;

import org.springframework.stereotype.Service;

import com.chunho.aml.common.generic.GenericGridResponse;
import com.chunho.aml.portal.kyc.cra.AKycMon01.vo.AKycMon01_00Response;
import com.chunho.aml.portal.kyc.cra.AKycMon01.vo.AKycMon01_00SearchRequest;

import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class AKycMon01_00Service {

	private final AKycMon01_00Repository repository;
	
	public GenericGridResponse<AKycMon01_00Response> findmonList(AKycMon01_00SearchRequest request) {
		return GenericGridResponse.<AKycMon01_00Response>builder()
                .collection(repository.findmonList(request))
                .build();
	}

}
