package com.chunho.aml.portal.ops.perm.APermMgmt01;

import java.util.HashMap;
import java.util.List;

import javax.validation.Valid;

import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.chunho.aml.common.AjaxResponse;
import com.chunho.aml.common.generic.GenericCollectionResponse;
import com.chunho.aml.common.generic.GenericGridRequest;
import com.chunho.aml.portal.common.data.CodeEnumType;
import com.chunho.aml.portal.common.data.CodeVO;
import com.chunho.aml.portal.common.data.CommonService;
import com.chunho.aml.portal.ops.perm.APermMgmt01.vo.APermMgmt01_00Response;
import com.chunho.aml.portal.ops.perm.APermMgmt01.vo.APermMgmt01_00SaveRequest;
import com.chunho.aml.portal.ops.perm.APermMgmt01.vo.APermMgmt01_00SearchRequest;

import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Controller
@AllArgsConstructor
@RequestMapping(APermMgmt01_00Controller.PATH)
@Slf4j
public class APermMgmt01_00Controller {
	
	final static String PATH = "ops/perm/APermMgmt01";
	
	private final APermMgmt01_00Service userService;
	private final CommonService commonService;
	
	@GetMapping("list")
	public String list(Model model) {
		List<CodeVO> departmentList = commonService.findDepartmentList(CodeEnumType.ALL);
		List<CodeVO> useYnList = commonService.finduseYnList(CodeEnumType.ALL);
		
		model.addAttribute("departmentList",departmentList);
		model.addAttribute("useYnList",useYnList);
		return "ops/perm/APermMgmt01/APermMgmt01_00";
	}

	@GetMapping("/ajax/search/list")
	@ResponseBody
	public ResponseEntity<GenericCollectionResponse<APermMgmt01_00Response>> list(@Valid APermMgmt01_00SearchRequest request) {
		HashMap<String, List<CodeVO>> codeMap = new HashMap<>();
		codeMap.put("groupCode",commonService.findGroupList(CodeEnumType.SELECT));
		codeMap.put("departmentCode",commonService.findDepartmentList(CodeEnumType.SELECT));
		codeMap.put("useYn",commonService.finduseYnList(CodeEnumType.SELECT));
		
		return ResponseEntity.ok(GenericCollectionResponse.<APermMgmt01_00Response>builder()
				.gridData(userService.findUserList(request))
				.codeData(codeMap)
				.build());
	}

	@PostMapping("/ajax/save")
	@ResponseBody
	public AjaxResponse<Void,Void> save(@RequestBody @Valid GenericGridRequest<APermMgmt01_00SaveRequest> request) {
		userService.save(request);
		return AjaxResponse.<Void, Void>builder()
				.build();
	}

	@PostMapping("/ajax/delete")
	@ResponseBody
	public AjaxResponse<Void,Void> delete(@RequestBody GenericGridRequest<APermMgmt01_00SaveRequest> request) {
		userService.delete(request);
		return AjaxResponse.<Void, Void>builder()
				.build();
	}

	@GetMapping("/ajax/password/change/view")
	@ResponseBody
	public AjaxResponse<Void,APermMgmt01_00Response> list(@RequestParam String userId) {
		return AjaxResponse.<Void, APermMgmt01_00Response>builder()
				.data(userService.findUserById(userId))
				.build();
	}

	@PostMapping("/ajax/password/change")
	@ResponseBody
	public AjaxResponse<Void,Void> changePassword(@RequestParam String userId, @RequestParam String password) {
		userService.changePassword(userId,password);
		return AjaxResponse.<Void, Void>builder()
				.build();
	}
	
	@PostMapping("/ajax/password/init")
	@ResponseBody
	public AjaxResponse<Void,Void> initPassword(@RequestParam("userIds[]") List<String> userIds) {
		userService.initPassword(userIds);
		return AjaxResponse.<Void, Void>builder()
				.build();
	}
}
