package com.chunho.aml.portal.kyc.cra.AKycAppl01.vo;

public class AKycAppl01_00SearchRequest {

}
