package com.chunho.aml.portal.ops.perm.APermMgmt04;

import org.springframework.stereotype.Service;

import com.chunho.aml.common.generic.GenericGridResponse;
import com.chunho.aml.portal.ops.perm.APermMgmt04.vo.APermMgmt04_00Response;
import com.chunho.aml.portal.ops.perm.APermMgmt04.vo.APermMgmt04_00SearchRequest;

import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class APermMgmt04_00Service {

    private final APermMgmt04_00Repository logRepository;

    public GenericGridResponse<APermMgmt04_00Response> findLogList(APermMgmt04_00SearchRequest request){
        return GenericGridResponse.<APermMgmt04_00Response>builder()
                .pageIndex(request.getPageIndex())
                .pageSize(request.getPageSize())
                .totalCount(logRepository.findTotalCount(request))
                .collection(logRepository.findLogList(request))
                .build();
    }


}
