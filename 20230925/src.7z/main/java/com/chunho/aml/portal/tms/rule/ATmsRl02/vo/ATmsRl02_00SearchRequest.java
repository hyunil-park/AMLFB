package com.chunho.aml.portal.tms.rule.ATmsRl02.vo;

public class ATmsRl02_00SearchRequest {

}
