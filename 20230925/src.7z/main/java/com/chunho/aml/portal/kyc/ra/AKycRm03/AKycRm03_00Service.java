package com.chunho.aml.portal.kyc.ra.AKycRm03;

import javax.validation.Valid;

import org.springframework.stereotype.Service;

import com.chunho.aml.common.SessionInfo;
import com.chunho.aml.common.generic.GenericGridRequest;
import com.chunho.aml.common.generic.GenericGridResponse;
import com.chunho.aml.portal.kyc.ra.AKycRm03.vo.AKycRm03_00Response;
import com.chunho.aml.portal.kyc.ra.AKycRm03.vo.AKycRm03_00SaveRequest;
import com.chunho.aml.portal.kyc.ra.AKycRm03.vo.AKycRm03_00SearchRequest;

import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class AKycRm03_00Service {

	private final AKycRm03_00Repository repository;
	
	public GenericGridResponse<AKycRm03_00Response> findintyList(AKycRm03_00SearchRequest request) {
		return GenericGridResponse.<AKycRm03_00Response>builder()
				.pageIndex(request.getPageIndex())
				.pageSize(request.getPageSize())
				.totalCount(repository.findTotalCount(request))
				.collection(repository.findintyList(request))
				.build();
	}

	public void save(GenericGridRequest<AKycRm03_00SaveRequest> request) {
		String sessionUserId = SessionInfo.getSessionUser().getUserId();
		
		request.getCreatedRows().forEach( x-> {
			boolean isExistYn = repository.checkDuplicateBojCode(x.getBojCode(), x.getBojName());
			
			if(isExistYn) {
				throw AKycRm03_00ErrorType.STR001.exception();
			}else {
				repository.create(x, sessionUserId);
			}
		});
		
		request.getUpdatedRows().forEach( x-> {
			boolean isExistYn = repository.checkDuplicateBojCode(x.getBojCode(), x.getBojName());
			
//			if(isExistYn) {
//				throw AKycRm03_00ErrorType.STR001.exception();
//			}else {
				repository.update(x, sessionUserId);
//			}
		});
	}

	public void delete(GenericGridRequest<AKycRm03_00SaveRequest> request) {
		String sessionUserId = SessionInfo.getSessionUser().getUserId();
		
		request.getDeletedRows().forEach( x-> {
			repository.delete(x, sessionUserId);
		});
	}
	
}
