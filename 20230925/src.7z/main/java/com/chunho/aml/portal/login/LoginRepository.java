package com.chunho.aml.portal.login;

import com.chunho.aml.portal.login.vo.UserVO;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

/**
 * author         : yejin
 * date           : 2023-05-25
 * description    :
 * ===========================================================
 * DATE              AUTHOR             NOTE
 * -----------------------------------------------------------
 * 2023-05-25        yejin       최초 생성
 */

@Mapper
public interface LoginRepository {

    public UserVO findUserInfo(@Param("id") String id);

}
