package com.chunho.aml.portal.tms.rule.ATmsRl01;

public class ATmsRl01_00Service {

}
