package com.chunho.aml.portal.kyc.synd.NCustSynd01.vo;

public class NCustSynd01_00SaveRequest {

}
