package com.chunho.aml.portal.main;

import lombok.AllArgsConstructor;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

/**
 * author         : yejin
 * date           : 2023-05-25
 * description    :
 * ===========================================================
 * DATE              AUTHOR             NOTE
 * -----------------------------------------------------------
 * 2023-05-25        yejin       최초 생성
 */

@Controller
@AllArgsConstructor
public class MainController {


    @GetMapping(value="/main")
    public String main() throws Exception {
        return "main/main";
    }

}
