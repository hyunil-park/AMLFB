package com.chunho.aml.portal.tms.sum.ATmsSt03;

public interface ATmsSt03_00Repository {

}
