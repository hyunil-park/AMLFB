package com.chunho.aml.portal.ops.comm.test;

import org.springframework.stereotype.Service;

import com.chunho.aml.common.SessionInfo;
import com.chunho.aml.common.generic.GenericGridResponse;
import com.chunho.aml.portal.ops.comm.test.vo.TestResponse;

import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class TestService {
	private final TestRepository repository;
	
	public GenericGridResponse<TestResponse> findUserList() {
		String sessionUserId = SessionInfo.getSessionUser().getUserId();
		
		return GenericGridResponse.<TestResponse>builder()
				.collection(repository.findUserList(sessionUserId))
				.build();
	}
}
