package com.chunho.aml.portal.kyc.ra.AKycRm07;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;

import com.chunho.aml.portal.kyc.ra.AKycRm07.vo.AKycRm07_00Response;
import com.chunho.aml.portal.kyc.ra.AKycRm07.vo.AKycRm07_00SaveRequest;
import com.chunho.aml.portal.kyc.ra.AKycRm07.vo.AKycRm07_00SearchRequest;

@Mapper
public interface AKycRm07_00Repository {

	List<AKycRm07_00Response> findreguList(AKycRm07_00SearchRequest request);
	int findTotalCount(AKycRm07_00SearchRequest request);
	
	boolean checkDuplicateRegu(String reguLst);
	
	void create(AKycRm07_00SaveRequest AKycRm07SaveRequest, String sessionUserId);
	void update(AKycRm07_00SaveRequest AKycRm07SaveRequest, String sessionUserId);
	void delete(AKycRm07_00SaveRequest AKycRm07SaveRequest, String sessionUserId);

}
