package com.chunho.aml.portal.tms.rpt.ATmsRp01;

import java.util.List;

import javax.validation.Valid;

import org.apache.ibatis.annotations.Mapper;

import com.chunho.aml.portal.tms.rpt.ATmsRp01.vo.ATmsRp01_00Response;
import com.chunho.aml.portal.tms.rpt.ATmsRp01.vo.ATmsRp01_00SearchRequest;

@Mapper
public interface ATmsRp01_00Repository {

	int findTotalCount(ATmsRp01_00SearchRequest request);

	List<ATmsRp01_00Response> findRp01List(@Valid ATmsRp01_00SearchRequest request);		
}
