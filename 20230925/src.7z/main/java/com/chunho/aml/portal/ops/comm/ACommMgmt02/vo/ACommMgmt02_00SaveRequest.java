package com.chunho.aml.portal.ops.comm.ACommMgmt02.vo;

import javax.validation.constraints.NotBlank;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class ACommMgmt02_00SaveRequest {
	private String rfrcNmbr;
	@NotBlank (message = "message.management.user.field.userId.require")
//	@Pattern(regexp = "^[가-힣|a-z|A-Z|0-9]*$", message = "message.management.user.field.userId.regex")
	private String rfrcTitl;
	
	@NotBlank (message = "message.management.user.field.userName.require")
//	@Pattern(regexp = "^[가-힣|a-z|A-Z|0-9]*$", message = "message.management.user.field.userName.regex")
	private String rfrcCont;
	
}
