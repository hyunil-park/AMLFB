package com.chunho.aml.portal.kyc.fx.BankMgmt01;

public interface BankMgmt01_00Repository {

}
