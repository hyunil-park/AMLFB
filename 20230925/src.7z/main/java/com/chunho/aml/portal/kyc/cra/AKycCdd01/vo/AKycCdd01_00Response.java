package com.chunho.aml.portal.kyc.cra.AKycCdd01.vo;

import java.time.LocalDateTime;

import com.chunho.aml.portal.ops.comm.ACommMgmt01.vo.ACommMgmt01_00Response;
import com.fasterxml.jackson.annotation.JsonFormat;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class AKycCdd01_00Response {
	
	private String prodtype;
	private String trantp;
	private String tranpurp;
	private String tranexpcnt;
	private String tranexpamount;
	private String prodtranch;
	
	
}
