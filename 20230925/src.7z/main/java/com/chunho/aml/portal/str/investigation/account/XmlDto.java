package com.chunho.aml.portal.str.investigation.account;


import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlCData;
import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlElementWrapper;
import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlProperty;
import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlRootElement;
import lombok.ToString;

import java.util.List;

@JacksonXmlRootElement(localName = "data")
@ToString
public class XmlDto {
    @JacksonXmlCData
    @JacksonXmlElementWrapper(useWrapping = false)
    @JacksonXmlProperty
    private List<String> product;

    @JacksonXmlCData
    @JacksonXmlElementWrapper(useWrapping = false)
    @JacksonXmlProperty
    private String backUrl;

    public List<String> getProduct() {
        return product;
    }

    public void setProduct(List<String> product) {
        if (this.product == null) {
            this.product = product;
        } else {
            this.product.addAll(product);
        }
    }

    public String getBackUrl() {
        return backUrl;
    }

    public void setBackUrl(String backUrl) {
        this.backUrl = backUrl;
    }
}
