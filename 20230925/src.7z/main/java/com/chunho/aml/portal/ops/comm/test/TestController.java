package com.chunho.aml.portal.ops.comm.test;

import java.util.HashMap;
import java.util.List;

import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.chunho.aml.common.generic.GenericCollectionResponse;
import com.chunho.aml.portal.common.data.CodeEnumType;
import com.chunho.aml.portal.common.data.CodeVO;
import com.chunho.aml.portal.common.data.CommonService;
import com.chunho.aml.portal.ops.comm.test.vo.TestResponse;

import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Controller
@AllArgsConstructor
@RequestMapping("/ops/comm/test")
@Slf4j
public class TestController {
	private final CommonService commonService;
	private final TestService service;
	
	@GetMapping("/list")
	public String index(Model model) {
		List<CodeVO> approveGroupList = commonService.fnidApproveGroupList(CodeEnumType.ALL);
		System.out.println("NEW~!~~~~~~~~~~~~");
		model.addAttribute("approveGroupList",approveGroupList);
		return "ops/comm/test/approveList";
		/* return "management/common/test/chart"; */
    }
	
	@GetMapping("/ajax/search/list")
    @ResponseBody
    public ResponseEntity<GenericCollectionResponse<TestResponse>> list() {
        HashMap<String, List<CodeVO>> codeMap = new HashMap<>();
        codeMap.put("group1",commonService.fnidApproveGroupList(CodeEnumType.SELECT));
        codeMap.put("group2",commonService.fnidApproveGroupList(CodeEnumType.SELECT));
        codeMap.put("group3",commonService.fnidApproveGroupList(CodeEnumType.SELECT));
        codeMap.put("group4",commonService.fnidApproveGroupList(CodeEnumType.SELECT));
        codeMap.put("group5",commonService.fnidApproveGroupList(CodeEnumType.SELECT));
        codeMap.put("group6",commonService.fnidApproveGroupList(CodeEnumType.SELECT));
        codeMap.put("group7",commonService.fnidApproveGroupList(CodeEnumType.SELECT));
        codeMap.put("group8",commonService.fnidApproveGroupList(CodeEnumType.SELECT));
        codeMap.put("group9",commonService.fnidApproveGroupList(CodeEnumType.SELECT));
        codeMap.put("group10",commonService.fnidApproveGroupList(CodeEnumType.SELECT));

        //codeMap.put("name1",commonService.fnidApproveUserList(CodeEnumType.SELECT));
        //codeMap.put("name2",commonService.fnidApproveUserList(CodeEnumType.SELECT));
        codeMap.put("name3",commonService.fnidApproveUserList(CodeEnumType.SELECT));
        codeMap.put("name4",commonService.fnidApproveUserList(CodeEnumType.SELECT));
        codeMap.put("name5",commonService.fnidApproveUserList(CodeEnumType.SELECT));
        codeMap.put("name6",commonService.fnidApproveUserList(CodeEnumType.SELECT));
        codeMap.put("name7",commonService.fnidApproveUserList(CodeEnumType.SELECT));
        codeMap.put("name8",commonService.fnidApproveUserList(CodeEnumType.SELECT));
        codeMap.put("name9",commonService.fnidApproveUserList(CodeEnumType.SELECT));
        codeMap.put("name10",commonService.fnidApproveUserList(CodeEnumType.SELECT));
        
        codeMap.put("001",commonService.fnidApproveUserList2(CodeEnumType.SELECT));
        
        return ResponseEntity.ok(GenericCollectionResponse.<TestResponse>builder()
                .gridData(service.findUserList())
				.codeData(codeMap)
                        .build());
    }
	
}
