package com.chunho.aml.portal.tms.rpt.ATmsRp01.vo;

import com.fasterxml.jackson.annotation.JsonFormat;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class ATmsRp01_00Response {
	
	private String strId;
	private String workGbn;
	private String workGbnCd;
	private String strStatus;
	private String sta;
	private String updateDate;
	private String updateId;
	private String fileNm;
	@JsonFormat(shape= JsonFormat.Shape.STRING, pattern="yyyy-MM-dd HH:mm:ss")
	private String uptdttm;
	private String custNo;
	private String firstApprovalResult;
	private String firstApprovalComment;
	private String firstApprovalDate;
	private String firstApprovalNm;
	private String ruleId;
	private String custRgstryBrn;
	private String alertId;

}
