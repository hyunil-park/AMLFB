package com.chunho.aml.portal.kyc.cra.AKycWl01.vo;

public class AKycWl01_00SaveRequest {

}
