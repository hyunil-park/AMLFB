package com.chunho.aml.portal.tms.rpt.ATmsRp01.vo;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class ATmsRp01_00SaveRequest {	
	
	private String userName;
	private String useYn;
	private String userId;
	private String departmentCode;
	
	private String positionCode;
	private String groupCode;
}
