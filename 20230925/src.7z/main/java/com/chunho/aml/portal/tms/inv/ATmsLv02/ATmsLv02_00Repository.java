package com.chunho.aml.portal.tms.inv.ATmsLv02;

public interface ATmsLv02_00Repository {

}
