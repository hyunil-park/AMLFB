package com.chunho.aml.portal.ops.comm.ACommMgmt02.vo;

import lombok.Builder;
import lombok.Getter;
import lombok.Setter;

@Builder
@Getter
@Setter
public class ACommMgmt02_00FileResponse {
	private String rfrcNmbr;
	private String fileNmbr;
	private String orgnName;
	private String saveName;
	private String extnName;
	private String fileSize;
	private String downCunt;
	private String registeredId;
	private String regtDtim;
	private String modifiedId;
	private String modiDtim;
}
