package com.chunho.aml.portal.ops.comm.ACommMgmt02;

import org.springframework.stereotype.Service;

import com.chunho.aml.common.SessionInfo;
import com.chunho.aml.common.generic.GenericCommonRequest;
import com.chunho.aml.common.generic.GenericGridRequest;
import com.chunho.aml.common.generic.GenericGridResponse;
import com.chunho.aml.portal.ops.comm.ACommMgmt02.vo.ACommMgmt02_00FileResponse;
import com.chunho.aml.portal.ops.comm.ACommMgmt02.vo.ACommMgmt02_00Response;
import com.chunho.aml.portal.ops.comm.ACommMgmt02.vo.ACommMgmt02_00SaveRequest;
import com.chunho.aml.portal.ops.comm.ACommMgmt02.vo.ACommMgmt02_00SearchRequest;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
@RequiredArgsConstructor
public class ACommMgmt02_00Service {
	private final ACommMgmt02_00Repository repository;

	public GenericGridResponse<ACommMgmt02_00Response> referencelist(ACommMgmt02_00SearchRequest request) {
		return GenericGridResponse.<ACommMgmt02_00Response>builder()
				.pageIndex(request.getPageIndex())
				.pageSize(request.getPageSize())
				.totalCount(repository.referenceTotalCount(request))
				.collection(repository.referenceList(request))
				.build();
	}

	public void write(ACommMgmt02_00SaveRequest request){
		String sessionUserId = SessionInfo.getSessionUser().getUserId();
		String sessionUserNa = SessionInfo.getSessionUser().getUserName();
		
		repository.write(request, sessionUserId, sessionUserNa);
	}
	
	public void save(ACommMgmt02_00SaveRequest request) {
		String sessionUserId = SessionInfo.getSessionUser().getUserId();
		
		repository.save(request, sessionUserId);
	}
	
	public void delete(GenericGridRequest<ACommMgmt02_00SaveRequest> request) {
		String sessionUserId = SessionInfo.getSessionUser().getUserId();
		
		request.getDeletedRows().forEach( x-> {
			repository.delete(x, sessionUserId);
		});
	}

	

	public GenericGridResponse<ACommMgmt02_00FileResponse> referenceFileList(GenericCommonRequest<Void> request, String rfrcNmbr) {
	
		return GenericGridResponse.<ACommMgmt02_00FileResponse>builder()
				.totalCount(repository.referenceFileTotalCount(rfrcNmbr))
				.collection(repository.referenceFileList(rfrcNmbr))
				.build();
	}

	



	

}
