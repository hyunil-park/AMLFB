package com.chunho.aml.portal.tms.inv.ATmsLv04.vo;

public class ATmsLv04_00SaveRequest {

}
