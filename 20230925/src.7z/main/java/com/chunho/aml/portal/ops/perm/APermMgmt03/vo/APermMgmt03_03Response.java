package com.chunho.aml.portal.ops.perm.APermMgmt03.vo;

import lombok.Builder;
import lombok.Getter;
import lombok.Setter;

import java.util.List;

@Getter
@Setter
@Builder
public class APermMgmt03_03Response {
    private String menuCode;
    private String menuName;
    private String menuPath;
    List<APermMgmt03_03Response> childNode;
    @Builder.Default
    private boolean active = false;
}
