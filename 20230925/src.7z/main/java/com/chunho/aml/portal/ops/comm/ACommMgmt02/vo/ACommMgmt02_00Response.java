package com.chunho.aml.portal.ops.comm.ACommMgmt02.vo;

import java.time.LocalDateTime;
import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Builder
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class ACommMgmt02_00Response {
	private String rfrcNmbr;
	private String rfrcTitl;
	private String rfrcCont;
	private String regtDate;
	private String regtName;
	private String deltIsyn;
	private String registeredId;
	private String regtDtim;
	private String modifiedId;
	private String modiDtim;
	
//	private UploadFile attachFile;          // 첨부 파일
//	private List<UploadFile> imageFiles;    // 첨부 이미지
}
