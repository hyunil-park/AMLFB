package com.chunho.aml.portal.ops.comm.ACommMgmt02;

import javax.validation.Valid;

import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.chunho.aml.common.generic.GenericCollectionResponse;
import com.chunho.aml.common.generic.GenericCommonRequest;
import com.chunho.aml.common.generic.GenericGridRequest;
import com.chunho.aml.portal.ops.comm.ACommMgmt02.vo.ACommMgmt02_00FileResponse;
import com.chunho.aml.portal.ops.comm.ACommMgmt02.vo.ACommMgmt02_00Response;
import com.chunho.aml.portal.ops.comm.ACommMgmt02.vo.ACommMgmt02_00SaveRequest;
import com.chunho.aml.portal.ops.comm.ACommMgmt02.vo.ACommMgmt02_00SearchRequest;

import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Controller
@AllArgsConstructor
@RequestMapping("/ops/comm/ACommMgmt02")
@Slf4j
public class ACommMgmt02_00Controller {
	private final ACommMgmt02_00Service service;
	
	@GetMapping("/list")
	public String index(Model model) {
        return "ops/comm/ACommMgmt02/ACommMgmt02_00";
    }
	
	@ResponseBody
	@GetMapping("/ajax/search/list") 
	public ResponseEntity<GenericCollectionResponse<ACommMgmt02_00Response>> referencelist(@Valid ACommMgmt02_00SearchRequest request){
		return ResponseEntity.ok(GenericCollectionResponse.<ACommMgmt02_00Response>builder()
				.gridData(service.referencelist(request)).build());
	}
	
	@ResponseBody
	@PostMapping("/ajax/write")
	public String write(@RequestBody @Valid ACommMgmt02_00SaveRequest request){
		service.write(request);
		return null;
	}
	
	@ResponseBody
	@PostMapping("/ajax/save")
	public String save(@RequestBody @Valid ACommMgmt02_00SaveRequest request){
		service.save(request);
		return null;
	}
	
	@ResponseBody
	@PostMapping("/ajax/delete")
	public ResponseEntity delete(@RequestBody GenericGridRequest<ACommMgmt02_00SaveRequest> request){
			service.delete(request);
		return ResponseEntity.ok().build();
	}
	
	@ResponseBody
	@GetMapping("/ajax/search/file")
	public ResponseEntity<GenericCollectionResponse<ACommMgmt02_00FileResponse>> referenceFileList(@ModelAttribute GenericCommonRequest<Void> request, String rfrcNmbr){
		return ResponseEntity.ok(GenericCollectionResponse.<ACommMgmt02_00FileResponse>builder()
				.gridData(service.referenceFileList(request,rfrcNmbr)).build());
	}
}
