package com.chunho.aml.portal.kyc.cra.AKycWl01;

public interface AKycWl01_00Repository {

}
