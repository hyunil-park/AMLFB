package com.chunho.aml.portal.common.file;

/**
 * author         : yejin
 * date           : 2023-06-13
 * description    : 파일 업로드 다운로드 관련 예외
 * ===========================================================
 * DATE              AUTHOR             NOTE
 * -----------------------------------------------------------
 * 2023-06-13        yejin       최초 생성
 */
public class FileException extends RuntimeException{
    public FileException(String message) {
        super(message);
    }

    public FileException(String message, Throwable cause) {
        super(message, cause);
    }
}
