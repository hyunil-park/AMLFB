package com.chunho.aml.portal.ops.comm.ACommMgmt01.vo;

import java.time.LocalDateTime;

import com.fasterxml.jackson.annotation.JsonFormat;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class ACommMgmt01_00Response {
	private String bcodCode;
	private String bcodName;
	
	private String usedIsyn;
	private String codeEtcs;
	private String codeOrdr;
	
	private String registeredId;
	private String modifiedId;
	
	@JsonFormat(shape= JsonFormat.Shape.STRING, pattern="yyyy-MM-dd HH:mm:ss")
	private LocalDateTime registerDateTime;
	@JsonFormat(shape= JsonFormat.Shape.STRING, pattern="yyyy-MM-dd HH:mm:ss")
	private LocalDateTime modifyDateTime;
}
