package com.chunho.aml.portal.tms.inv.ATmsLv06;

public interface ATmsLv06_00Repository {

}
