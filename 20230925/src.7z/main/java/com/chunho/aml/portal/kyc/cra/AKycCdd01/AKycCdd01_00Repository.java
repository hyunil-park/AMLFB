package com.chunho.aml.portal.kyc.cra.AKycCdd01;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;

import com.chunho.aml.portal.kyc.cra.AKycCdd01.vo.AKycCdd01_00Response;

@Mapper
public interface AKycCdd01_00Repository {

	List<AKycCdd01_00Response> prodtype();

}
