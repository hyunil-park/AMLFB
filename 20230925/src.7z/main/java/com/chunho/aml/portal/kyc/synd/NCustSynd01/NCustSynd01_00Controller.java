package com.chunho.aml.portal.kyc.synd.NCustSynd01;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.chunho.aml.portal.kyc.fx.BankMgmt01.BankMgmt01_00Controller;

import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Controller
@AllArgsConstructor
@RequestMapping("/kyc/synd/NCustSynd01")
@Slf4j
public class NCustSynd01_00Controller {

	@GetMapping("/list")
	public String index(Model model){
        return "kyc/synd/NCustSynd01/NCustSynd01_00";
    }
}
