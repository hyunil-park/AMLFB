package com.chunho.aml.portal.ops.perm.APermMgmt02;

import java.util.List;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.chunho.aml.common.SessionInfo;
import com.chunho.aml.common.generic.GenericCommonRequest;
import com.chunho.aml.common.generic.GenericGridRequest;
import com.chunho.aml.common.generic.GenericGridResponse;
import com.chunho.aml.portal.ops.perm.APermMgmt02.vo.APermMgmt02_00Response;
import com.chunho.aml.portal.ops.perm.APermMgmt02.vo.APermMgmt02_00SearchRequest;
import com.chunho.aml.portal.ops.perm.APermMgmt02.vo.APermMgmt02_01Response;

import lombok.RequiredArgsConstructor;
@Service
@RequiredArgsConstructor
public class APermMgmt02_00Service {

	private final APermMgmt02_00Repository repository;
	public GenericGridResponse<APermMgmt02_01Response> groupList(APermMgmt02_00SearchRequest request){
		return GenericGridResponse.<APermMgmt02_01Response>builder()
				.pageIndex(request.getPageIndex())
				.pageSize(request.getPageSize())
				.totalCount(repository.groupTotalCount())
				.collection(repository.groupList(request))
				.build();
	}

	public List<APermMgmt02_00Response> menuList(String groupCode){
		return repository.findAuthMenuTree(groupCode);
    }

	@Transactional
	public void save(GenericGridRequest<APermMgmt02_00Response> request){
		request.getUpdatedRows().forEach(r->{
			r.setUser(SessionInfo.getSessionUser().getUserId());
			repository.save(r);
		});
	}

}
