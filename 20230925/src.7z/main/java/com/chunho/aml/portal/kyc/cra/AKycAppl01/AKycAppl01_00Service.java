package com.chunho.aml.portal.kyc.cra.AKycAppl01;

public class AKycAppl01_00Service {

}
