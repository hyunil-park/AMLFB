package com.chunho.aml.portal.ops.perm.APermMgmt03;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import com.chunho.aml.portal.ops.perm.APermMgmt03.vo.APermMgmt03_00Response;
import com.chunho.aml.portal.ops.perm.APermMgmt03.vo.APermMgmt03_00Request;
import com.chunho.aml.portal.ops.perm.APermMgmt03.vo.APermMgmt03_01Response;

@Mapper
public interface APermMgmt03_00Repository {
    List<APermMgmt03_00Response> menuList();
    Boolean isExistMenu(APermMgmt03_00Request request);
    int createMenu(APermMgmt03_00Request request,String userId);
    int updateMenu(APermMgmt03_00Request request,String userId);
    int deleteMenu(APermMgmt03_00Request request,String userId);
    List<APermMgmt03_00Response> headerMenuList(String groupCode);
    List<String> findAutorizedMenu(@Param("groupCode") String groupCode);
    List<APermMgmt03_00Request> findAllMenu();
    List<APermMgmt03_01Response> findMenuTitle(String groupCode);

    default List<APermMgmt03_00Response> findAllMenuTree(){
        List<APermMgmt03_00Response> menuList = this.menuList();
        menuList.forEach(one->{
            if(one.get_children().isEmpty()){
                one.set_children(null);
            } else{
                one.get_children().forEach(two->{
                    if(two.get_children().isEmpty()) {
                        two.set_children(null);
                    }
                });
            }
        });
        return menuList;
    }

    public int menuCount();
}
