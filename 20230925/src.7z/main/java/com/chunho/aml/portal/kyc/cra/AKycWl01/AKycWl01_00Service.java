package com.chunho.aml.portal.kyc.cra.AKycWl01;

public class AKycWl01_00Service {

}
