package com.chunho.aml.portal.kyc.ra.AKycRm02.vo;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class AKycRm02_00SaveRequest {

	private String corpSeq;
	
	private String corpLeGrp;
	private String icbcCtry;
	
	private String corpRisk;
	private String fieSch;
	
	private String useYn;
	
}
