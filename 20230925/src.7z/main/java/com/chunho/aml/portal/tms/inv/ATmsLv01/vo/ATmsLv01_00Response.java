package com.chunho.aml.portal.tms.inv.ATmsLv01.vo;

public class ATmsLv01_00Response {

}
