package com.chunho.aml.portal.common.file;

import com.chunho.aml.portal.common.file.service.FileService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.Resource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;

import javax.servlet.http.HttpServletRequest;
import java.io.IOException;
import java.net.URLEncoder;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

/**
 * author         : yejin
 * date           : 2023-06-13
 * description    : 파일 업로드 다운로드 기능 예제
 * ===========================================================
 * DATE              AUTHOR             NOTE
 * -----------------------------------------------------------
 * 2023-06-13        yejin       최초 생성
 */

@Controller
@Slf4j
public class FileController {
    private final FileService fileService;

    @Autowired
    public FileController(FileService fileService) {
        this.fileService = fileService;
    }

    @GetMapping("fileExample1")
    public String fileExample1(){
        return "example/file/fileExample1";
    }

    @GetMapping("fileExample2")
    public String fileExample2(){
        return "example/file/fileExample2";
    }


    //단일 파일 업로드
    @PostMapping("/uploadFile")
    @ResponseBody
    public FileUploadVO uploadFile(@RequestParam("file1") MultipartFile file) {
        String fileName = fileService.storeFile(file);

        String fileDownloadUri = ServletUriComponentsBuilder.fromCurrentContextPath()
                .path("/downloadFile/")
                .path(fileName)
                .toUriString();

        return new FileUploadVO(fileName, fileDownloadUri,
                file.getContentType(), file.getSize());
    }
    // 다중
    @PostMapping("/uploadMultipleFiles")
    @ResponseBody
    public List<FileUploadVO> uploadMultipleFiles(@RequestParam("files") MultipartFile[] files) {
        return Arrays.asList(files)
                .stream()
                .map(file -> uploadFile(file))
                .collect(Collectors.toList());
    }

    @GetMapping("/downloadFile/{fileName:.+}")
    @ResponseBody
    public ResponseEntity<Resource> downloadFile(@PathVariable String fileName, HttpServletRequest request) {
        // 파일을 Resource타입으로 받아온다.
        Resource resource = fileService.loadFileAsResource(fileName);
        // 파일 content type 확인 (jpg, png 등..)
        String encodedFileName = null;
        String contentType = null;
        try {
            contentType = request.getServletContext().getMimeType(resource.getFile().getAbsolutePath());
            encodedFileName = URLEncoder.encode(resource.getFilename(),"UTF-8").replaceAll("\\+", "%20");
        } catch (IOException ex) {
            log.info("Could not determine file type.");
        }
        // 파일 타입을 알 수 없는 경우의 기본값
        if(contentType == null) {
            contentType = "application/octet-stream";
        }
        return ResponseEntity.ok()
                .contentType(MediaType.parseMediaType(contentType))
                .header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=\"" + encodedFileName + "\"")
                .body(resource);
    }
}
