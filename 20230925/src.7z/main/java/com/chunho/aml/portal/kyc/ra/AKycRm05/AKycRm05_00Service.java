package com.chunho.aml.portal.kyc.ra.AKycRm05;

import javax.validation.Valid;

import org.springframework.stereotype.Service;

import com.chunho.aml.common.SessionInfo;
import com.chunho.aml.common.generic.GenericGridRequest;
import com.chunho.aml.common.generic.GenericGridResponse;
import com.chunho.aml.portal.kyc.ra.AKycRm05.vo.AKycRm05_00Response;
import com.chunho.aml.portal.kyc.ra.AKycRm05.vo.AKycRm05_00SaveRequest;
import com.chunho.aml.portal.kyc.ra.AKycRm05.vo.AKycRm05_00SearchRequest;

import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class AKycRm05_00Service {

	private final AKycRm05_00Repository repository;
	
	public GenericGridResponse<AKycRm05_00Response> findchList(AKycRm05_00SearchRequest request) {
		return GenericGridResponse.<AKycRm05_00Response>builder()
				.pageIndex(request.getPageIndex())
                .pageSize(request.getPageSize())
                .totalCount(repository.findTotalCount(request))
                .collection(repository.findchList(request))
                .build();
	}

	public void save(@Valid GenericGridRequest<AKycRm05_00SaveRequest> request) {
		String sessionUserId = SessionInfo.getSessionUser().getUserId();
		
		request.getCreatedRows().forEach( x-> {
			boolean isExistYn = repository.checkDuplicateCh(x.getChCode());
			
			if(isExistYn) {
				throw AKycRm05_00ErrorType.STR001.exception();
			}else {
				repository.create(x, sessionUserId);
			}
		});
		
		request.getUpdatedRows().forEach( x-> {
			boolean isExistYn = repository.checkDuplicateCh(x.getChCode());
			
//			if(isExistYn) {
//				throw AKycRm05_00ErrorType.STR001.exception();
//			}else {
				repository.update(x, sessionUserId);
//			}
		});
		
	}

	public void delete(@Valid GenericGridRequest<AKycRm05_00SaveRequest> request) {
		String sessionUserId = SessionInfo.getSessionUser().getUserId();
		
		request.getDeletedRows().forEach( x-> {
			repository.delete(x, sessionUserId);
		});
		
	}

}
