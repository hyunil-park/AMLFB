package com.chunho.aml.portal.ops.perm.APermMgmt03.vo;

import lombok.Builder;
import lombok.Getter;
import lombok.Setter;

import java.io.Serializable;

@Getter
@Setter
@Builder
public class APermMgmt03_01Response implements Serializable {
    private String menuPath;
    private String firstMenu;
    private String secondMenu;
    private String thirdMenu;
}
