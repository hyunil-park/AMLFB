package com.chunho.aml.portal.tms.rpt.ATmsMon01.vo;

public class ATmsMon01_00Response {

}
