package com.chunho.aml.portal.tms.inv.ATmsLv02.vo;

public class ATmsLv02_00Response {

}
