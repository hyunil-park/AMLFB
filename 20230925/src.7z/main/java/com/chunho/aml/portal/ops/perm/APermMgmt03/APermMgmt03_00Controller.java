package com.chunho.aml.portal.ops.perm.APermMgmt03;

import javax.validation.Valid;

import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.chunho.aml.common.generic.GenericCollectionResponse;
import com.chunho.aml.common.generic.GenericGridRequest;
import com.chunho.aml.common.interceptor.AuthCheckerService;
import com.chunho.aml.portal.ops.perm.APermMgmt03.vo.APermMgmt03_00Response;
import com.chunho.aml.portal.ops.perm.APermMgmt03.vo.APermMgmt03_00Request;

import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;


@Controller
@AllArgsConstructor
@RequestMapping("/ops/perm/APermMgmt03")
@Slf4j
public class APermMgmt03_00Controller {
    private final APermMgmt03_00Service service;
    private final AuthCheckerService authCheckerService;

    @GetMapping("/list")
    public String index(Model model){
        return "ops/perm/APermMgmt03/APermMgmt03_00";
    }

    @ResponseBody
    @GetMapping("/ajax/list")
    public ResponseEntity<GenericCollectionResponse<APermMgmt03_00Response>> menuList(){
        return ResponseEntity.ok(service.menuList());
    }
    @ResponseBody
    @PostMapping("/ajax/save")
    public ResponseEntity<Void> saveMenu(@Valid @RequestBody GenericGridRequest<APermMgmt03_00Request> request){
        service.save(request);
        authCheckerService.refreshMenuAuth();
        return ResponseEntity.ok().build();
    }

    @ResponseBody
    @PostMapping("/ajax/delete")
    public ResponseEntity<Void> deleteMenu(@RequestBody GenericGridRequest<APermMgmt03_00Request> request){
        service.delete(request.getDeletedRows());
        authCheckerService.refreshMenuAuth();
        return ResponseEntity.ok().build();
    }

}
