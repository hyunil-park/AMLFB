package com.chunho.aml.portal.kyc.ra.AKycRm06;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;

import com.chunho.aml.portal.kyc.ra.AKycRm06.vo.AKycRm06_00Response;
import com.chunho.aml.portal.kyc.ra.AKycRm06.vo.AKycRm06_00SaveRequest;
import com.chunho.aml.portal.kyc.ra.AKycRm06.vo.AKycRm06_00SearchRequest;

@Mapper
public interface AKycRm06_00Repository {

	List<AKycRm06_00Response> findexchList(AKycRm06_00SearchRequest request);
	int findTotalCount(AKycRm06_00SearchRequest request);
	
	boolean checkDuplicateExch(String exchStk);
	
	void create(AKycRm06_00SaveRequest AKycRm06SaveRequest, String sessionUserId);
	void update(AKycRm06_00SaveRequest AKycRm06SaveRequest, String sessionUserId);
	void delete(AKycRm06_00SaveRequest AKycRm06SaveRequest, String sessionUserId);

}
