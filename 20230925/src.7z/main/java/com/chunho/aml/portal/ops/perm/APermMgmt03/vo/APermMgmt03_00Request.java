package com.chunho.aml.portal.ops.perm.APermMgmt03.vo;

import lombok.Getter;
import lombok.Setter;

import javax.validation.constraints.Max;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.PositiveOrZero;
import java.io.Serializable;

@Getter
@Setter
public class APermMgmt03_00Request implements Serializable {
    @NotBlank(message = "message.management.menu.field.menuCode.require")
    private String menuCode;
    @NotBlank(message = "message.management.menu.field.menuName.require")
    private String menuName;
    @PositiveOrZero
    @Max(value = 3, message = "message.management.menu.field.menuDepth.require")
    private int menuDepth;
    @PositiveOrZero(message = "message.management.menu.field.menuOrder.require")
    private int menuOrder;
    private String upMenuCode;
    private String menuPath;
    private String packagePath;
}
