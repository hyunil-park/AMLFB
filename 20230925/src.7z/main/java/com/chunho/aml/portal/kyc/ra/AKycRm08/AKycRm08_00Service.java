package com.chunho.aml.portal.kyc.ra.AKycRm08;

public class AKycRm08_00Service {

}
