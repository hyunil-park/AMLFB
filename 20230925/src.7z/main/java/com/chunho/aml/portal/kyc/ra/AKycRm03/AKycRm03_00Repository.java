package com.chunho.aml.portal.kyc.ra.AKycRm03;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;

import com.chunho.aml.portal.kyc.ra.AKycRm03.vo.AKycRm03_00Response;
import com.chunho.aml.portal.kyc.ra.AKycRm03.vo.AKycRm03_00SaveRequest;
import com.chunho.aml.portal.kyc.ra.AKycRm03.vo.AKycRm03_00SearchRequest;

@Mapper
public interface AKycRm03_00Repository {

	List<AKycRm03_00Response> findintyList(AKycRm03_00SearchRequest request);
	int findTotalCount(AKycRm03_00SearchRequest request);
	
	boolean checkDuplicateBojCode(String bojCode, String bojName);
	
	void create(AKycRm03_00SaveRequest AKycRm03SaveRequest, String sessionUserId);
	void update(AKycRm03_00SaveRequest AKycRm03SaveRequest, String sessionUserId);
	void delete(AKycRm03_00SaveRequest AKycRm03SaveRequest, String sessionUserId);

}
