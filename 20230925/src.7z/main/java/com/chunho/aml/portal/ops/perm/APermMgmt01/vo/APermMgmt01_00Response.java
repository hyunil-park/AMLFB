package com.chunho.aml.portal.ops.perm.APermMgmt01.vo;

import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.*;

import java.time.LocalDateTime;

/**
 * author         : yejin
 * date           : 2023-07-20
 * description    : grid 조회 응답 VO
 * ===========================================================
 * DATE              AUTHOR             NOTE
 * -----------------------------------------------------------
 * 2023-06-20        yejin       최초 생성
 */
@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class APermMgmt01_00Response {
	
	private String userId;
	private String userName;

	private String departmentCode;
	private String positionCode;
	private String groupCode;
	private String useYn;
	
	private String modifyUserId;
	private String registerUserId;
	
	@JsonFormat(shape= JsonFormat.Shape.STRING, pattern="yyyy-MM-dd HH:mm:ss")
	private LocalDateTime modifyDateTime;
	@JsonFormat(shape= JsonFormat.Shape.STRING, pattern="yyyy-MM-dd HH:mm:ss")
	private LocalDateTime registerDateTime;

}
