package com.chunho.aml.portal.kyc.cra.AKycEdd01;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Controller
@AllArgsConstructor
@RequestMapping("/kyc/cra/AKycEdd01")
@Slf4j
public class AKycEdd01_00Controller {
	
	@GetMapping("/list")
	public String index(Model model){
        return "kyc/cra/AKycEdd01/AKycEdd01_00";
    }
}
