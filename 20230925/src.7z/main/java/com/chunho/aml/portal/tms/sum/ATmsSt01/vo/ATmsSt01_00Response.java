package com.chunho.aml.portal.tms.sum.ATmsSt01.vo;

public class ATmsSt01_00Response {

}
