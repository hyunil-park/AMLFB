package com.chunho.aml.portal.tms.rpt.ATmsRp01;

import java.util.HashMap;
import java.util.List;

import javax.validation.Valid;

import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.chunho.aml.common.AjaxResponse;
import com.chunho.aml.common.generic.GenericCollectionResponse;
import com.chunho.aml.common.generic.GenericGridRequest;
import com.chunho.aml.portal.common.data.CodeEnumType;
import com.chunho.aml.portal.common.data.CodeVO;
import com.chunho.aml.portal.common.data.CommonService;
import com.chunho.aml.portal.ops.perm.APermMgmt01.vo.APermMgmt01_00SaveRequest;
import com.chunho.aml.portal.tms.rpt.ATmsRp01.vo.ATmsRp01_00Response;
import com.chunho.aml.portal.tms.rpt.ATmsRp01.vo.ATmsRp01_00SaveRequest;
import com.chunho.aml.portal.tms.rpt.ATmsRp01.vo.ATmsRp01_00SearchRequest;

import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;

/**
 * author         : hjs
 * date           : 2023-09-18 
 * description    : TMS > 보고서 관리
 * ===========================================================
 * DATE              AUTHOR             NOTE
 * -----------------------------------------------------------
 * 2023-09-18        hjs       최초 생성
 */
   
@Controller
@AllArgsConstructor
@RequestMapping("/tms/rpt/ATmsRp01")
@Slf4j
public class ATmsRp01_00Controller {
	
	private final CommonService commonService;
	private final ATmsRp01_00Service aTmsRp01Service;
	
	/**
	 * 보고서 관리 > 보고내역조회 및 검토_[화면 로딩]
	 * @param model
	 * @return
	 */
	@GetMapping("/list")
	public String list(Model model){
		
		List<CodeVO> strRptType = commonService.findRptType(CodeEnumType.ALL);		//보고서 종류
		List<CodeVO> strRptStatus = commonService.findRptStatus(CodeEnumType.ALL);	//결재 상태
		model.addAttribute("strRptType",strRptType);		
		model.addAttribute("strRptStatus",strRptStatus);	

        return "tms/rpt/ATmsRp01/ATmsRp01_00";
    }
	
	/**
	 * 보고서 관리 > 보고내역조회 및 검토_[조회]
	 * @param request
	 * @return
	 */
	@GetMapping("/ajax/search/list")
	@ResponseBody
	public ResponseEntity<GenericCollectionResponse<ATmsRp01_00Response>> list(@Valid ATmsRp01_00SearchRequest request) {
		
		HashMap<String, List<CodeVO>> codeMap = new HashMap<>();
        codeMap.put("strRptType",commonService.findRptType(CodeEnumType.SELECT));		//보고서 종류
        codeMap.put("strRptStatus",commonService.findRptStatus(CodeEnumType.SELECT));	//결재 상태
        codeMap.put("firstApprovalResult",commonService.findFirstApprovalResult(CodeEnumType.SELECT));	//검토결과
		return ResponseEntity.ok(GenericCollectionResponse.<ATmsRp01_00Response>builder()
                .gridData(aTmsRp01Service.findRp01List(request))
                .codeData(codeMap)
                .build());
    }
	
	/**
	 * 보고서 관리 > 보고내역조회 및 검토_[저장]
	 * @param request
	 * @return
	 */
	@PostMapping("/ajax/save")
	@ResponseBody
	public AjaxResponse<Void,Void> save(@RequestBody @Valid GenericGridRequest<ATmsRp01_00SaveRequest> request) {
		aTmsRp01Service.save(request);
		return AjaxResponse.<Void, Void>builder().build();
	}
}
