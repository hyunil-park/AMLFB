package com.chunho.aml.portal.tms.rule.ATmsRl02;

public class ATmsRl02_00Service {

}
