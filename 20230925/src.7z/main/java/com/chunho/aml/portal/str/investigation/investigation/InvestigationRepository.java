package com.chunho.aml.portal.str.investigation.investigation;


import org.apache.ibatis.annotations.Mapper;

/**
 * author         : yejin
 * date           : 2023-05-24
 * description    :
 * ===========================================================
 * DATE              AUTHOR             NOTE
 * -----------------------------------------------------------
 * 2023-05-24        yejin       최초 생성
 */

@Mapper
public interface InvestigationRepository {

    String test();
}
