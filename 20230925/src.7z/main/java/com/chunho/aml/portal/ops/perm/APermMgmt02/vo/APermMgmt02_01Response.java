package com.chunho.aml.portal.ops.perm.APermMgmt02.vo;

import lombok.Builder;
import lombok.Getter;
import lombok.RequiredArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@Builder
public class APermMgmt02_01Response {
	
	private String groupCode;
	private String groupName;
	private String groupNote;
	private String registerId;
	private String modifyId;
	
}
