package com.chunho.aml.portal.kyc.cra.AKycMon01.vo;

public class AKycMon01_00SaveRequest {

}
