package com.chunho.aml.common.generic;

import com.chunho.aml.portal.common.data.CodeVO;
import lombok.Builder;
import lombok.Getter;
import lombok.Setter;

import java.util.List;
import java.util.Map;

@Getter
@Setter
@Builder
public class GenericCollectionResponse<T> {
    private Map<String, List<CodeVO>> codeData;
    private GenericGridResponse<T> gridData;
    @Builder.Default
    private boolean success = true;
}
