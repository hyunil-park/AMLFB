package com.chunho.aml.common;

import java.util.HashMap;
import java.util.Map;

/**
 * author         : yejin
 * date           : 2023-05-31
 * description    : ThreadLocal한 ThreadID 저장소
 * ===========================================================
 * DATE              AUTHOR             NOTE
 * -----------------------------------------------------------
 * 2023-05-31        yejin       최초 생성
 */
public class MdcContextHolder {

    private static final ThreadLocal<Map<String, String>> MDC_CONTEXT_HOLDER = new ThreadLocal<>();

    public static void put(String key, String value) {
        Map<String, String> context = MDC_CONTEXT_HOLDER.get();
        if (context == null) {
            context = new HashMap<>();
            MDC_CONTEXT_HOLDER.set(context);
        }
        context.put(key, value);
    }

    public static String get(String key) {
        Map<String, String> context = MDC_CONTEXT_HOLDER.get();
        if (context != null) {
            return context.get(key);
        }
        return null;
    }

    public static void clear() {
        MDC_CONTEXT_HOLDER.remove();
    }

}
