package com.chunho.aml.common.exception;

import lombok.Builder;
import lombok.Getter;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import javax.servlet.RequestDispatcher;
import javax.servlet.http.HttpServletRequest;
import java.time.LocalDateTime;

@Getter
@Builder
public class BusinessErrorResponse {

    private final LocalDateTime timestamp = LocalDateTime.now();
    private final int status;
    private final String error;
    private final BusinessErrorCode code;
    private final String detail;
    private final String message;

    private final boolean success = false;

    public static ResponseEntity<Object> toResponseEntity(BusinessErrorCodeException exception) {

        return ResponseEntity
                  .status(exception.getStatus())
                  .body(
                          BusinessErrorResponse.builder()
                          .status(exception.getStatus().value())//httpStatus 코드
                          .error(exception.getStatus().name())//httpStatus 이름
                          .code(exception.getBusinessErrorCode())//errorCode 의 이름
                          //.detail(business)//errorCode 상세
                          .message(exception.getReason())//에러 메시지
                          .build()
                  );
      }
    public static ResponseEntity<Object> toResponseEntity(HttpServletRequest request) {
        HttpStatus status = getStatus(request);
        return ResponseEntity.status(status).build();
    }
    private static HttpStatus getStatus(HttpServletRequest request) {
        Integer statusCode = (Integer) request.getAttribute(RequestDispatcher.ERROR_STATUS_CODE);
        if (statusCode == null) {
            return HttpStatus.INTERNAL_SERVER_ERROR;
        }
        try {
            return HttpStatus.valueOf(statusCode);
        }
        catch (Exception ex) {
            return HttpStatus.INTERNAL_SERVER_ERROR;
        }
    }
}