package com.chunho.aml.common.utils;

import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.stereotype.Component;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;
import org.springframework.web.servlet.LocaleResolver;

import javax.annotation.PostConstruct;
import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import java.util.Locale;

/**
 * author         : yejin
 * date           : 2023-06-08
 * description    : MessageSource, LoclaeResolver를 이용하여 Enum에 정의해둔
 *                  Code의 message값 세팅
 * ===========================================================
 * DATE              AUTHOR             NOTE
 * -----------------------------------------------------------
 * 2023-06-08        yejin       최초 생성
 */
@Component
@Slf4j
public class MessageUtil {

    @Resource
    private MessageSource source;

    @Autowired
    private LocaleResolver localeResolver;

    //@Resource(name = "localeResolver")
    //private LocaleResolver localeResolver;
    static MessageSource messageSource;

    static LocaleResolver cookieLocaleResolver;


    @PostConstruct
    public void initialize() {
        messageSource = source;
        cookieLocaleResolver = localeResolver;
    }

    public static String getMessage(String messageCd, Object[] messageArgs) {
        ServletRequestAttributes servletRequestAttribute = (ServletRequestAttributes) RequestContextHolder.currentRequestAttributes();
       HttpServletRequest request = servletRequestAttribute.getRequest();

        Locale locale =  cookieLocaleResolver.resolveLocale(request);
        /*String locale = null;
        Cookie[] cookies = request.getCookies();
        for(Cookie cookie:cookies) {
            if(cookie.getName().equals("lang")) {
                log.info("cookie : {} ",cookie.getValue());
                locale = cookie.getValue();
            }
        }
        */
        return messageSource.getMessage(messageCd, messageArgs, locale);
    }
}
