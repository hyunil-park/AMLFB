package com.chunho.aml.common.interceptor;

import java.util.List;

import org.springframework.cache.annotation.CachePut;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Service;

import com.chunho.aml.common.SessionInfo;
import com.chunho.aml.common.cache.CacheKeys;
import com.chunho.aml.portal.ops.perm.APermMgmt03.APermMgmt03_00Repository;
import com.chunho.aml.portal.ops.perm.APermMgmt03.vo.APermMgmt03_00Response;
import com.chunho.aml.portal.ops.perm.APermMgmt03.vo.APermMgmt03_00Request;
import com.chunho.aml.portal.ops.perm.APermMgmt03.vo.APermMgmt03_01Response;

import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class AuthCheckerService {
    private final APermMgmt03_00Repository menuRepository;

    public void refreshMenuAuth(){
        String groupCode = SessionInfo.getSessionUser().getGroupCode();
        refreshAllMenu();
        refreshMenuPermission(groupCode);
        refreshMenuTitle(groupCode);
    }
    @Cacheable(cacheNames = CacheKeys.MENU_PERMISSION, key = "#groupCode")
    public List<String> findMenuPermission(String groupCode){
        return menuRepository.findAutorizedMenu(groupCode);
    }

    @CachePut(value = CacheKeys.MENU_PERMISSION, key = "#groupCode")
    public List<String> refreshMenuPermission(String employeeNumber){
        return menuRepository.findAutorizedMenu(employeeNumber);
    }

    @Cacheable(value = CacheKeys.ALL_MENU)
    public List<APermMgmt03_00Request> findAllMenu(){
        return menuRepository.findAllMenu();
    }
    @CachePut(value = CacheKeys.ALL_MENU)
    public List<APermMgmt03_00Request> refreshAllMenu(){
        return menuRepository.findAllMenu();
    }

    @Cacheable(value = CacheKeys.MENU_TITLE, key = "#groupCode")
    public List<APermMgmt03_01Response> findMenuTitle(String groupCode){
        return menuRepository.findMenuTitle(groupCode);
    }

    @CachePut(value = CacheKeys.MENU_TITLE, key = "#groupCode")
    public List<APermMgmt03_01Response> refreshMenuTitle(String groupCode){
        return menuRepository.findMenuTitle(groupCode);
    }

    @Cacheable(value = CacheKeys.GNB_MENU, key = "#groupCode")
    public List<APermMgmt03_00Response> headerMenuList(String groupCode){
        return menuRepository.headerMenuList(groupCode);
    }



}
