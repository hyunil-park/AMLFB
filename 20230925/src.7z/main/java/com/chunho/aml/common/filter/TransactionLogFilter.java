package com.chunho.aml.common.filter;

import com.chunho.aml.common.EnvironmentConstants;
import lombok.extern.slf4j.Slf4j;
import org.slf4j.MDC;
import org.springframework.util.PatternMatchUtils;

import javax.servlet.*;
import javax.servlet.http.HttpServletRequest;
import java.io.IOException;
import java.util.List;
import java.util.UUID;

/**
 * author         : yejin
 * date           : 2023-05-25
 * description    : 트랜잭션별 로그 ID생성 필터
 * ===========================================================
 * DATE              AUTHOR             NOTE
 * -----------------------------------------------------------
 * 2023-05-25        yejin       최초 생성
 */
@Slf4j
public class TransactionLogFilter implements Filter {

    @Override
    public void init(FilterConfig filterConfig) throws ServletException {
        Filter.super.init(filterConfig);
    }

    @Override
    public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException, ServletException {

        String uri = ((HttpServletRequest)request).getRequestURI();
        List<String> excludePaths = EnvironmentConstants.CommonProperty.EXCLUDE_PATHS;


        if(PatternMatchUtils.simpleMatch(excludePaths.toArray(new String[excludePaths.size()]),uri)){
            chain.doFilter(request,response);
            return;
        }
        try{
            String key =  UUID.randomUUID().toString();
            MDC.put("transactionId", key);
            chain.doFilter(request,response);
        }finally {
            log.info("MDC Clear");
            MDC.clear();

        }

    }

    @Override
    public void destroy() {
        Filter.super.destroy();
    }
}

