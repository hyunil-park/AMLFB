package com.chunho.aml.common.generic;

import lombok.Getter;

import javax.validation.Valid;
import java.util.List;

@Getter
public class GenericGridRequest<T> {
    @Valid
    private List<T> createdRows;
    @Valid
    private List<T> updatedRows;
    private List<T> deletedRows;
}
