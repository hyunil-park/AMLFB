package com.chunho.aml.common.cache;

import java.util.HashMap;
import java.util.Map;

public final class CacheKeys {
    private final Long ONE_HOUR = 60*60L;
    public static final String MENU_PERMISSION = "menuPermission";
    public static final String ALL_MENU = "allMenu";
    public static final String MENU_TITLE = "menuTitle";
    public static final String GNB_MENU = "gnbMenu";

    public Map<String,Long> getCacheMaps(){
        Map<String,Long> result = new HashMap<>();

        result.put(MENU_PERMISSION, ONE_HOUR);
        result.put(ALL_MENU, ONE_HOUR);
        result.put(MENU_TITLE, ONE_HOUR);
        result.put(GNB_MENU, ONE_HOUR);

        return result;
    }
}
