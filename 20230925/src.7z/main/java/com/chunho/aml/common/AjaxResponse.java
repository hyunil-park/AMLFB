package com.chunho.aml.common;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;

@Getter
@AllArgsConstructor
@Builder
public class AjaxResponse<P, D> {
   @Builder.Default
   private boolean success = true;
   private int responseCode;
   private String responseMessage;
   private P param;
   private D data;

   public static<P, D> AjaxResponse<P, D> res(
         final boolean success,
         final int responseCode,
         final String responseMessage,
         final P param,
         final D responseData
         ) {
      return AjaxResponse.<P, D>builder()
            .success(success)
            .responseCode(responseCode)
            .responseMessage(responseMessage)
            .param(param)
            .data(responseData)
            .build();
   }
   
   public static<P, D> AjaxResponse<P, D> res(
         final boolean success,
         final int responseCode,
         final String responseMessage,
         final P param
         ) {
      return AjaxResponse.<P, D>builder()
            .success(success)
            .responseCode(responseCode)
            .responseMessage(responseMessage)
            .param(param)
            .build();
   }
   
   public static<P, D> AjaxResponse<P, D> res(
         final boolean success,
         final P param
         ) {
      return AjaxResponse.<P, D>builder()
            .success(success)
            .param(param)
            .build();
   }
   
   public static<P, D>AjaxResponse<P, D> res(
         final boolean success,
         final int responseCode,
         final String responseMessage
         ) {
      return AjaxResponse.<P, D>builder()
            .success(success)
            .responseCode(responseCode)
            .responseMessage(responseMessage)
            .build();
   }

   public static<P, D> AjaxResponse<P, D> res(
         final boolean success) {
      return AjaxResponse.<P, D>builder()
            .success(success)
            .build();
   }
}