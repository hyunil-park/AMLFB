package com.chunho.aml.common.generic;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonUnwrapped;
import lombok.Builder;
import lombok.Getter;
import lombok.Setter;

@Getter
@JsonInclude(JsonInclude.Include.NON_EMPTY)
public class GenericCommonRequest<T> {
    private Integer pageIndex;
    private Integer pageSize;
    @JsonUnwrapped
    private T request;

    public GenericCommonRequest() {
        this.pageIndex = 1;
        this.pageSize = 10;
    }
    public void setPageIndex(Integer pageIndex) {
        if(pageIndex == null){
            pageIndex = 1;
        }
        this.pageIndex = pageIndex;
    }

    public void setPageSize(Integer pageSize) {
        if(pageSize == null){
            pageSize = 10;
        }
        this.pageSize = pageSize;
    }

    public void setRequest(T request) {
        this.request = request;
    }
}
