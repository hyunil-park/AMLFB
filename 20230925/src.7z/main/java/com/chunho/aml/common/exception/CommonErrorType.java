package com.chunho.aml.common.exception;

import com.chunho.aml.common.exception.BusinessErrorCode;
import com.chunho.aml.common.exception.BusinessErrorCodeException;
import com.chunho.aml.common.utils.MessageUtil;
import lombok.Getter;
import java.util.function.BiFunction;

/**
 * author         : yejin
 * date           : 2023-06-05
 * description    :
 * ===========================================================
 * DATE              AUTHOR             NOTE
 * -----------------------------------------------------------
 * 2023-06-05        yejin       최초 생성
 */
public enum CommonErrorType  implements BusinessErrorCode {
    SESSION_EXPIRED("msg.session.expired2",BusinessErrorCodeException.UNAUTHORIZED::httpStatus),

    NO_ACCESS_AUTH("message.no.auth",BusinessErrorCodeException.UNAUTHORIZED::httpStatus),

    LOGIN_FAIL("message.login.fail",BusinessErrorCodeException.OK::httpStatus),
    SYSTEM_500_ERROR("message.common.system.error",BusinessErrorCodeException.INTERNAL_SERVER_ERROR::httpStatus),
    VALIDATION_DATE_SCOPE("message.common.validation.search.date.scope",BusinessErrorCodeException.OK::httpStatus),
    VALIDATION_DATE_FORMAT("message.common.validation.search.date.format",BusinessErrorCodeException.OK::httpStatus);

    @Getter
    public final String code;

    @Getter
    public String message;


    CommonErrorType(String code, BiFunction<BusinessErrorCode, Object[], BusinessErrorCodeException> exception) {

        this.code = code;
        this.exception = exception;
    }

    private final BiFunction<BusinessErrorCode, Object[], BusinessErrorCodeException> exception;

    public BusinessErrorCodeException exception(Object... args) {
        this.message = MessageUtil.getMessage(this.code,args);
        return exception.apply(this, args);
    }




}
