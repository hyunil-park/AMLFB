package com.chunho.aml.common.generic;

import lombok.Builder;
import lombok.Getter;
import lombok.Setter;

import java.util.List;

@Getter
@Setter
@Builder
public class GenericGridResponse<E> {
    private int pageIndex;
    private int pageSize;
    private int totalCount;
    private List<E> collection;

}
