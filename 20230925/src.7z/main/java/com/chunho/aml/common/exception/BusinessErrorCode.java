package com.chunho.aml.common.exception;

public interface BusinessErrorCode {

    String getCode();

    String getMessage();

    default String getMessage(Object... args) {
        return String.format(getMessage(), args);
    }
}
