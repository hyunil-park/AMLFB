package com.chunho.aml.common.generic;


import com.chunho.aml.common.validation.DateCheckConstraint;
import lombok.Getter;
import lombok.Setter;

/**
 * author         : yejin
 * date           : 2023-07-19
 * description    : 검색조건 관련 공통 VO
 * (페이지번호, 페이지사이즈, 시작일자, 종료일자, 키워드 관련 SEARCHTEXT 고려중)
 * ===========================================================
 * DATE              AUTHOR             NOTE
 * -----------------------------------------------------------
 * 2023-05-30        yejin       최초 생성
 */


@Getter
@Setter
@DateCheckConstraint(startDate = "startDate", endDate = "endDate")
public class SearchConditionVO {
    private Integer pageIndex;
    private Integer pageSize;

    private String startDate;
    private String endDate;
    
    //날짜 valid 관련 커스터마이징 DateCheckConstraint valid사용 으로 String으로 전달받음
    //@DateTimeFormat(pattern = "yyyy-MM-dd")
    //private LocalDate startDate;
    //@DateTimeFormat(pattern = "yyyy-MM-dd")
    //private LocalDate endDate;

    public SearchConditionVO() {
        this.pageIndex = 1;
        this.pageSize = 10;
        //this.startDate2 = "nouse";
    }
    public void setPageIndex(Integer pageIndex) {
        if(pageIndex == null){
            pageIndex = 1;
        }
        this.pageIndex = pageIndex;
    }

    public void setPageSize(Integer pageSize) {
        if(pageSize == null){
            pageSize = 10;
        }
        this.pageSize = pageSize;
    }


}
