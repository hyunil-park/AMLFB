package com.chunho.aml.common.encrypt;

public enum EncryptVersion {
    $2A("$2a"),

    $2Y("$2y"),

    $2B("$2b");

    private final String version;

    EncryptVersion(String version) {
        this.version = version;
    }

    public String getVersion() {
        return this.version;
    }
}
