package com.chunho.aml.common.exception;

import com.chunho.aml.common.utils.MessageUtil;
import com.chunho.aml.portal.common.file.FileException;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.ui.Model;
import org.springframework.validation.BindException;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.method.HandlerMethod;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.Collection;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

/**
 * author         : yejin
 * date           : 2023-05-30
 * description    : error 화면 처리
 * ===========================================================
 * DATE              AUTHOR             NOTE
 * -----------------------------------------------------------
 * 2023-05-30        yejin       최초 생성
 */

@ControllerAdvice
@Slf4j
public class GlobalExceptionHandler  {
    private static final String ERROR_404_PAGE_PATH = "error/404";
    private static final String ERROR_500_PAGE_PATH = "error/500";
    private static final String ERROR_ETC_PAGE_PATH = "error/error";
    private static final String ERROR_SESSION_EXPIRED_PAGE_PATH = "error/sessionExpired";
    private static final String ERROR_NO_AUTH_PAGE_PATH = "error/noAuth";

    /**
     * BusinessErrorCodeException 커스텀 - 비즈니스적인 예외 처리
     */
    @ExceptionHandler(BusinessErrorCodeException.class)
    public Object businessException(HandlerMethod handlerMethod, BusinessErrorCodeException ex) {
        log.info("BusinessException",ex);

        ResponseBody methodAnnotation = handlerMethod.getMethodAnnotation(ResponseBody.class);
        
        //페이지이동 인경우 페이지 리턴(세션 만료 또는 접근 권한없을 경우 보여주는 페이지 세팅)
        if (methodAnnotation == null) {
           // if("true".equals(response.getHeader("SESSION_EXPIRED"))){
            //    model.addAttribute("msg",ex.getReason());
            //   return ERROR_SESSION_EXPIRED_PAGE_PATH;
            //}else{
                return ERROR_NO_AUTH_PAGE_PATH;
            //}
        }
        
        //AJAX 통신인경우 json 리턴
        return BusinessErrorResponse.toResponseEntity(ex);
    }

    /**
     * FileException 커스텀 - 파일처리시 에러발생
     */
    @ExceptionHandler(FileException.class)
    public Object fileException(HttpServletResponse response, FileException exception, HandlerMethod handlerMethod, HttpServletRequest request) {

        log.info("FileException",exception);
        return  ResponseEntity
                    .status(HttpStatus.INTERNAL_SERVER_ERROR) //500
                    .body(
                            BusinessErrorResponse.builder()
                                    .status(500)//httpStatus 코드
                                    //.detail(business)//errorCode 상세
                                    .message(exception.getMessage())//에러 메시지
                                    .build()
                    );
    }

    /**
     * save request dto validation 익셉션
     */
    @ExceptionHandler(MethodArgumentNotValidException.class)
    public Object notValidException(MethodArgumentNotValidException ex){

        Map<String,String> errors = ex.getBindingResult()
                .getFieldErrors()
                .stream()
                .collect( Collectors.toMap(x->x.getField().split("\\.")[1], x->   MessageUtil.getMessage(x.getDefaultMessage(),null),
                        (oldValue, newValue) -> {
                            return oldValue;
                        }
                ));
        Collection<String> values = errors.values();
        return  ResponseEntity
                .status(HttpStatus.BAD_REQUEST) //401
                .body(values);
    }

    /**
     * search request dto validation 익셉션
     */
    @ExceptionHandler(BindException.class)
    public Object bindingException(BindException ex){

        System.out.println(ex);

        List<String> errors = ex.getBindingResult()
                .getFieldErrors()
                .stream()
                .map(x->x.getDefaultMessage()).collect(Collectors.toList());

        return  ResponseEntity
                .status(HttpStatus.BAD_REQUEST)
                .body(errors);
    }
    /**
     * 정의한 익셉션 외의 모든 익셉션 처리
     */
    @ExceptionHandler(Exception.class)
    public Object exception(Exception exception, HandlerMethod handlerMethod) {

        log.info("Exception",exception);
        ResponseBody methodAnnotation = handlerMethod.getMethodAnnotation(ResponseBody.class);
        //AJAX 통신 인경우 json 리턴
        if (methodAnnotation != null) {
            return BusinessErrorResponse.toResponseEntity(CommonErrorType.SYSTEM_500_ERROR.exception());
        }

        //페이지 이동인경우 페이지 리턴
        return ERROR_500_PAGE_PATH;
    }
}





