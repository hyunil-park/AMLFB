package com.chunho.aml.common;

import com.chunho.aml.portal.login.vo.UserVO;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

/**
 * author         : yejin
 * date           : 2023-07-14
 * description    : 세션 정보
 * ===========================================================
 * DATE              AUTHOR             NOTE
 * -----------------------------------------------------------
 * 2023-05-25        yejin       최초 생성
 */
@Slf4j
public class SessionInfo {

	public static UserVO getSessionUser(){
		ServletRequestAttributes servletRequestAttribute = (ServletRequestAttributes) RequestContextHolder.currentRequestAttributes();
		HttpServletRequest request = servletRequestAttribute.getRequest();
		HttpSession session = request.getSession();

		UserVO userVO = (UserVO)session.getAttribute(EnvironmentConstants.CommonProperty.LOGIN_USER_SESSION_NAME);

		return userVO;
	}
}
