package com.chunho.aml.common.interceptor;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.web.servlet.HandlerInterceptor;
import org.springframework.web.servlet.ModelAndView;

import com.chunho.aml.common.EnvironmentConstants;
import com.chunho.aml.common.exception.CommonErrorType;
import com.chunho.aml.portal.login.vo.UserVO;
import com.chunho.aml.portal.ops.perm.APermMgmt03.vo.APermMgmt03_00Response;
import com.chunho.aml.portal.ops.perm.APermMgmt03.vo.APermMgmt03_01Response;
import com.chunho.aml.portal.ops.perm.APermMgmt03.vo.APermMgmt03_02Response;

import lombok.extern.slf4j.Slf4j;

/**
 * author         : yejin
 * date           : 2023-05-26
 * description    : 로그인 체크 인터셉터
 * ===========================================================
 * DATE              AUTHOR             NOTE
 * -----------------------------------------------------------
 * 2023-05-26        yejin       최초 생성
 */
@Slf4j
public class AuthLoginInterceptor implements HandlerInterceptor {
    private AuthCheckerService authCheckerService;

    public AuthLoginInterceptor(AuthCheckerService authChecker) {
        this.authCheckerService = authChecker;
    }
    @Override
    public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler) throws Exception {

        HttpSession session = request.getSession();

        if(session == null || session.getAttribute(EnvironmentConstants.CommonProperty.LOGIN_USER_SESSION_NAME) == null){
             if (isAjaxRequest(request)) {
                log.info("SESSION ===> NO, AJAX");
                /* ajax 요청일때 세션만료인경우 common.js*/
                response.setHeader("SESSION_EXPIRED", "true");
                throw CommonErrorType.SESSION_EXPIRED.exception("1","2");

            } else {
                log.info("SESSION ===> NO");
                /*방법 1) 알럿 없이 로그인페이지 이동*/
                response.sendRedirect(EnvironmentConstants.CommonProperty.LOGIN_PATH);
                return false;

                /*방법 2) 알럿 띄우고 로그인 페이지이동 (error/sessionExpired.jsp) */
                //response.setHeader("SESSION_EXPIRED", "true");
                //throw CommonErrorType.SESSION_EXPIRED.exception("1","2");
             }
        }

        log.info("SESSION ===> YES");
        Object obj =session.getAttribute(EnvironmentConstants.CommonProperty.LOGIN_USER_SESSION_NAME);
        UserVO user = (UserVO) obj;
        String requestURI = request.getRequestURI();
        log.info("isExistMenu : {}",isExistMenu(requestURI));
        log.info(String.format("%s PERMISSION ===> %s", requestURI, checkPermission(user.getGroupCode(), requestURI)));

        if(isExistMenu(requestURI)){ // 실제 존재하는 메뉴인지 체크
            if(checkPermission(user.getGroupCode(), requestURI)){ // 권한 체크
                request.setAttribute("menuTtile",getMenuTitle(user.getGroupCode(),requestURI));
                List<APermMgmt03_00Response> mList = authCheckerService.headerMenuList(user.getGroupCode());
                request.setAttribute("gnbHeader",mList);
                request.setAttribute("activeMenuCode",getMenuCode(mList,requestURI));
            } else{
                throw CommonErrorType.NO_ACCESS_AUTH.exception();
            }
        }

        // 컨트롤러 고
        return true;
    }

    // Ajax 요청인지 체크하는 메소드
    private boolean isAjaxRequest(HttpServletRequest request) {
        return EnvironmentConstants.CommonProperty.AJAX_HEADER_VALUE.equals(request.getHeader(EnvironmentConstants.CommonProperty.AJAX_HEADER_NAME));
    }
    @Override
    public void postHandle(HttpServletRequest request, HttpServletResponse response, Object handler, ModelAndView modelAndView) throws Exception {
        HandlerInterceptor.super.postHandle(request, response, handler, modelAndView);
    }

    private boolean checkPermission(String groupCode, String requestUri){
        return authCheckerService
                .findMenuPermission(groupCode)
                .stream()
                .anyMatch(s->s.equals(requestUri));
    }

    //존재하는 메뉴인지 확인 - 404에러 관련필요
    private boolean isExistMenu(String requestUri){
        return authCheckerService.findAllMenu().stream()
                .anyMatch(s->s.getMenuPath().contains(requestUri));
    }

    private APermMgmt03_01Response getMenuTitle(String groupCode, String requestURI){
        return authCheckerService.findMenuTitle(groupCode)
                .stream().filter(x->requestURI.equals(x.getMenuPath()))
                .findFirst()
                .orElse(null);
    }

    private APermMgmt03_02Response getMenuCode(List<APermMgmt03_00Response> mList, String requestURI){

        APermMgmt03_02Response.APermMgmt03_02ResponseBuilder result = APermMgmt03_02Response.builder();
        for(APermMgmt03_00Response f : mList){
            for(APermMgmt03_00Response s : f.get_children()){
                for(APermMgmt03_00Response t : s.get_children()){
                    if(requestURI.equals(t.getMenuPath())){
                        result.first(f.getMenuCode());
                        result.second(t.getMenuCode());
                        result.third(t.getMenuCode());
                        break;
                    }
                }
            }
        }
        return result.build();
    }
}
