package com.chunho.aml.common.encrypt;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.stereotype.Component;

import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.util.regex.Pattern;


@Component
public class CryptPasswordEncoder implements PasswordEncoder{
    private Pattern BCRYPT_PATTERN = Pattern.compile("\\A\\$2(a|y|b)?\\$(\\d\\d)\\$[./0-9A-Za-z]{53}");
    private final Log logger = LogFactory.getLog(getClass());
    private final int strength = 10 ;
    private final EncryptVersion version = EncryptVersion.$2Y;

    private SecureRandom random;

    public CryptPasswordEncoder(){
        try {
            this.random = SecureRandom.getInstanceStrong();
        } catch (NoSuchAlgorithmException e) {
            throw new RuntimeException(e);
        }
    }

    public String encode(CharSequence rawPassword) {
        if (rawPassword == null) {
            throw new IllegalArgumentException("rawPassword cannot be null");
        }
        String salt = getSalt();

        return Crypt.hashpw(rawPassword.toString(), salt);
    }
    private String getSalt() {
        if (this.random != null) {
            return Crypt.gensalt(this.version.getVersion(), this.strength, this.random);
        }
        return Crypt.gensalt(this.version.getVersion(), this.strength);
    }

    public boolean matches(CharSequence rawPassword, String encodedPassword) {
        if (rawPassword == null) {
            throw new IllegalArgumentException("rawPassword cannot be null");
        }
        if (encodedPassword == null || encodedPassword.length() == 0) {
            this.logger.warn("Empty encoded password");
            return false;
        }
        if (!this.BCRYPT_PATTERN.matcher(encodedPassword).matches()) {
            this.logger.warn("Encoded password does not look like BCrypt");
            return false;
        }
        return Crypt.checkpw(rawPassword.toString(), encodedPassword);
    }

}
