package com.chunho.aml.common.exception;

import lombok.AccessLevel;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;


@RequiredArgsConstructor(access = AccessLevel.PACKAGE)
public  class BusinessErrorCodeExceptionBuilder {

    private final HttpStatus httpStatus;

    public BusinessErrorCodeException httpStatus(BusinessErrorCode code){
        return BusinessErrorCodeException.httpStatus(httpStatus, code);
    }
    public BusinessErrorCodeException httpStatus(BusinessErrorCode code, Object ... args){
        return BusinessErrorCodeException.httpStatus(httpStatus, code, args);
    }

}
