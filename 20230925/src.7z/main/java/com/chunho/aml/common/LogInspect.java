package com.chunho.aml.common;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Collections;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.servlet.http.HttpServletRequest;

import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.AfterReturning;
import org.aspectj.lang.annotation.AfterThrowing;
import org.aspectj.lang.annotation.Aspect;
import org.json.simple.JSONObject;
import org.springframework.stereotype.Component;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import com.chunho.aml.common.exception.BusinessErrorCodeException;
import com.chunho.aml.common.interceptor.AuthCheckerService;
import com.chunho.aml.portal.login.vo.UserVO;
import com.chunho.aml.portal.ops.perm.APermMgmt03.vo.APermMgmt03_00Request;
import com.chunho.aml.portal.ops.perm.APermMgmt04.APermMgmt04_00Repository;
import com.chunho.aml.portal.ops.perm.APermMgmt04.vo.APermMgmt04_00Response;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

/**
 * author         : yejin
 * date           : 2023-06-20
 * description    : 사용자 로그 AOP
 * ===========================================================
 * DATE              AUTHOR             NOTE
 * -----------------------------------------------------------
 * 2023-06-20        yejin       최초 생성
 */

@Component
@Aspect
@Slf4j
@RequiredArgsConstructor
public class LogInspect {

    private final APermMgmt04_00Repository logRepository;

    private final AuthCheckerService authCheckerService;

    @AfterThrowing(
            pointcut = "execution(* com.chunho..*Controller.*(..))",
            throwing = "ex"
    )
    private void afterException(JoinPoint joinPoint, Throwable ex) {
            
        //비즈니스 예외는 제외
        if(ex instanceof BusinessErrorCodeException){
            return;
        }
        run(ex);
    }

    @AfterReturning(pointcut = "execution(* com.chunho..*Controller.*(..))")
    private void after(JoinPoint joinPoint) {
        run(null);
    }
    
    //todo : 리팩토링 필요

    private void run(Throwable ex){

        HttpServletRequest request = ((ServletRequestAttributes) RequestContextHolder.getRequestAttributes()).getRequest();
        String requestURI = request.getRequestURI();
        Object session = request.getSession().getAttribute(EnvironmentConstants.CommonProperty.LOGIN_USER_SESSION_NAME);
        UserVO user = (UserVO) session;
        String ajaxAction = null;
        String menuName = null;

        String menuPattern = findUriPattern(requestURI, MENU_NAME_PATTERN);

        if(menuPattern != null) {
            List<APermMgmt03_00Request> allMenu = authCheckerService.findAllMenu();
            APermMgmt03_00Request menuSaveRequest = allMenu.stream().filter(x -> menuPattern.equals(x.getPackagePath())).findFirst().orElse(null);
            menuName = menuSaveRequest.getMenuName();

            ajaxAction = findAjaxAction(requestURI);

            if(ajaxAction != null){
                //LogVO.LogVOBuilder logVOBuilder = LogVO.builder().method(method).uri(requestURI).logTime(logTime).ip(request.getRemoteAddr());
                String connectDate = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyyMMdd"));
                String connectTime = LocalDateTime.now().format(DateTimeFormatter.ofPattern("HHmmssSSS"));
                APermMgmt04_00Response.APermMgmt04_00ResponseBuilder logVOBuilder = APermMgmt04_00Response.builder().requestMethod(ajaxAction)
                                                        .userId(user.getUserId())
                                                        .connectDate(connectDate)
                                                        .connectTime(connectTime)
                                                        .logType("PROCESS")
                                                        .requestUri(requestURI)
                                                        .requestType(menuName)
                                                        .clientIp(request.getRemoteAddr())
                                                        .registerId(user.getUserId())
                                                        .errorMessage(ex==null?null:ex.getMessage() );
                logRepository.saveLog(logVOBuilder.build());
            }
        }

    }


    /*
    @Around("userLogPointCut()")
    public Object methodLog(ProceedingJoinPoint proceedingJoinPoint) throws Throwable {
        HttpServletRequest request = ((ServletRequestAttributes) RequestContextHolder.getRequestAttributes()).getRequest();
        String requestURI = request.getRequestURI();

        String ajaxAction = null;
        String menuName = null;
        try {
            String menuPattern = findUriPattern(requestURI, MENU_NAME_PATTERN);

            if(menuPattern != null) {
                List<MenuVO> allMenu = authCheckerService.findAllMenu();
                MenuVO menuVO = allMenu.stream().filter(x -> menuPattern.equals(x.getPackagePath())).findFirst().orElse(null);
                menuName = menuVO.getMenuName();

                ajaxAction = findAjaxAction(requestURI);

                if(ajaxAction != null){
                    //LogVO.LogVOBuilder logVOBuilder = LogVO.builder().method(method).uri(requestURI).logTime(logTime).ip(request.getRemoteAddr());
                    String logTime = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"));
                    LogVO.LogVOBuilder logVOBuilder = LogVO.builder().method(ajaxAction).uri(menuName).logTime(logTime).ip(request.getRemoteAddr());
                    logRepository.saveLog(logVOBuilder.build());
                }
            }
            Object result = proceedingJoinPoint.proceed();
            return result;
        } catch (Throwable throwable) {
            String logTime = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"));
            LogVO.LogVOBuilder logVOBuilder = LogVO.builder().method(throwable.getMessage()).uri(menuName).logTime(logTime).ip(request.getRemoteAddr());
            logRepository.saveLog(logVOBuilder.build());

            throw throwable;
        }

    }
     */

    /** menu name find 정규식 /a/b/c/d/e/f => /a/b/c/                                     */
    private static final String MENU_NAME_REGEX = "^\\/(.*?)\\/(.*?)\\/(.*?)\\/";
    private static final Pattern MENU_NAME_PATTERN = Pattern.compile(MENU_NAME_REGEX);

    /** ajax action find 정규식     ~/ajax/action/~/ => /ajax/action/                     */
    /**                            ~/ajax/action => NO                                   */
    //    private static final String AJAX_ACTION_REGEX = "\\/ajax\\/(.*?)\\/";

    /** ajax action find 정규식    ~/ajax/searchList/ => /ajax/search                     */
    /** ajax action find 정규식    ~/ajax/search/list => /ajax/search                     */
    private static final String AJAX_ACTION_REGEX ="\\/ajax\\/(search\\/list|save|delete)";
    private static final Pattern AJAX_ACTION_PATTERN = Pattern.compile(AJAX_ACTION_REGEX);

    private static class Constants{
        static final Map<String, String> immutableMap;
        static {
            Map<String, String> mutableMap = new HashMap<>();
            mutableMap.put("/ajax/search/list", "조회");
            mutableMap.put("/ajax/save", "저장");
            mutableMap.put("/ajax/delete", "삭제");
            immutableMap = Collections.unmodifiableMap(mutableMap);
        }
    }



    /**
     * url로 패턴 찾기
     */
    private static String findUriPattern(String requestUri, Pattern patternName){

        Matcher matcher = patternName.matcher(requestUri);
        String result = null;
        while (matcher.find()) {
            result = matcher.group();
        }

        return result;
    }

    /**
     * uri로 ajax action 찾기
     */
    private static String findAjaxAction(String requestUri){

        String pattern = findUriPattern(requestUri, AJAX_ACTION_PATTERN);

        String action = Constants.immutableMap.get(pattern);

        return action;
    }

    private static JSONObject getParams(HttpServletRequest request){
        JSONObject jsonObject = new JSONObject();


        Enumeration<String> params = request.getParameterNames();

        while(params.hasMoreElements()){
            String param = params.nextElement();
            String replaceParam = param.replaceAll("\\.","-");
            jsonObject.put(replaceParam, request.getParameter(param));
        }

        return jsonObject;
    }

}