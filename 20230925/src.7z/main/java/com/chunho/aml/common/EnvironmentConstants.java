package com.chunho.aml.common;

import com.chunho.aml.common.encrypt.CryptPasswordEncoder;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.env.Environment;

import java.util.List;
import java.util.Locale;

/**
 * author         : yejin
 * date           : 2023-05-25
 * description    : 상수 설정
 * ===========================================================
 * DATE              AUTHOR             NOTE
 * -----------------------------------------------------------
 * 2023-05-25        yejin       최초 생성
 */
@Slf4j
@Configuration
public class EnvironmentConstants {

	private static Environment environment;

	private static CryptPasswordEncoder cryptPasswordEncoder;

	@Autowired
	@SuppressWarnings("static-access")
	public void environment (Environment environment, CryptPasswordEncoder cryptPasswordEncoder) {
		this.environment = environment;
		this.cryptPasswordEncoder = cryptPasswordEncoder;
	}

	public static class CommonProperty {
		public static final List<String> EXCLUDE_PATHS = environment.getProperty("data.excludes.path",List.class);

		public static final String LOGIN_PATH = "/login";

		public static final String AJAX_HEADER_NAME = "X-Requested-With";
		public static final String AJAX_HEADER_VALUE = "XMLHttpRequest";
		public static final String LOCALE_COOKIE_NAME = "language";
		public static final String LOGIN_USER_SESSION_NAME = "sessionUser";

		public static final String DEFAULT_LOCALE_KOREAN = Locale.KOREAN.getLanguage();

		public static final String DEFAULT_PASSWORD
				= cryptPasswordEncoder.encode(environment.getProperty("default.password",String.class));

	}



}
