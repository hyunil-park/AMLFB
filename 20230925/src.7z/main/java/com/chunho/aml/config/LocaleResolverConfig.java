package com.chunho.aml.config;

import com.chunho.aml.common.EnvironmentConstants;
import lombok.extern.slf4j.Slf4j;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.LocaleResolver;
import org.springframework.web.servlet.i18n.CookieLocaleResolver;

import java.util.Locale;

/**
 * author         : yejin
 * date           : 2023-05-25
 * description    : 다국어 처리 설정
 * ===========================================================
 * DATE              AUTHOR             NOTE
 * -----------------------------------------------------------
 * 2023-05-25        yejin       최초 생성
 */

@Configuration
@Slf4j
public class LocaleResolverConfig {
  /*  //메세지 테스트코드를위함
    @Bean
    public MessageSource messageSource() {
        ResourceBundleMessageSource messageSource = new ResourceBundleMessageSource();
       messageSource.setBasename("messages/messages");
       messageSource.setDefaultEncoding("UTF-8");
       // locale에 해당하는 file이 없을 경우 system locale을 사용
       //messageSource.setFallbackToSystemLocale(false);
       return messageSource;
    }

    @Bean
    public MessageSourceAccessor messageSourceAccessor()  {
        return new MessageSourceAccessor(messageSource());
    }
   */

    /*
    //세션로케일리졸버
    @Bean
    public SessionLocaleResolver localeResolver() {
        SessionLocaleResolver sessionLocaleResolver = new SessionLocaleResolver();
        sessionLocaleResolver.setDefaultLocale(Locale.KOREA);
        return sessionLocaleResolver;
    }

    */

    /**
     * 쿠키로케일리졸버
     * @return
     */
    @Bean
    public LocaleResolver localeResolver() {
        CookieLocaleResolver localeResolver = new CookieLocaleResolver();
        localeResolver.setCookieName(EnvironmentConstants.CommonProperty.LOCALE_COOKIE_NAME);
        localeResolver.setDefaultLocale(new Locale(EnvironmentConstants.CommonProperty.DEFAULT_LOCALE_KOREAN));
        localeResolver.setCookieHttpOnly(true);
        return localeResolver;
    }

}
