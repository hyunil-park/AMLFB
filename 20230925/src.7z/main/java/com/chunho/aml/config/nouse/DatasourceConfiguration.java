package com.chunho.aml.config.nouse;


//@Configuration
//
// @PropertySource("classpath:profile/${spring.profiles.active}/database.yml")
//@PropertySource(value = "classpath:config/database.properties")
public class DatasourceConfiguration {

}
