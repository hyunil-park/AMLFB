package com.chunho.aml.config;


import com.chunho.aml.common.EnvironmentConstants;
import com.chunho.aml.common.filter.TransactionLogFilter;
import com.chunho.aml.common.interceptor.AuthLoginInterceptor;
import com.chunho.aml.common.interceptor.CommonInterceptor;
import com.chunho.aml.common.interceptor.AuthCheckerService;
import org.springframework.boot.web.servlet.FilterRegistrationBean;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.InterceptorRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;
import org.springframework.web.servlet.i18n.LocaleChangeInterceptor;

import javax.servlet.Filter;


/**
 * author         : yejin
 * date           : 2023-05-25
 * description    : 인터셉터, 필터, 등 Web Application 전반적인 설정
 * ===========================================================
 * DATE              AUTHOR             NOTE
 * -----------------------------------------------------------
 * 2023-05-25        yejin       최초 생성
 */
@Configuration
public class WebMvcConfig implements WebMvcConfigurer {

    private final AuthCheckerService authChecker;
    public WebMvcConfig(AuthCheckerService authChecker){
        this.authChecker = authChecker;
    }


    /*
    //세션 로케일 사용시

    private final LocaleChange localeChange;

    public WebMvcConfig(AuthCheckerService authChecker, LocaleChange localeChange) {
        this.authChecker = authChecker;
        this.localeChange = localeChange;
    }
    */


    /**
     * 인터셉터 등록
     * @param registry

     */
    @Override
    public void addInterceptors(InterceptorRegistry registry) {
        registry.addInterceptor(new CommonInterceptor())
                .excludePathPatterns(EnvironmentConstants.CommonProperty.EXCLUDE_PATHS);

        registry.addInterceptor(new AuthLoginInterceptor(authChecker))
                .excludePathPatterns(EnvironmentConstants.CommonProperty.EXCLUDE_PATHS)
                        .excludePathPatterns("/login",
                                              "/",
                                            "/ajax/login",
                                            "/jsonError",
                                            "/error",
                                            "/ajax/logout"
                                            );


        registry.addInterceptor(localeChangeInterceptor());
    }

    /**
     * 다국어 인터셉터
     * @return
     */

    /* 세션로케일 사용시
    
    public LocaleChange localeChangeInterceptor() {
        //LocaleChangeInterceptor localeChangeInterceptor = new LocaleChangeInterceptor();
        //LocaleChange localeChangeInterceptor = new LocaleChange(messageInjector);
       // LocaleChange localeChangeInterceptor = new LocaleChange(messageInjector());
        localeChange.setParamName("lang");
        return localeChange;
    }*/

    public LocaleChangeInterceptor localeChangeInterceptor() {
        LocaleChangeInterceptor localeChangeInterceptor = new LocaleChangeInterceptor();
        localeChangeInterceptor.setParamName("lang");
        
        //유효하지않은locale인 경우 오류 발생 여부
        //localeChangeInterceptor.setIgnoreInvalidLocale(true); 
        return localeChangeInterceptor;
    }


    /**
     * 로그 필터
     * @return
     */
    @Bean
    public FilterRegistrationBean logFilter(){
        FilterRegistrationBean<Filter> filterFilterRegistrationBean = new FilterRegistrationBean<>();
        filterFilterRegistrationBean.setFilter(new TransactionLogFilter());
        filterFilterRegistrationBean.setOrder(1);
        filterFilterRegistrationBean.addUrlPatterns("/*");

        return filterFilterRegistrationBean;
    }
}
