package com.chunho.aml.config.nouse;

import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;
import org.springframework.web.servlet.i18n.LocaleChangeInterceptor;

import java.util.Locale;

/**
 * author         : yejin
 * date           : 2023-06-07
 * description    :
 * ===========================================================
 * DATE              AUTHOR             NOTE
 * -----------------------------------------------------------
 * 2023-06-07        yejin       최초 생성
 */

@Slf4j
@Component
public class LocaleChange extends LocaleChangeInterceptor {
    public final MessageInjector messageInjector;

    public LocaleChange(MessageInjector messageInjector){
        this.messageInjector = messageInjector;
    }

    public Locale parseLocaleValue(String localeValue) {
        log.info("LocaleChangeInterceptor parseLocaleValue : {} ", localeValue);
        messageInjector.changeLocale(localeValue);
        return super.parseLocaleValue(localeValue);
    }
}
