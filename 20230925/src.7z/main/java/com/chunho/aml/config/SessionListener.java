package com.chunho.aml.config;

import org.springframework.beans.factory.annotation.Value;

import javax.servlet.http.HttpSessionEvent;
import javax.servlet.http.HttpSessionListener;
/**
 * author         : yejin
 * date           : 2023-06-01
 * description    : spring boot의 내장 톰캣 사용으로 세션 timeout 리스너 사용
 * ===========================================================
 * DATE              AUTHOR             NOTE
 * -----------------------------------------------------------
 * 2023-05-25        yejin       최초 생성
 */
public class SessionListener implements HttpSessionListener {
    
    @Value("${server.servlet.session.timeout}")
    private int sessionTime;
    
    public void sessionCreated(HttpSessionEvent se) {
        se.getSession().setMaxInactiveInterval(sessionTime);
    }
 
    public void sessionDestroyed(HttpSessionEvent se) {
    }
}