package com.chunho.aml.config;

import com.chunho.aml.common.cache.CacheKeys;
import net.sf.ehcache.Cache;
import net.sf.ehcache.CacheManager;
import net.sf.ehcache.config.CacheConfiguration;
import net.sf.ehcache.config.DiskStoreConfiguration;
import net.sf.ehcache.config.PersistenceConfiguration;
import org.springframework.cache.annotation.EnableCaching;
import org.springframework.cache.ehcache.EhCacheCacheManager;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@EnableCaching
@Configuration
public class EhCacheConfig {

    private CacheManager createCacheManager() {
        net.sf.ehcache.config.Configuration configuration = new net.sf.ehcache.config.Configuration();
        configuration.diskStore(new DiskStoreConfiguration().path("java.io.tmpdir"));
        return CacheManager.create(configuration);
    }

    @Bean
    public EhCacheCacheManager ehCacheCacheManager() {
        CacheManager manager = this.createCacheManager();
        CacheKeys keys = new CacheKeys();
        keys.getCacheMaps().forEach((cacheName,time)->{
            Cache cache = new Cache(new CacheConfiguration()
                    .maxEntriesLocalHeap(1000)
                    .maxEntriesLocalDisk(10000)
                    .eternal(false)
                    .timeToIdleSeconds(time)
                    .timeToLiveSeconds(time)
                    .memoryStoreEvictionPolicy("LFU")
                    .transactionalMode(CacheConfiguration.TransactionalMode.OFF)
                    .persistence(new PersistenceConfiguration().strategy(PersistenceConfiguration.Strategy.LOCALTEMPSWAP))
                    .name(cacheName)
            );
            manager.addCache(cache);
        });


        return new EhCacheCacheManager(manager);
    }
}
