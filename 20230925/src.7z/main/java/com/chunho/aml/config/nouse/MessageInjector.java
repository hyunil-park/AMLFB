package com.chunho.aml.config.nouse;

import com.chunho.aml.common.exception.CommonErrorType;
import com.chunho.aml.portal.str.investigation.investigation.StrReportErrorType;
import lombok.extern.slf4j.Slf4j;
import org.springframework.context.MessageSource;
import org.springframework.stereotype.Component;

import java.util.Arrays;
import java.util.Locale;

/**
 * author         : yejin
 * date           : 2023-06-05
 * description    : 언어 변경시 사용할 메세지에대하여 enum setting
 * ===========================================================
 * DATE              AUTHOR             NOTE
 * -----------------------------------------------------------
 * 2023-06-05        yejin       최초 생성
 */

@Component
@Slf4j
public class MessageInjector {
    private final MessageSource messageSource;


    public MessageInjector(MessageSource messageSource) {
        this.messageSource = messageSource;
    }

    /* 로그인후 모든화면에서 다국어 변경 기능 사용안하게되면 고려
    @Value("${application.locale}")
    private String locale;

    @PostConstruct
    public void postConstruct() {
        Arrays.stream(CommonErrorType.values())
                .forEach(errorcode -> errorcode.message = messageSource.getMessage(errorcode.getCode(), null, Locale.forLanguageTag(this.locale)));
    }
    */
    /**
     * 메세지용 Enum 추가시  아래 추가 필요
     * @param language
     */
    public void changeLocale(String language){
        log.info("MessageInjector, language : {} ", language);

        Arrays.stream(CommonErrorType.values())
                .forEach(errorCode -> errorCode.message =
                        messageSource.getMessage(errorCode.getCode(), null, Locale.forLanguageTag(language)));

        Arrays.stream(StrReportErrorType.values())
                .forEach(errorCode -> errorCode.message =
                        messageSource.getMessage(errorCode.getCode(), null, Locale.forLanguageTag(language)));

    }
}
