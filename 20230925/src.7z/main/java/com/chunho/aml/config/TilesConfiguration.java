package com.chunho.aml.config;


import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.view.tiles3.TilesConfigurer;
import org.springframework.web.servlet.view.tiles3.TilesView;
import org.springframework.web.servlet.view.tiles3.TilesViewResolver;
/**
 * author         : yejin
 * date           : 2023-05-23
 * description    : tiles 설정
 * ===========================================================
 * DATE              AUTHOR             NOTE
 * -----------------------------------------------------------
 * 2023-05-23        yejin       최초 생성
 */
@Configuration
public class TilesConfiguration {

    @Bean
    public TilesConfigurer tilesConfigurer(){
        
        TilesConfigurer tilesConfigurer = new TilesConfigurer();
        
        //tiles.xml 경로 명시
        tilesConfigurer.setDefinitions(new String[]{
            "classpath:config/tiles.xml"        
        });
        
        //리프레쉬 가능 여부 설정
        tilesConfigurer.setCheckRefresh(true);
        return  tilesConfigurer;
    }

    @Bean
    public TilesViewResolver tilesViewResolver(){
        TilesViewResolver tilesViewResolver = new TilesViewResolver();
        tilesViewResolver.setViewClass(TilesView.class);
        tilesViewResolver.setOrder(1); //뷰 우선순위
        return tilesViewResolver;
    }
}
